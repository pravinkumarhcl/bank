<?php
error_reporting(E_ALL);
phpinfo();
?>