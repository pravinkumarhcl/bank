<?php
class dashboard_model extends CI_Model {
	public function __construct()
     {
		   parent::__construct();
		   $this->active_user="";
		   $this->active_invoice_user="";
		   $this->active_vendor_user="";
		   $active_cust_id=$this->session->userdata('active_cust_id');
		   if($active_cust_id!='')
		   {
			 $active_cust_id=$active_cust_id;
			 $this->active_user=" AND cust_id=$active_cust_id";
			 $this->active_t_user=" AND t1.cust_id=$active_cust_id";
			 $this->active_invoice_user=" AND invoice_cust_id=$active_cust_id";
			 $this->active_vendor_user=" AND vendor_cust_id=$active_cust_id";
		   }
	}
    function vendorCodeandCount()
    {       
        //and due_date = CURDATE() 
        $query = $this->db->query("select * from (SELECT t1.* , DATE_ADD(DATE(invoice_date), INTERVAL invoice_deduction_days DAY) as due_date FROM invoice_details as t1) 
                as tmp where  invoice_status='Pending' group by due_date order by due_date asc limit 0,10");             
        return $query->result();
    }   
   
    
    function approvedInvoicegroupbyAccountno()
    {
        $query = $this->db->query("SELECT invoice_cust_id,invoice_vendor_id,invoice_beneficiary_name, invoice_beneficiary_number, sum(invoice_amount) as invoice_amount,sum(invoice_discount) as invoice_discount,sum(invoice_topaid) as invoice_topaid,invoice_date,invoice_status FROM "
                . "invoice_details where invoice_status ='Approved' ".$this->active_invoice_user." group by invoice_beneficiary_number");
        return $query->result();
    }
    
    function vendorCodeandCountMainPage()
    {
        $query = $this->db->query("SELECT vendor_id,vendor_name, vendor_code,vendor_cust_id, "
                . "(select count(*) from invoice_details where invoice_vendor_id = vendor_id and invoice_status='Pending') "
                . "as pending_count , "
                . "(select sum(invoice_amount) from invoice_details where invoice_vendor_id = vendor_id) "
                . "as total_amount , "
                . "(select count(*) from invoice_details where invoice_vendor_id = vendor_id and invoice_status='Confirmed') "
                . "as confirmed_count "
                . "FROM vendor_details order by vendor_name asc");
                
        return $query->result();
    }
    
    function customerCodeandvendorCount()
    {
        
        $query = $this->db->query("SELECT *,"
                . "(select count(*) from vendor_details where cust_id=vendor_cust_id) as totalcount "
                . "FROM customer_details");
        return $query->result();
    }
    
    function logdetailsQuery()
    {
        
        $query = $this->db->query("SELECT t2.cust_name,t1.* FROM log_details as t1 
            left join customer_details as t2 on t1.member_id = t2.cust_id 
            order by dateupdated desc");
        return $query->result();
    }
    
    function getInvoicebyAccountno($number)
    {
        $query = $this->db->query("SELECT * from invoice_details AS t1
		LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
		where "
                . "invoice_beneficiary_number='".$number."' and invoice_status ='Approved'");
        return $query->result();
    }
    
    function getInvoicebyTransactionnumber($number)
    {
        $query = $this->db->query("SELECT * from invoice_details AS t1
		LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
		where "
                . "invoice_transactionid='".$number."'");
        return $query->result();
    }
    
    function getInterestlist()
    {
        $status = $this->input->get('status');
        if($status=='')
        {
            $status = 'Pending';
        }
        if($status!='')
        {
            $where = ' where t1.status="'.$status.'"';
        }
        $query = $this->db->query("SELECT t2.cust_name,t2.cust_id,t1.* FROM customer_interest_rate as t1 left join customer_details as t2 "
                . "on t1.cust_rate_cust_id = t2.cust_id ".$where." order by t2.cust_name asc");
        return $query->result();
    }	
	function getMasterRates()
	{
			$sQuery = "SELECT rate_id,3mclr as threemclr,6mclr as sixmclr,9mclr as ninemclr,12mclr twelvemclr,strategic_premium,risk_premium,cust_interest_rate,status,IFNULL(DATE_FORMAT(effective_from,'%d-%m-%Y'),'-') AS effective_from,IFNULL(DATE_FORMAT(effective_to,'%d-%m-%Y'),'-') AS effective_to FROM rates_master ";	
			$rResult = $this->db->query($sQuery);
			$res= $rResult->result_array();
			return $this->db->last_query();
	}
	function InvoiceStatusReport($filter_from,$filter_to)
	{
		 if($filter_from!='' && $filter_to!='')
		   {
			   $filter_from=explode("-",$filter_from);
			    $filter_from=$filter_from[2].'-'.$filter_from[1].'-'.$filter_from[0];
				
				$filter_to=explode("-",$filter_to);
			    $filter_to=$filter_to[2].'-'.$filter_to[1].'-'.$filter_to[0];
				
				$invoice_date=" AND DATE(invoice_date) BETWEEN '$filter_from' AND '$filter_to' ";				
		   }
		   
			
		   
			$sQuery = "SELECT invoice_status,
			FORMAT(ROUND(SUM(invoice_amount),2),'2','en_IN')  AS invoice_amount,
			FORMAT(ROUND(SUM(invoice_discount),2),'2','en_IN')  AS invoice_discount,
			FORMAT(ROUND(SUM(invoice_to_paid),2),'2','en_IN') AS invoice_to_paid 
			FROM (
			(
				SELECT 'Pending' AS invoice_status,(0.00) AS invoice_amount,(0.00) invoice_discount,(0.00) invoice_to_paid
			)
			UNION
			(
				SELECT 'Paid' AS invoice_status,(0.00) AS invoice_amount,(0.00) invoice_discount,(0.00) invoice_to_paid
			)
			UNION
			(
				SELECT 'Verified' AS invoice_status,(0.00) AS invoice_amount,(0.00) invoice_discount,(0.00) invoice_to_paid
			)
			UNION
			(
				SELECT 'Approved' AS invoice_status,(0.00) AS invoice_amount,(0.00) invoice_discount,(0.00) invoice_to_paid
			)
			UNION
			(
				SELECT			
				invoice_status,		
				ROUND(SUM(invoice_amount),2) AS invoice_amount,ROUND(SUM(invoice_discount),2) AS invoice_discount,ROUND(SUM(invoice_amount)-SUM(invoice_discount),2) AS invoice_to_paid
				FROM(
				SELECT 			
				invoice_amount AS invoice_amount,

				CASE WHEN invoice_net='NET' THEN (((interest_rate)*(invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END AS invoice_discount,

				invoice_status		
				FROM invoice_details AS i
				LEFT JOIN customer_details AS c ON c.cust_id=i.invoice_cust_id
				WHERE invoice_status!='Rejected' ".$this->active_user." $invoice_date
				GROUP BY invoice_id)inv
				GROUP BY invoice_status
			)
			)tab GROUP BY invoice_status
			ORDER BY (CASE WHEN invoice_status='Pending' THEN 'A' WHEN invoice_status='Verified' THEN 'B' WHEN invoice_status='Approved' THEN 'C' ELSE 'D' END)ASC";	
			$rResult = $this->db->query($sQuery);		;
			$res= $rResult->result_array();
			return $res;
	}
	function ActivateMasterRate($rate_id)
	{
			$sQuery_deactive = "UPDATE rates_master SET status='Inactive',effective_to=now() WHERE status='Active'";	
			$this->db->query($sQuery_deactive);
			
			$sQuery_active = "UPDATE rates_master SET status='Active',effective_from=now() WHERE rate_id='$rate_id'";	
			$this->db->query($sQuery_active);			
			
	}	
    function paidInvoicegroupbytransactionID()
    {
        $query = $this->db->query("SELECT payment_datetime,invoice_transactionid,invoice_cust_id,invoice_vendor_id,invoice_beneficiary_name, invoice_beneficiary_number, sum(invoice_amount) as invoice_amount,sum(invoice_discount) as invoice_discount,sum(invoice_topaid) as invoice_topaid,invoice_date,invoice_status FROM "
                . "invoice_details where invoice_status ='Paid' ".$this->active_invoice_user." group by invoice_transactionid");
        return $query->result();
    }
    
    function getweeklylimit($cust_id)
    {
        $query = $this->db->query("SELECT sum(invoice_topaid) as week_amount FROM invoice_details where "
                . "WEEK(payment_datetime) = WEEK('".date('Y-m-d H:i:s')."') and invoice_status IN('Paid') and invoice_cust_id = '".$cust_id."'");
        return $query->result();
    }
    
    function getmonthlylimit($cust_id)
    {
        $query = $this->db->query("SELECT sum(invoice_topaid) as month_amount FROM invoice_details where "
                . "MONTH(payment_datetime) = MONTH('".date('Y-m-d H:i:s')."') and invoice_status IN('Paid') and invoice_cust_id = '".$cust_id."'");
        return $query->result();
    }
    
    function getTotallimit($cust_id)
    {
        $query = $this->db->query("SELECT sum(invoice_topaid) as total_amount FROM invoice_details "
                . "where invoice_cust_id = '".$cust_id."' and invoice_status IN('Paid')");
        return $query->result();
    }
    function getreplenishmentlist($id='')
    {
        if($id!='')
        {
            $where= ' where t1.id= "'.$id.'" '.$this->active_t_user;
        }
        else {
            $where= ' where 1=1 '.$this->active_t_user;;
        }
        $query = $this->db->query("SELECT t1.*,t2.cust_name FROM cust_replenishment 
            as t1 left join customer_details as t2 on t1.cust_id = t2.cust_id ".$where." 
            order by t1.date_created
        ");
        return $query->result();
    }
    function getreplenishmentlist_query($id=''){
		  if($id!='')
        {
            $where= ' where t1.id= "'.$id.'" '.$this->active_t_user;
        }
        else {
            $where= ' where 1=1 '.$this->active_t_user;;
        }
        $query = $this->db->query("SELECT t1.*,t2.cust_name FROM cust_replenishment 
            as t1 left join customer_details as t2 on t1.cust_id = t2.cust_id ".$where." 
          
        ");
        return  $this->db->last_query();
		
	}
    function autocompleteCustomers()
    {
        $q = $this->input->get("term");
        $json=array();
        $query = $this->db->query("select * from (SELECT CONCAT(cust_name, ',', cust_user_code) AS fullname,cust_name,cust_user_code from "
                . "customer_details) as tmp WHERE fullname LIKE '%".$q."%'");
        
        $queryarray = $query->result_array();
        foreach ($queryarray as $eachresult) 
        {
		array_push($json, $eachresult['cust_name'].' ('.$eachresult['cust_user_code'].')');
        }
        echo json_encode($json);
        exit;
    }
    function GetCustomerByID($custid)
	{
		$sQuery = "SELECT cust_name FROM customer_details WHERE cust_id=".$custid;	
		$rResult = $this->db->query($sQuery);
		$res= $rResult->result_array();
		return $res;
	}
	function GetVendorByID($vendor_id)
	{
		$sQuery = "SELECT c.cust_id,vendor_name,cust_name
		FROM vendor_details as v
		LEFT JOIN customer_details AS c ON v.vendor_cust_id=c.cust_id
		WHERE vendor_id=".$vendor_id;	
		$rResult = $this->db->query($sQuery);
		$res= $rResult->result_array();
		return $res;
	}
	
	function customerBasedReport($filter_from,$filter_to)
    {	
		 if($filter_from!='' && $filter_to!='')
		   {
			   $filter_from=explode("-",$filter_from);
			    $filter_from=$filter_from[2].'-'.$filter_from[1].'-'.$filter_from[0];
				
				$filter_to=explode("-",$filter_to);
			    $filter_to=$filter_to[2].'-'.$filter_to[1].'-'.$filter_to[0];
				
				$invoice_date=" AND DATE(invoice_date) BETWEEN '$filter_from' AND '$filter_to' ";				
		   }
		

		
		   
		$sQuery = "
		SELECT cust_id,cust_no,cust_name,cust_loan_limit,SUM(paid_amount) AS paid_amount,(cust_loan_limit-SUM(paid_amount))  AS balance_amount,SUM(pending_amount) AS pending_amount
		FROM(SELECT c.cust_id,c.cust_user_code AS cust_no,c.cust_name AS cust_name,
		IFNULL(c.cust_loan_limit,0) AS cust_loan_limit,
		
		IFNULL(CASE WHEN i.invoice_status='Paid' THEN SUM(IFNULL(i.invoice_topaid,0)) END,0) AS paid_amount,
		
		
		
		IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN ROUND(SUM(invoice_amount)-SUM(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END),2) END,0) AS pending_amount
		
		FROM customer_details AS c
		LEFT JOIN vendor_details AS v ON v.vendor_cust_id=c.cust_id
		LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
		WHERE 1=1 $invoice_date  ".$this->active_user."
		GROUP BY c.cust_id,i.invoice_status)report group by cust_id";
	
		$rResult = $this->db->query($sQuery);
		$res= $rResult->result_array();
		return $res;
    }	
	

	
	
	
	function vendorBasedReport($cust_id,$filter_from,$filter_to)
    {		
		/* $filter_from='28-06-2018';
		$filter_to='06-07-2018'; */
		 if($filter_from!='' && $filter_to!='')
		   {
			    $filter_from=explode("-",$filter_from);
			    $filter_from=$filter_from[2].'-'.$filter_from[1].'-'.$filter_from[0];
				
				$filter_to=explode("-",$filter_to);
			    $filter_to=$filter_to[2].'-'.$filter_to[1].'-'.$filter_to[0];
				
				$invoice_date=" AND DATE(i.invoice_date) BETWEEN '$filter_from' AND '$filter_to' ";				
		   }
		  /* $sQuery = "
		SELECT invoice_date,vendor_id,vendor_name,vendor_code,vendor_company_name,vendor_phone,vendor_email,SUM(discount) AS discount,SUM(paid_amount) AS paid_amount,SUM(pending_amount) AS pending_amount,SUM(IFNULL(invoice_amount,0)) invoice_amount
		FROM(SELECT v.vendor_id,v.vendor_name,v.vendor_code,v.vendor_company_name,v.vendor_phone,v.vendor_email,
        
		SUM(IFNULL(i.invoice_amount,0)) invoice_amount,
			
		
		ROUND(IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN SUM(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END)
		ELSE SUM(i.invoice_discount)
		END,0),2) AS discount,
		
		SUM(IFNULL(CASE WHEN i.invoice_status='Paid' AND i.invoice_topaid>0 THEN IFNULL(i.invoice_topaid,0)  WHEN i.invoice_status='Paid' THEN  IFNULL(i.invoice_amount,0) END,0)) AS paid_amount,
		
		IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN ROUND(SUM(invoice_amount)-SUM(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END),2) END,0) AS pending_amount	,i.invoice_date	
		
		FROM vendor_details AS v 
		LEFT JOIN customer_details AS c ON v.vendor_cust_id=c.cust_id
		LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
		WHERE v.vendor_cust_id=$cust_id  $invoice_date  ".$this->active_user."
		GROUP BY v.vendor_id,i.invoice_status
		)report where 1=1 "; */
		
	$sQuery = "SELECT v.vendor_id,v.vendor_name,v.vendor_code,v.vendor_company_name,v.vendor_phone,v.vendor_email,
        
		SUM(IFNULL(i.invoice_amount,0)) invoice_amount,
			
		
		ROUND(IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN SUM(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END)
		ELSE SUM(i.invoice_discount)
		END,0),2) AS discount,
		
		SUM(IFNULL(CASE WHEN i.invoice_status='Paid' AND i.invoice_topaid>0 THEN IFNULL(i.invoice_topaid,0)  WHEN i.invoice_status='Paid' THEN  IFNULL(i.invoice_amount,0) END,0)) AS paid_amount,
		
		IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN ROUND(SUM(invoice_amount)-SUM(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END),2) END,0) AS pending_amount	,i.invoice_date	
		
		FROM vendor_details AS v 
		LEFT JOIN customer_details AS c ON v.vendor_cust_id=c.cust_id
		LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
		WHERE v.vendor_cust_id=$cust_id  $invoice_date  ".$this->active_user."
		GROUP BY v.vendor_id";
		
		$rResult = $this->db->query($sQuery);
		$res= $rResult->result_array();
		return $sQuery;
    }
	function invoiceBasedReport($vendor_id)
    {	
		
		 if($filter_from!='' && $filter_to!='')
		   {
			   $filter_from=explode("-",$filter_from);
			    $filter_from=$filter_from[2].'-'.$filter_from[1].'-'.$filter_from[0];
				
				$filter_to=explode("-",$filter_to);
			    $filter_to=$filter_to[2].'-'.$filter_to[1].'-'.$filter_to[0];
				
				$invoice_date=" AND DATE(invoice_date) BETWEEN '$filter_from' AND '$filter_to' ";				
		   }
		$sQuery = "SELECT invoice_id,
		invoice_beneficiary_name, invoice_beneficiary_number, invoice_number, invoice_ifsc_code, 
		
		ROUND(IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' 
		THEN 
			CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) 
			ELSE 
			0 END ELSE invoice_discount
		END,0),2) AS invoice_discount,
		
		i.invoice_amount,i.invoice_deduction_days,
		
		ROUND(IFNULL(CASE WHEN i.invoice_status='Pending' OR  i.invoice_status='Approved' OR i.invoice_status='Verified' THEN (invoice_amount)-(CASE WHEN UPPER(i.invoice_net)='NET' THEN ((c.interest_rate*(i.invoice_amount*invoice_deduction_days)/365)/100) ELSE 0 END) ELSE invoice_topaid END,0),2) AS invoice_topaid,	
		
		(CASE WHEN invoice_status='Paid' THEN invoice_transactionid ELSE '-' END) AS invoice_transactionid, invoice_net, invoice_date, invoice_status
		FROM invoice_details AS i
		LEFT JOIN customer_details AS c ON i.invoice_cust_id=c.cust_id
		WHERE invoice_vendor_id=$vendor_id  $invoice_date  ".$this->active_user."";	
		$rResult = $this->db->query($sQuery);
		$res= $rResult->result_array();
		return $this->db->last_query();
    }	
	function GetCustomerForSelection()
	{
			$sQuery = "SELECT cust_id,cust_name,cust_user_code FROM customer_details;";	
			$rResult = $this->db->query($sQuery);
			$res= $rResult->result_array();
			return $res;
	}	
	function get_RatesMasterActive()
	{
			$sQuery = "SELECT m.*,IFNULL(DATE_FORMAT(effective_from,'%d-%m-%Y'),'-') AS effective_from FROM rates_master m WHERE STATUS='Active';";	
			$rResult = $this->db->query($sQuery);
			$res= $rResult->result_array();
			return $res;
	}
	function get_MCLR_Active($cust_id)
	{
			$sQuery = "SELECT three_mclr,six_mclr,nine_mclr,mclr_twelve,financing_date,strategic_premium_rate,risk_premium_rate 
FROM customer_details WHERE cust_id=1;";	
			$rResult = $this->db->query($sQuery);
			$res= $rResult->result_array();
			return $res;
	}	
	function invoiceByCustomer($status)
	{
			$sQuery = "SELECT 
			cus.cust_id,cus.cust_name,cus.cust_user_code AS cust_code,CASE WHEN cus.cust_mclr='12' THEN  '1 Year' ELSE CONCAT(cus.cust_mclr,' Months') END cust_mclr,cus.cust_weekly_loan_limit,
			cus.cust_monthly_loan_limit,cus.cust_current_loan_balance,SUM(invoice_topaid) AS to_be_paid,COUNT(invoice_id) AS  no_of_invoice
			FROM
			customer_details AS cus
			LEFT JOIN invoice_details AS inv ON inv.invoice_cust_id=cus.cust_id
			WHERE invoice_status='$status'
			GROUP BY cus.cust_id;";	
			$rResult = $this->db->query($sQuery);
			$res= $rResult->result_array();
			return $res;
	}   
	function referralCompanyByCode($cust_id)
    {     
		$query="select cust_id,cust_name,		
		FORMAT(cust_loan_limit,'2','en_IN') AS cust_loan_limit,
		
		CONCAT('<b>".SUBSIDIARY_LIMIT."%</b> (',FORMAT(((cust_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN'),')') AS sub_loan_limit,		
		
		FORMAT(cust_current_loan_balance,'2','en_IN') AS cust_current_loan_balance,
		
		FORMAT(cust_weekly_loan_limit,'2','en_IN') AS cust_weekly_loan_limit,
		
		CONCAT('<b>".SUBSIDIARY_LIMIT."%</b> (',FORMAT(((cust_weekly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN'),')') AS sub_weekly_loan_limit,
		
		FORMAT(cust_monthly_loan_limit,'2','en_IN') AS cust_monthly_loan_limit,
		
		CONCAT('<b>".SUBSIDIARY_LIMIT."%</b> (',FORMAT(((cust_monthly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN'),')') AS sub_monthly_loan_limit,
		cust_mclr
		,strategic_premium_rate,
		risk_premium_rate,mclr_percent,interest_rate,cust_status from customer_details WHERE cust_id='".$cust_id."'";
        $query = $this->db->query($query);     
        $res= $query->result_array();
		return $res[0];
    }
	function referralCompanyByCodeToSave($cust_id)
    {     
		$query="select cust_id,
		cust_name,		
		cust_loan_limit,
		cust_current_loan_balance,
		cust_weekly_loan_limit,
		cust_monthly_loan_limit,		
		cust_mclr,
		strategic_premium_rate,
		risk_premium_rate,
		mclr_percent,
		interest_rate,
		cust_status 
		from customer_details WHERE cust_id='".$cust_id."'";
        $query = $this->db->query($query);     
        $res= $query->result_array();
		return $res[0];
    }
	/* function GetCustomerData($cust_id)
    {     
        $query = $this->db->query("select cust_id,cust_referral_id,cust_type,cust_name,cust_user_code,cust_address1,cust_address2,cust_city,cust_state,cust_phone,cust_email,cust_account_no,cust_ifsc_code,
		FORMAT(cust_loan_limit,'2','en_IN') AS cust_loan_limit,
		FORMAT(cust_current_loan_balance,'2','en_IN') AS cust_current_loan_balance,
		FORMAT(cust_weekly_loan_limit,'2','en_IN') AS cust_weekly_loan_limit,
		FORMAT(cust_monthly_loan_limit,'2','en_IN') AS cust_monthly_loan_limit,
		cust_mclr
		,strategic_premium_rate,
		risk_premium_rate,mclr_percent,interest_rate,cust_status from customer_details WHERE cust_id=".$cust_id);     
        $res= $query->result_array();
		return $res[0];
    } */
	function GetCustomerData($cust_id)
    {     
        $query = $this->db->query("select 
		cd.three_mclr,cd.six_mclr,cd.nine_mclr,cd.mclr_twelve,cd.financing_date,	cd.cust_id,cust_referral_id,cust_type,cust_name,cust_user_code,cust_address1,cust_address2,cust_city,cust_state,cust_phone,cust_email,cust_account_no,cust_ifsc_code,
		FORMAT(cust_loan_limit,'2','en_IN') AS cust_loan_limit,
		FORMAT((cust_loan_limit - cust_current_loan_balance),'2','en_IN') AS cust_loan_used,
		FORMAT(cust_current_loan_balance,'2','en_IN') AS cust_current_loan_balance,
		FORMAT(cust_weekly_loan_limit,'2','en_IN') AS cust_weekly_loan_limit,
		FORMAT(cust_monthly_loan_limit,'2','en_IN') AS cust_monthly_loan_limit,
		IFNULL(FORMAT(sum(cr.amount),'2','en_IN'),'') AS cust_replenishment,
		IFNULL(MonthInvoice.monthlypaid,'') AS monthlyPainIvoice,
		IFNULL(weekInvoice.weeklypaid,'') AS weeklyPainIvoice,
		cust_mclr
		,strategic_premium_rate,
		risk_premium_rate,mclr_percent,interest_rate,cust_status from customer_details cd
		LEFT JOIN cust_replenishment cr on cd.cust_id = cr.cust_id
        LEFT JOIN (SELECT t.invoice_cust_id,sum(t.invoice_topaid) as monthlypaid
			FROM invoice_details t
			WHERE MONTH( t.created_date) = MONTH(CURRENT_DATE())
			AND YEAR( t.created_date) = YEAR(CURRENT_DATE()) AND t.invoice_cust_id = ".$cust_id."  AND t.invoice_status = 'Paid') as MonthInvoice on cd.cust_id = MonthInvoice.invoice_cust_id
		LEFT JOIN (SELECT w.invoice_cust_id , sum(w.invoice_topaid) as weeklypaid 
			FROM invoice_details w
			WHERE w.created_date >= CURDATE() - INTERVAL  6 DAY 
			  AND w.created_date  < CURDATE() + INTERVAL  1 DAY  AND w.invoice_cust_id = ".$cust_id." AND w.invoice_status = 'Paid' ) as weekInvoice on cd.cust_id = weekInvoice.invoice_cust_id
		WHERE cd.cust_id=".$cust_id." ");     
        $res= $query->result_array();
		return $res[0];
    }
	function GetCustomerDataBySub($cust_id)
    {     
        $query = $this->db->query("select 
		s.three_mclr,s.six_mclr,s.nine_mclr,s.mclr_twelve,s.financing_date,	s.cust_id,s.cust_referral_id,s.cust_type,s.cust_name,s.cust_user_code,s.cust_address1,s.cust_address2,s.cust_city,s.cust_state,s.cust_phone,s.cust_email,s.cust_account_no,s.cust_ifsc_code,
		FORMAT(((p.cust_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN') AS cust_loan_limit,
		FORMAT(((p.cust_current_loan_balance/100)*".SUBSIDIARY_LIMIT."),'2','en_IN') AS cust_current_loan_balance,
		FORMAT(((p.cust_weekly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN') AS cust_weekly_loan_limit,
		FORMAT(((p.cust_monthly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN') AS cust_monthly_loan_limit,
		p.cust_mclr
		,p.strategic_premium_rate,
		p.risk_premium_rate,p.mclr_percent,p.interest_rate,s.cust_status 
		from customer_details AS s
		LEFT JOIN customer_details  AS p ON p.cust_id=s.cust_referral_id
		WHERE s.cust_id=".$cust_id);     
        $res= $query->result_array();
		return $res[0];
    }
	function GetCustemerByID($cust_id)
	{
		$query = $this->db->query("select 
		s.three_mclr,s.six_mclr,s.nine_mclr,s.mclr_twelve,s.financing_date,		s.cust_id,s.cust_referral_id,s.cust_type,s.cust_name,s.cust_user_code,s.cust_address1,s.cust_address2,s.cust_city,s.cust_state,s.cust_phone,s.cust_email,s.cust_account_no,s.cust_ifsc_code,
		
		(CASE WHEN s.cust_type='sub' THEN
		FORMAT(((p.cust_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN') 
		ELSE
		FORMAT(s.cust_loan_limit,'2','en_IN')  END)
		AS cust_loan_limit,		
		(CASE WHEN s.cust_type='sub' THEN
		FORMAT(((p.cust_current_loan_balance/100)*".SUBSIDIARY_LIMIT."),'2','en_IN')
		ELSE
		FORMAT(s.cust_current_loan_balance,'2','en_IN') END)
		AS cust_current_loan_balance,
		(CASE WHEN s.cust_type='sub' THEN
		FORMAT(((p.cust_weekly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN')
		ELSE
		FORMAT(s.cust_weekly_loan_limit,'2','en_IN') END)
		AS cust_weekly_loan_limit,
		(CASE WHEN s.cust_type='sub' THEN
		FORMAT(((p.cust_monthly_loan_limit/100)*".SUBSIDIARY_LIMIT."),'2','en_IN')
		ELSE
		FORMAT(s.cust_monthly_loan_limit,'2','en_IN') END)
		AS cust_monthly_loan_limit,
		(CASE WHEN s.cust_type='sub' THEN p.cust_mclr ELSE s.cust_mclr END) AS cust_mclr,
		(CASE WHEN s.cust_type='sub' THEN p.strategic_premium_rate ELSE s.strategic_premium_rate END) AS strategic_premium_rate,
		(CASE WHEN s.cust_type='sub' THEN p.risk_premium_rate ELSE s.risk_premium_rate END) AS risk_premium_rate,
		(CASE WHEN s.cust_type='sub' THEN p.mclr_percent ELSE s.mclr_percent END) AS mclr_percent,
		(CASE WHEN s.cust_type='sub' THEN p.interest_rate ELSE s.interest_rate END) AS interest_rate,
		s.cust_status 
		from customer_details AS s
		LEFT JOIN customer_details  AS p ON p.cust_id=s.cust_referral_id
		WHERE s.cust_id=".$cust_id);     
        $res= $query->result();		
		return $res[0];
	}
	function ValidateInvoice($cust_id,$vendor_code,$invoice_code)
    {     
        $query = $this->db->query("SELECT COUNT(cust_id) AS cust_id,
		CASE WHEN vendor_code='$vendor_code' AND invoice_number='$invoice_code' THEN '1' ELSE '0'  END AS same_vendor
		FROM customer_details AS c
		LEFT JOIN vendor_details AS v ON c.cust_id=v.vendor_cust_id
		LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
		WHERE c.cust_user_code='".$cust_id."'");		
        $res= $query->result_array();
		return $res[0];
    }	
	
	 function vendorCodeandCountFull($id="")
    {      
       $status=$this->encryption->decrypt(str_replace(" ","+",$this->input->get('status')));
	   if($status=='')
        {
            $status= 'Pending';
        }
        $query = $this->db->query("select * from (
		SELECT t1.* , DATE_ADD(DATE(invoice_date), INTERVAL invoice_deduction_days DAY) as due_date,c.cust_name,c.cust_id
		FROM invoice_details as t1
		LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
		WHERE  t1.invoice_cust_id='$id'
		) 
                as tmp where  invoice_status='".$status."' order by due_date asc");
        
        return $query->result();
    }
	
	function allJoinPosts($id="",$limit,$start,$col,$dir,$select_query,$groupby=""){	

       
        $query = $this->db->query($select_query.$groupby."
	  order by $col  $dir LIMIT $limit OFFSET $start ");     
			//echo $select_query.$groupby."
	 // order by $col  $dir LIMIT $limit OFFSET $start "	;	
        return $query->result();
		
	}
	function allJoinPostsCount($id="",$select_query,$groupby=""){
		
	  
		 $query = $this->db->query($select_query.$groupby);
				 return $query->num_rows(); 
	}
	  function JoinPostsSearch($id="", $limit,$start,$search,$col,$dir,$columns,$select_query,$groupby="",$status=""){
		
		$like='';
	    foreach($columns as $key=>$val){
		if($key ==0)$like .= ' and '.$val." like '%$search%'";
		else{
			$like .= 'or '.$val." like '%$search%'";
		}		
		
		
	}
	if($status!=""){
		//$like .=" and t.invoice_status = 'Pending'";
		}
	$query = $this->db->query($select_query.$groupby.$like."
	  order by $col  $dir LIMIT $limit OFFSET $start ");
	if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
	}
	
	function JoinPostsSearchCount($id="",$search,$columns,$select_query,$groupby="",$status=""){
		$like='';
		
		foreach($columns as $key=>$val){
			if($key ==0)$like .= ' and '.$val." like '%$search%'";
			else{
			$like .= 'or '.$val." like '%$search%'";
			}

		}
		if($status!=""){
			//$like .=" and t.invoice_status = 'Pending'";
		}
		$query = $this->db->query($select_query.$groupby.$like);
    
        return $query->num_rows();
		
	}
	public function commonAjax($table,$columns)
		{
			   $result =array();
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];		
			
			   
			   $totalData = $this->dashboard_model->allposts_count($table);
					
			    $totalFiltered = $totalData; 
					
				if(empty($this->input->post('search')['value']))
				{            
					$posts = $this->dashboard_model->allposts($limit,$start,$order,$dir,$table);
				}
				else {
					$search = $this->input->post('search')['value']; 

					$posts =  $this->dashboard_model->posts_search($limit,$start,$search,$order,$dir,$columns,$table);

					$totalFiltered = $this->dashboard_model->posts_search_count($search,$columns,$table);
				}
				$result['totalData'] = $totalData;
				$result['totalFiltered'] = $totalFiltered;
				$result['posts'] = $posts;
				return $result;
		}

	
	
	
	
	
	function allposts_count($table)
    {   
	if($table=="customer_details"){
			$CustomerData=$this->session->userdata("CustomerData");	 
			$cust_type=$CustomerData['cust_type'];
			$cust_referral_id=$CustomerData['cust_referral_id'];
			$where=array(); 
			if($cust_type=="parent"){
				$where=array(
				'cust_id'=>$CustomerData['cust_id'],
 				);
				$where_or=array(
 				'cust_referral_id'=>$CustomerData['cust_id']
				);
				$this->db->where($where);
				$this->db->or_where($where_or);
			}else if($cust_type=="sub"){
				$where=array(
				'cust_id'=>$CustomerData['cust_referral_id'],
 				);
				$where_or=array(
 				'cust_referral_id'=>$CustomerData['cust_referral_id']
				);
				$this->db->where($where);
				$this->db->or_where($where_or);
			} 
				//Keep parant list if selected is sub company after clear
			if($cust_type==""&&$this->session->userdata("active_cust_type_list")!=""){
				$cust_type1=$this->session->userdata("active_cust_type_list");
				$cust_id1=$this->session->userdata("active_cust_id_re_list");
				$active_parent1=$this->session->userdata("active_parent_id_for_re_list");
				$where=array(
				'cust_id'=>$active_parent1,
 				);
				$where_or=array(
 				'cust_referral_id'=>$active_parent1
				);
				//$this->db->where($where);
				//$this->db->or_where($where_or); #implemented and disabled by simi
			}
			
	}
        $query = $this
                ->db
                ->get($table);    
        return $query->num_rows();  

    }    
    function allposts($limit,$start,$col,$dir,$table)
    {   
	if($table=="customer_details"){
			$CustomerData=$this->session->userdata("CustomerData");	 
			$cust_type=$CustomerData['cust_type'];
			$cust_referral_id=$CustomerData['cust_referral_id'];
			$where=array(); 
			if($cust_type=="parent"){
				$where=array(
				'cust_id'=>$CustomerData['cust_id'],
 				);
				$where_or=array(
 				'cust_referral_id'=>$CustomerData['cust_id']
				);
				$this->db->where($where);
				$this->db->or_where($where_or);
			}else if($cust_type=="sub"){
				$where=array(
				'cust_id'=>$CustomerData['cust_referral_id'],
 				);
				$where_or=array(
 				'cust_referral_id'=>$CustomerData['cust_referral_id']
				);
				$this->db->where($where);
				$this->db->or_where($where_or);
			} 
			//Keep parant list if selected is sub company after clear
			if($cust_type==""&&$this->session->userdata("active_cust_type_list")!=""){
				$cust_type1=$this->session->userdata("active_cust_type_list");
				$cust_id1=$this->session->userdata("active_cust_id_re_list");
				$active_parent1=$this->session->userdata("active_parent_id_for_re_list");
				$where=array(
				'cust_id'=>$active_parent1,
 				);
				$where_or=array(
 				'cust_referral_id'=>$active_parent1
				);
				//$this->db->where($where);
				//$this->db->or_where($where_or); #implemented and disabled by simi
			}
			
	}
       $query = $this
                ->db
                ->limit($limit,$start)
                ->order_by($col,$dir)
                ->get($table);
        // echo $this->db->last_query();
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }   
    function posts_search($limit,$start,$search,$col,$dir,$columns,$table)
    {		
	$like='';
	foreach($columns as $key=>$val){
		if($key ==0)$like .= $val." like '%$search%'";
		else{
			$like .= 'or '.$val." like '%$search%'";
		}
		
	}
	if($table=="customer_details"){
			$CustomerData=$this->session->userdata("CustomerData");	 
			$cust_type=$CustomerData['cust_type'];
			$cust_referral_id=$CustomerData['cust_referral_id'];
			 $where=''; 
			if($cust_type=="parent"){
				 
				$where=" (cust_id=".$CustomerData['cust_id']." or cust_referral_id=".$CustomerData['cust_id'].") AND "; 
				 
			} 
			
	}
	
	 $query = $this->db->query("select * from $table where $where ($like)
	  order by $col  $dir LIMIT $limit OFFSET $start ");
	// echo $this->db->last_query();
        /*$query = $this
                ->db
                ->like('invoice_id',$search) 
				->or_like('invoice_beneficiary_name',$search)                
                ->or_like('invoice_beneficiary_number',$search)                
                ->or_like('invoice_number',$search)                
                ->or_like('invoice_amount',$search)                
                ->or_like('invoice_topaid',$search)                
                ->or_like('invoice_net',$search)                
                ->or_like('invoice_status',$search)  
                ->limit($limit,$start)
                ->order_by($col,$dir)
                ->get('invoice_details');
        
       */
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }

    function posts_search_count($search,$columns,$table)
    {
		$like='';
		foreach($columns as $key=>$val){
			if($key ==0)$like .= $val." like '%$search%'";
			else{
			$like .= 'or '.$val." like '%$search%'";
			}

		}

		$query = $this->db->query("select * from $table where $like 
		");
    
        return $query->num_rows();
    } 
}