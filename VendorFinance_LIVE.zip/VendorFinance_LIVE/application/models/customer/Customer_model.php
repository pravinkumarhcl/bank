<?php
class customer_model extends CI_Model { 

	/* function customer_model(){
		parent::__construct(); 
	} */
	function check_login($uname,$pass){
	
		#For Temp purpose password is not encrypt
		$this->db->select("*");
		$this->db->from("user_details");
		$where_arr=array('user_type'=>'customer','user_login_name'=>$uname,'user_status'=>1);
		if($pass!=""){
			$where_arr['user_login_password']=md5($pass);
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		
		return $res;
	}	
	function get_all_invoice($type="",$id="",$where_Array=array()){
		#Getting all invoice details from single table
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("*");
		$this->db->from("invoice_details");
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id']);
		if($type!=""&& $type!="Documents"){
			$where_arr['invoice_status']=$type;
		}else if($type=="Documents"){ 
			$this->db->where("invoice_id not in(select(invoice_id) from invoice_documents where status<>'2')");
		}
		if($id!=""){
			$where_arr['invoice_id']=$id;
		}
		if(!empty($where_Array)){
			$this->db->where($where_Array);
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $res->result_array();
	}
	function get_all_invoice_by_vendor_list($vendor,$where_Array){
		#Getting all invoice details from single table
		$cust_data=$this->session->userdata('customer_login');
		$customer_id =	$this->session->userdata('active_cust_id');
		$this->db->select("*");
		$this->db->from("invoice_details");
		if(isset($customer_id)){
			$where_arr=array('invoice_cust_id'=>$customer_id);
			
		}else{
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id']);
		}
		if($vendor!=""){
			$where_arr['invoice_beneficiary_name']=base64_decode($vendor);
		}
		if(!empty($where_Array)){
			$this->db->where($where_Array);
		} 
		$where_arr['invoice_status']="Paid";
		$this->db->where($where_arr);
		$res=$this->db->get();
		return  $this->db->last_query();
	}	
	function get_all_invoice_by_vendor($where_arr_r=array()){
		#Getting all invoice details from single table invoice_topaid
		$cust_data=$this->session->userdata('customer_login');
		$cust_id=$this->session->userdata('active_cust_id');
		$this->db->select("*,sum(invoice_amount) as totl_amount,invoice_beneficiary_name as inv_name,sum(invoice_amount) as totl_net_amount,(select sum(invoice_topaid) from invoice_details where invoice_status='Paid' and invoice_beneficiary_name=inv_name) as invoice_topaid,sum(invoice_discount) as invoice_discount,count(invoice_id) as total_invoice");
		$this->db->from("invoice_details");
		if(isset($cust_id)){
			$where_arr=array('invoice_cust_id'=>$cust_id); 
		}else{
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id']); 
		}
		if(!empty($where_arr_r)){
			$this->db->where($where_arr_r);
		}
		$this->db->where($where_arr);
		$this->db->group_by('invoice_beneficiary_name');
		$res=$this->db->get();
		//echo $this->db->last_query();die;
		return $res->result_array();
	}	
	function get_all_invoice_document($invoice_id=""){
		#Getting all invoice details from single table
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("*");
		$this->db->from("invoice_documents");
		$where_arr=array(); 
		$where_arr['status']='1';
		if($invoice_id!=""){
			$where_arr['invoice_id']=$invoice_id;
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		//echo $this->db->last_query();
		return $res->result_array();
	}
		function update_rejected_reason($invoice_id,$reason){		
		
		$this->db->query("UPDATE invoice_details SET invoice_status='Rejected' , reject_reason='$reason' WHERE invoice_id='$invoice_id'");
		
		return true;
	}
	function update_invoice_document($insert_data){ 
		$this->db->insert('invoice_documents',$insert_data);
	}
	function remove_invoice_document($rand_key,$doc_id){
		$insert_data=array('status'=>'2');
		$where_array=array('rand_key'=>$rand_key,'id'=>$doc_id);
		$this->db->where($where_array);
		$this->db->update('invoice_documents',$insert_data);
		
	}	
	function forgot_password_request($customer_data,$request_type=0){
		$ret_data=array();
		$salt_key=  uniqid(mt_rand(), true);
		$otp=  rand(0,9999);
		$ret_data[]=$salt_key;
		$ret_data[]=$otp;
		$insert_data=array(
		'cust_id '=>$customer_data['cust_id'],
		'created_date'=>date('Y-m-d H:i:s'),
		'expiry_hrs'=>$this->config->item('forgot_request_expiry_in_hours'),
		'salt_key'=>$salt_key,
		'status'=>'Sent',
		'otp'=>$otp,
		'ip_address'=>$this->input->ip_address(),
		'request_type'=>$request_type,
		);
		$this->db->insert('cust_forgot_password',$insert_data);
		return $ret_data;
	}
	
	
	function get_email_template($id){ 
		$this->db->select("*");
		$this->db->from("mail_templates");
		$where_arr=array('id'=>$id,'status'=>'Active'); 
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $res->row_array();
	}
	function check_otp($user_otp,$salt){ 
		$this->db->select("*");
		$this->db->from("cust_forgot_password");
		$where_arr=array('otp'=>$user_otp,'salt_key'=>$salt,'status'=>'Sent'); 
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $res;
	}
	function update_table($table_name,$data_update,$where_cond,$where_in=array()){ 
		$this->db->where($where_cond);
		if(!empty($where_in)){
			$this->db->where_in("invoice_id",$where_in);

		}
		$res =$this->db->update($table_name,$data_update);
		if($res){
			return true;
		}else{
			return false;
		}
	}
	function get_table($table_name,$where_cond){ 
		$this->db->where($where_cond);
		$res=$this->db->get($table_name);
		return $res;
	}
	  function get_DatabyCommon($table,$where,$options)
    {
       if($options!=''){
        $this->db->select($options);
        }
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->row();
    }
	function get_counts($table,$options,$where)
    {
       if($options!=''){
        $this->db->select($options);
        }
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->row_array();
    }
	
	 function get_column_count($table,$where)
    {
        
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->num_rows();
    }
	
	
	 function cust_logdetails($description,$module)
    {
		
		$ipaddress = "";
		if ($_SERVER['HTTP_CLIENT_IP'] != '')
		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		else if ($_SERVER['HTTP_X_FORWARDED_FOR'] != '')
		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else if ($_SERVER['HTTP_X_FORWARDED'] != '')
		$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		else if ($_SERVER['HTTP_FORWARDED_FOR'] != '')
		$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		else if ($_SERVER['HTTP_FORWARDED'] != '')
		$ipaddress = $_SERVER['HTTP_FORWARDED'];
		else if ($_SERVER['REMOTE_ADDR'] != '')
		$ipaddress = $_SERVER['REMOTE_ADDR'];
		else
		$ipaddress = $_SERVER['REMOTE_ADDR'];
	
	    $ip_address	= $ipaddress;
		$cust_data=$this->session->userdata('customer_login'); 
       $cust_id  = $cust_data['cust_id'];
		
        $array = array('activity_description'=>$description,
            'module'=>$module,'dateupdated'=>date('Y-m-d H:i:s'),'ip_address'=>$this->input->ip_address()); 
		if($cust_id!=""){
			$array['member_id']=$cust_id;
		}
		$where = array('cust_id'=>$cust_id);
		$userdetails = $this->get_DatabyCommon('customer_details',$where,'*');
		$logfile_path="logs/logs-".date("Y-m-d").".txt"; 	
		
         if(file_exists($logfile_path))	{	
		     $logfile = fopen($logfile_path, "a");
		 }else{
			 $logfile = fopen($logfile_path, "w");
		 }    
		$log_details = $userdetails->cust_name.'$'.$description.'$'.$module.'$'.date('Y-m-d H:i:s').'$'.'0'.'$'.$ip_address;
		 fwrite( $logfile, $log_details.PHP_EOL);
		 fclose( $logfile );
		
        //$this->db->insert('cust_log_details', $array);
    }
	function get_all_invoice_by_date_for_debit($where_arr_r=array()){
		#Getting all invoice details from single table  
		$cust_data=$this->session->userdata('customer_login');	 
		$cust_id  = $cust_data['cust_id'];
		$where_1='';
		$where_2='';
		if(!empty($where_arr_r)){
				$where_1="AND invoice_date>='".$where_arr_r['from_date']."' and invoice_date<='".$where_arr_r['to_date']."' ";
				$where_2="AND date_created>='".$where_arr_r['from_date']."' and date_created<='".$where_arr_r['to_date']."' ";
		}
		$res=$this->db->query("select * from (SELECT invoice_id as id,DATE_FORMAT(payment_datetime,'%Y-%m-%d')as date_conver, sum(invoice_amount)as amount1,'Debit' as t_type,count(invoice_id)as invoive_processed FROM `invoice_details` where invoice_status='Paid' and invoice_cust_id=".$cust_id." ".$where_1."  group by date_conver UNION select id as id ,DATE_FORMAT(date_created,'%Y-%m-%d')as date_conver, sum(amount)as amount1,'Credit' as t_type, 'N/A' as invoive_processed from cust_replenishment where cust_id=".$cust_id." ".$where_2." group by date_conver)as I where 1=1 ");
		
		   //return $res->result_array();
			return $this->db->last_query();
	}

	function verify_vendor_list($vendor_code){
		#Getting all invoice details from single table  
		$cust_data=$this->session->userdata('customer_login');	 
		$cust_id  = $cust_data['cust_id'];		
		$res=$this->db->query("SELECT vendor_code FROM vendor_details WHERE vendor_cust_id='$cust_id' AND vendor_code='$vendor_code';");
		return $num = $res->num_rows();		
	}
	 function insert_Common($table,$data)
    {
	    $this->db->insert($table,$data);
		return $this->db->insert_id();
    }

	function get_replenishments_due(){
		#Getting all invoice details from single table
		$cust_id=$this->session->userdata('active_cust_id');
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("t1.*,vendor_code");
		$this->db->from("invoice_details t1");
		$this->db->join("vendor_details t2",'t1.invoice_vendor_id=t2.vendor_id');
		if(isset($cust_id)){
			$where_arr=array('invoice_cust_id'=>$cust_id,'invoice_status'=>'Paid'); 
		}else{
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id'],'invoice_status'=>'Paid'); 
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $res->result_array();
	}
	
	function homepage_replenishments_due(){
		
		$cust_id=$this->session->userdata('active_cust_id');
		
		if($cust_id!='')
		{
			$res=$this->db->query('SELECT DATE_FORMAT(DATE_ADD(payment_datetime,INTERVAL invoice_deduction_days DAY), "%Y-%m-%d") as date ,sum(invoice_amount) as amount, DATEDIFF(DATE_ADD(payment_datetime,INTERVAL invoice_deduction_days DAY),CURDATE()) as RemDays  FROM `invoice_details` WHERE invoice_cust_id = '.$cust_id.' and paid_by_customer = "No"  and invoice_status="Paid" group by DATE_FORMAT(DATE_ADD(payment_datetime,INTERVAL invoice_deduction_days DAY), "%Y-%m-%d") ASC limit 2');
			return $res->result_array();
		}else{
			return null;
		}
		
	}
	
	function get_customer_name($cust_code){
		#Getting one customer name using customercode
		$this->db->select("cust_name");
		$this->db->from("customer_details");
		$where_arr=array('cust_user_code'=>$cust_code); 
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $res->row();
	}
 

 //added by sreeja on 04-12-2018
	function get_all_invoice_query($type="",$id="",$where_Array=array()){
		#Getting all invoice details from single table
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("t1.*,t2.rand_key");
		$this->db->from("invoice_details t1");
		$this->db->join("invoice_documents t2",'t2.invoice_id=t1.invoice_id and t2.status="1"','left');
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id']);
		if($type!=""&& $type!="Documents"){
			$where_arr['invoice_status']=$type;
		}else if($type=="Documents"){ 
			$this->db->where("t1.invoice_id not in(select(invoice_id) from invoice_documents where status<>'2')");
		}
		if($id!=""){
			$where_arr['t1.invoice_id']=$id;
		}
		
		if(!empty($where_Array)){
			$this->db->where($where_Array);
		}
		
		$this->db->where($where_arr);
		$res=$this->db->get();
		
		
		return $this->db->last_query();
		
	}
    function get_replenishments_due_query(){
		#Getting all invoice details from single table
		$cust_id=$this->session->userdata('active_cust_id');
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("t1.*,vendor_code");
		$this->db->from("invoice_details t1");
		$this->db->join("vendor_details t2",'t1.invoice_vendor_id=t2.vendor_id');
		if(isset($cust_id)){
			$where_arr=array('invoice_cust_id'=>$cust_id,'invoice_status'=>'Paid'); 
		}else{
		$where_arr=array('invoice_cust_id'=>$cust_data['cust_id'],'invoice_status'=>'Paid'); 
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		return $this->db->last_query();
	}

	function get_all_invoice_by_vendor_query($where_arr_r=array()){
		$where_date ="";
		$cust_data=$this->session->userdata('customer_login');
		$cust_id=$this->session->userdata('active_cust_id');
		/*$this->db->select("*,sum(invoice_amount) as totl_amount,invoice_beneficiary_name as inv_name,sum(invoice_amount) as totl_net_amount,(select sum(invoice_topaid) from invoice_details where invoice_status='Paid' and invoice_beneficiary_name=inv_name) as invoice_topaid,sum(invoice_discount) as invoice_discount,count(invoice_id) as total_invoice");
		$this->db->from("invoice_details");*/
		if(isset($cust_id)){
			$where_arr=array('invoice_cust_id'=>$cust_id); 
			$customer_id =$cust_id; 
		}else{
			$where_arr=array('invoice_cust_id'=>$cust_data['cust_id']); 
			$customer_id =$cust_data['cust_id']; 
		}
		/*if(!empty($where_arr_r)){
			$this->db->where($where_arr_r);
		}
		$this->db->where($where_arr);
		$this->db->group_by('invoice_beneficiary_name');
		$res=$this->db->get();*/
		if(!empty($where_arr_r['from_date'] )){
		$where_date=" AND payment_datetime>='".$where_arr_r['from_date']."'";
		
		}
		if(!empty($where_arr_r['to_date'] )){
		$where_date .=" AND payment_datetime<='".$where_arr_r['to_date']."'";
		
		}

		$res=$this->db->query("select * from (SELECT invoice_id ,invoice_status,payment_datetime,invoice_transactionid,invoice_cust_id,invoice_vendor_id,invoice_beneficiary_name, invoice_beneficiary_number, sum(invoice_amount) as invoice_amount,invoice_beneficiary_name as inv_name,sum(invoice_amount) as totl_net_amount,(select sum(invoice_topaid) from invoice_details where invoice_status='Paid' and invoice_beneficiary_name=inv_name) as invoice_topaid,sum(invoice_discount) as invoice_discount,count(invoice_id) as total_invoice FROM invoice_details where invoice_status ='Paid' AND invoice_cust_id=".$customer_id.$where_date."  group by invoice_vendor_id  )t where 1=1 ");	
		return $this->db->last_query();


	}
	function get_table_query($table_name,$where_cond){ 
		$this->db->where($where_cond);
		$res=$this->db->get($table_name);
		return $this->db->last_query();
	}
}
