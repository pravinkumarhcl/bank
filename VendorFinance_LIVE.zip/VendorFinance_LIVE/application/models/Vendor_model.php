<?php
class vendor_model extends CI_Model {

    function logincheck($email,$password)
    {
        $qr = $this->db->get_where('user_details',array('user_login_name'=>$email,'user_login_password'=>md5($password),'user_type !='=>'customer','user_status'=>1));        
        $res= $qr->row();     
        return $res;        
    }
    
    function deleteCommon($table,$where)
    {
        $this->db->where($where);
        $this->db->delete($table); 
    }
    function UpdateDatabyCommon($table,$where,$options)
    {
        $options  = $this->escape_array($options);
		
        $this->db->where($where);
        $this->db->update($table, $options);
	
    }
	

    function InsertCommon($table,$options)
    {
        $options  = $this->escape_array($options);
        $qr = $this->db->insert($table, $options);
        return $this->db->insert_id();
    }
       
    function get_DatabyCommonFull($table,$where,$options)
    {
        if($options!=''){
        $this->db->select($options);
        }
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->result();
    }
   
    function get_DatabyCommonFullwithgroupBy($table,$where,$options,$groupby)
    {
        if($options!=''){
        $this->db->select($options);
        }
        if($groupby!=''){
            $this->db->group_by($groupby);
        }
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);    
    
        return $qr->result();
    }
    
    
    function get_DatabyCommonwithOrderby($table,$where,$options,$orderby,$limit='') # made it by $limit='' because in controller 4 param only passsing. it should be optional
    {
        if($options!=''){
            $this->db->select($options);
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($orderby!=''){
            $this->db->order_by($orderby);
        }
        if($limit!=''){
            $this->db->limit($limit[1],$limit[0]);
        }
        $qr = $this->db->get($table); 
		
        return $qr->result();
    }
    
    function get_DatabyCommon($table,$where,$options)
    {
       if($options!=''){
        $this->db->select($options);
        }
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->row();
    }
    function get_DatabyCommonCount($table,$where)
    {
        
        if($where!=''){
        $this->db->where($where);
        }
        $qr = $this->db->get($table);                       
        return $qr->num_rows();
    }
    
    function escape_array($array){
        
        if($array!='*')
        {
            $posts = array();
            if(!empty($array)){
             foreach($array as $key => $value)
             {  
                if(is_numeric($value))
                {
                    $posts[$key] = $value;
                }
                else
                {
                    $posts[$key] = $value;
                    // $posts[$key] = mysql_escape_string($value);
                }
             }
            }
        }
        else {
            $posts = $array; 
        }
        
        
        return $posts;
    }  
    
    function logdetails($description,$module,$item_id="")
    {
		
		$error = "";
		$ipaddress = "";
		if ($_SERVER['HTTP_CLIENT_IP'] != '')
		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		else if ($_SERVER['HTTP_X_FORWARDED_FOR'] != '')
		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else if ($_SERVER['HTTP_X_FORWARDED'] != '')
		$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		else if ($_SERVER['HTTP_FORWARDED_FOR'] != '')
		$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		else if ($_SERVER['HTTP_FORWARDED'] != '')
		$ipaddress = $_SERVER['HTTP_FORWARDED'];
		else if ($_SERVER['REMOTE_ADDR'] != '')
		$ipaddress = $_SERVER['REMOTE_ADDR'];
		else
		$ipaddress = $_SERVER['REMOTE_ADDR'];
	
	    $ip_address	= $ipaddress;
		
        $member_sess = $this->session->userdata('member');
        $member_id  = $member_sess['member_id'];
		$where = array('user_id'=>$member_id);
		$userdetails = $this->get_DatabyCommon('user_details',$where,'*');
        $array = array('member_id'=>$member_id,'activity_description'=>$description,
            'module'=>$module,'dateupdated'=>date('Y-m-d H:i:s'),'item_id'=>$item_id,'ip_address'=>$ip_address);
			
		try {
				$logfile_path="application/logs/logs-".date("Y-m-d").".txt"; 	
				if(file_exists($logfile_path))	{	
					$logfile = fopen($logfile_path, "a");
				}else{
					$logfile = fopen($logfile_path, "w");
				}				
				$log_details = $userdetails->user_name .'$'.$description.'$'.$module.'$'.date('Y-m-d H:i:s').'$'.$item_id.'$'.$ip_address;
				fwrite($logfile, $log_details.PHP_EOL);
			}
			catch (Exception $e) {
			$error =  "Error (File: ".$e->getFile().", line ".
			$e->getLine()."): ".$e->getMessage();
			}	
			
						
					/* 	
					   Sending mail notification to admin
					   
					    $to_email = ERROR_NOTIFICATION_EMAIL;
					    $subject="Error found in updating LogDetails at ".SITE_NAME;
						$message .="Sir,";
						$message .= 'Error found in updating Log Details . <br/>';
						$message .= $error.'<br/>';
						$res = vfemail($to_email,$subject,$message,'');
						*/

      //  $this->InsertCommon('log_details', $array);
    }	
	
    function validateUpdatedElements($previousDataInDB,$currentlyUpdatedData)
    {
        $previousDataInDB = (array)$previousDataInDB;
        $currentlyUpdatedData = (array)$currentlyUpdatedData;
        $changed ='';
        $arrayKey = array_keys($currentlyUpdatedData); 

        foreach($previousDataInDB as $key=>$previous)
        {
            if(!in_array($key, $arrayKey))
            {
                unset($previousDataInDB[$key]);
            }
        }
        foreach($previousDataInDB as $key=>$previous)
        {
            if($previous!=$currentlyUpdatedData[$key])
            {
                $changed.= $key.',';
            }
        }
        $trimed = trim(str_replace('_',' ',$changed),',');

        return $trimed;
    }
	function masterlist($insert_opt)
	{
		$result = $this->session->userdata('member');
		$member_id = $result['member_id'];
		$data = array('created_by'=>$member_id);
		$this->db->set($data);
		$this->db->insert('rates_master',$insert_opt);
	}
	
	
	function customer_reports()
	{
			$this->load->dbutil();
			$delimiter = ",";
			$newline = "\r\n";
			$query = "SELECT cust_id AS sno,cust_no AS customercode,cust_name AS customername,cust_loan_limit as loanamount,SUM(paid_amount) AS paidamount,(cust_loan_limit-SUM(paid_amount))  AS balanceamount,SUM(pending_amount) AS pendingamount
			FROM(SELECT c.cust_id,c.cust_user_code AS cust_no,c.cust_name AS cust_name,
			IFNULL(c.cust_loan_limit,0) AS cust_loan_limit,
			IFNULL(CASE WHEN i.invoice_status='Paid' THEN SUM(IFNULL(i.invoice_amount,0)) END,0) AS paid_amount,
			IFNULL(CASE WHEN i.invoice_status='Pending' THEN SUM(IFNULL(i.invoice_amount,0)) END,0) AS pending_amount
			FROM customer_details AS c
			LEFT JOIN vendor_details AS v ON v.vendor_cust_id=c.cust_id
			LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
			WHERE 1=1 $invoice_date
			GROUP BY c.cust_id,i.invoice_status)report group by cust_id";
			$result = $this->db->query($query);
			$data = $this->dbutil->csv_from_result($result, $delimiter, $newline);
			return $data;
	}
	function vendor_reports($tempid) 
	{
		$cust_id = $tempid;
		$this->load->dbutil();
		$delimiter =",";
		$newline ="\r\n";			
		$query = "SELECT vendor_name AS vendorname,vendor_code as vendorcode,vendor_company_name AS companyname,SUM(discount) AS discount,SUM(paid_amount) AS paidamount,SUM(pending_amount) AS pendingamount,SUM(invoice_net) AS i
		FROM(SELECT v.vendor_id,v.vendor_name,v.vendor_code,v.vendor_company_name,v.vendor_phone,v.vendor_email,
        SUM(IFNULL(i.invoice_discount,0)) discount,		
		SUM(IFNULL(CASE WHEN i.invoice_status='Paid' AND i.invoice_topaid>0 THEN IFNULL(i.invoice_topaid,0)  WHEN i.invoice_status='Paid' THEN  IFNULL(i.invoice_amount,0) END,0)) AS paid_amount,
		SUM(IFNULL(CASE WHEN i.invoice_status='Pending' AND i.invoice_topaid>0 THEN IFNULL(i.invoice_topaid,0) WHEN i.invoice_status='Pending' THEN  IFNULL(i.invoice_amount,0) END,0)) AS pending_amount,
		SUM(IFNULL(i.invoice_net,0)) AS invoice_net
		FROM vendor_details AS v 
		LEFT JOIN invoice_details AS i ON v.vendor_id=i.invoice_vendor_id
		WHERE v.vendor_cust_id = $cust_id  $invoice_date
		GROUP BY v.vendor_id,i.invoice_status)report GROUP BY vendor_id";		
		$res = $this->db->query($query);
		$data_res = $this->dbutil->csv_from_result($res,$delimiter,$newline);
		return $data_res;
	}
	
	function invoice_reports($id)
	{
		$vendor_id = $id;
		$this->load->dbutil();
		$delimiter =",";
		$newline ="\r\n";
		$query ="SELECT 
		invoice_beneficiary_name AS beneficiaryname,invoice_beneficiary_number AS beneficiarynumber,invoice_ifsc_code AS ifsccode,(CASE WHEN invoice_status='Paid' THEN invoice_transactionid ELSE '-' END) AS transactionid,invoice_number AS invoicenumber,invoice_amount As invoiceamount,invoice_discount AS discount,invoice_topaid AS topaidamount,invoice_deduction_days AS deductiondays,invoice_net as net_gross,invoice_status As status
		FROM invoice_details WHERE invoice_vendor_id = ".$vendor_id;		
		$res = $this->db->query($query);
		$data_res = $this->dbutil->csv_from_result($res,$delimiter,$newline);
		return $data_res;
	}	
		function get_all_invoice_document($invoice_id=""){
		#Getting all invoice details from single table
		$cust_data=$this->session->userdata('customer_login');
		$this->db->select("*");
		$this->db->from("invoice_documents");
		$where_arr=array(); 
		$where_arr['status']='1';
		if($invoice_id!=""){
			$where_arr['invoice_id']=$invoice_id;
		}
		$this->db->where($where_arr);
		$res=$this->db->get();
		//echo $this->db->last_query();
		return $res->result_array();
	}
	function get_table($table_name,$where_cond){ 
		$this->db->where($where_cond);
		$res=$this->db->get($table_name);
		return $res;
	}
	function update_sub_companies($cust_id,$status){ 
		$where_cond=array('cust_id'=>$cust_id);
		 $res=$this->get_table('customer_details',$where_cond);
		 $data_set=$res->result_array();
		 foreach($data_set as $data_ind){
			$this->UpdateDatabyCommon('user_details',array('cust_id'=>$data_ind['cust_id']),array('user_status'=>$status));
			}
		$this->UpdateDatabyCommon('customer_details',array('cust_referral_id'=>$cust_id),array('cust_status'=>$status));

	}
	function get_uploaded_invoice($ids=array()){ 
		$where_cond=array('t1.status'=>1);
		 $this->db->select('*');
		 $this->db->from('invoice_csv_uploads t1');
		 $this->db->join('customer_details t2', 't2.cust_id=t1.customer_id');
		 if(!empty($ids)){
			$this->db->where_in('t1.id',$ids); 
		 }
		 $this->db->where($where_cond);
		 $this->db->group_by('t1.id'); 
		 $res=$this->db->get();
		 //echo $this->db->last_query();exit();
		 $data_set=$res->result_array();
	 return $data_set;
	}
function check_forgot_email($uname){
	
		#For Temp purpose password is not encrypt
		$this->db->select("*");
		$this->db->from("user_details");
		$where_arr=array('user_type !='=>'customer','user_login_name'=>$uname,'user_status'=>1); 
		$this->db->where($where_arr);
		$res=$this->db->get(); 
		return $res;
	}
function forgot_password_request($customer_data,$request_type=0){
		$ret_data=array();
		$salt_key=  uniqid(mt_rand(), true);
		$otp=  rand(0,99999);
		$ret_data[]=$salt_key;
		$ret_data[]=$otp;
		$insert_data=array(
		'cust_id '=>$customer_data['cust_id'],
		'created_date'=>date('Y-m-d H:i:s'),
		'expiry_hrs'=>$this->config->item('forgot_request_expiry_in_hours'),
		'salt_key'=>$salt_key,
		'status'=>($request_type==1?'Completed':'Sent'),
		'otp'=>$otp,
		'ip_address'=>$this->input->ip_address(),
		'request_type'=>$request_type,
		);
		$this->db->insert('cust_forgot_password',$insert_data);
		return $ret_data;
	}
	
}