<?php
class invoice_loan_limit extends CI_Model {

 function customerBasedLoanLimit($invoice_array,$cust_id)
	{
			if(is_array($invoice_array))
			{
				$invoice_array=implode("','",$invoice_array);			
			}
			
			$flag=0;			
			$active_cust_type=$this->session->userdata('active_cust_type');			
			if($active_cust_type=='sub')
			{				
				$active_parent_id=$this->session->userdata('active_parent_id');
				$parent_customer=$active_parent_id;				
						
			}else{
				$parent_customer=$cust_id;
			}
			
			//Total Balance Customer Based
			$query = $this->db->query("SELECT 
			cust_weekly_loan_limit,
			cust_monthly_loan_limit,
			cust_loan_limit,
			IFNULL(SUM(r.amount),0) AS repl_amount,
			IFNULL(SUM(r.amount),0)+cust_loan_limit AS total_bal_amount,
			IFNULL(interest_rate,0) AS  interest_rate,vendor_company_limit
			FROM 
			customer_details AS c
			LEFT JOIN cust_replenishment AS r ON r.cust_id=c.cust_id
			WHERE c.cust_id='$parent_customer'");			
			$cust_loan_limits=$query->result_array();
			$cust_loan_limit=$cust_loan_limits[0];
			$interest_rate=$cust_loan_limit['interest_rate'];
			$vendor_company_limit=$cust_loan_limit['vendor_company_limit'];
			/* if($interest_rate=='')
			{
				$interest_rate=0;
			} */
			//Total Payed amount Customer and subsidiary

			$query = $this->db->query("SELECT IFNULL(SUM(weekly_paid),0) AS weekly_paid,IFNULL(SUM(monthly_paid),0) AS monthly_paid,IFNULL(SUM(total_paid),0) AS total_paid FROM(
			
				
				SELECT 
				invoice_topaid AS total_paid
				,CASE WHEN (YEARWEEK(DATE(status_updated_datetime),1) = YEARWEEK(CURDATE(),1)) THEN invoice_topaid ELSE 0 END AS weekly_paid
				,CASE WHEN MONTH(status_updated_datetime) = MONTH(CURDATE()) AND YEAR(status_updated_datetime) = YEAR(CURDATE()) THEN invoice_topaid ELSE 0 END AS monthly_paid
				FROM invoice_details
				WHERE invoice_cust_id IN(SELECT cust_id FROM customer_details WHERE cust_referral_id='$parent_customer' OR cust_id='$cust_id') AND invoice_id NOT IN('$invoice_array') AND invoice_status IN('Verified','Paid','Approved') 
			
			)paid");
			
			$paid_amts_all=$query->result_array();
			$paid_amt_all=$paid_amts_all['0'];
			
			$query = $this->db->query("SELECT ROUND(SUM(invoice_amount)-SUM(
			CASE WHEN invoice_deduction_days<=90 AND UPPER(t1.invoice_net)='NET' THEN (((three_mclr+strategic_premium_rate+risk_premium_rate)
			*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN invoice_deduction_days<=180 AND UPPER(t1.invoice_net)='NET' THEN (((six_mclr+strategic_premium_rate+risk_premium_rate)*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN invoice_deduction_days<=270 AND UPPER(t1.invoice_net)='NET' THEN (((nine_mclr+strategic_premium_rate+risk_premium_rate)
			*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN UPPER(t1.invoice_net)='NET'  THEN 
			(((mclr_twelve+strategic_premium_rate+risk_premium_rate)*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			ELSE 0  END
			),2) AS payment

			FROM invoice_details AS t1
			LEFT JOIN customer_details AS c ON c.cust_id=t1.invoice_cust_id
			WHERE  invoice_id IN('$invoice_array')");
			
			$total_inv_amts=$query->result_array();
			$total_inv_amt=$total_inv_amts['0'];
			
			//Payment for current invoice + already (paid + approved) invoice
			$paid_cur_inv_amt=($total_inv_amt['payment']+$paid_amt_all['total_paid']);	
			$paid_cur_inv_amt_month=($total_inv_amt['payment']+$paid_amt_all['monthly_paid']);
			$paid_cur_inv_amt_week=($total_inv_amt['payment']+$paid_amt_all['weekly_paid']);
				
			// Weekly limit checking for main company also subsidiary companyecho 
			if($cust_loan_limit['cust_weekly_loan_limit']<$paid_cur_inv_amt_week)
			{
				$flag=3;
			}
			
			// Monthly limit checking for main company also subsidiary company			
			if($cust_loan_limit['cust_monthly_loan_limit']<$paid_cur_inv_amt_month)
			{
				$flag=2;
			}
			// Total limit checking for main company also subsidiary company
			if($cust_loan_limit['total_bal_amount']<$paid_cur_inv_amt)
			{
				$flag=1;
			}	
			
			$query = $this->db->query("SELECT IFNULL(ROUND(SUM(invoice_amount)-SUM(
			CASE WHEN invoice_deduction_days<=90 AND UPPER(t1.invoice_net)='NET' THEN (((three_mclr+strategic_premium_rate+risk_premium_rate)
			*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN invoice_deduction_days<=180 AND UPPER(t1.invoice_net)='NET' THEN (((six_mclr+strategic_premium_rate+risk_premium_rate)*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN invoice_deduction_days<=270 AND UPPER(t1.invoice_net)='NET' THEN (((nine_mclr+strategic_premium_rate+risk_premium_rate)
			*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			WHEN UPPER(t1.invoice_net)='NET'  THEN 
			(((mclr_twelve+strategic_premium_rate+risk_premium_rate)*(t1.invoice_amount*invoice_deduction_days)/365)/100)
			ELSE 0  END
			),2),0) AS payment
			FROM invoice_details AS t1
			LEFT JOIN customer_details AS c ON c.cust_id=t1.invoice_cust_id
			LEFT JOIN vendor_details AS v ON vendor_cust_id=t1.invoice_cust_id AND v.vendor_id=t1.invoice_vendor_id
			WHERE  invoice_id IN('$invoice_array') 
			AND is_subsidiary='Y'");
		
			$paid_amts_subsidiary_to_pay=$query->result_array();
			$subsidiary_to_pay=$paid_amts_subsidiary_to_pay['0'];
			
			if($subsidiary_to_pay['payment']>0)
			{			
					//Subsidiary paid amount and calculations
					$query = $this->db->query("SELECT IFNULL(SUM(weekly_paid),0) AS weekly_paid,
					IFNULL(SUM(monthly_paid),0) AS monthly_paid,IFNULL(SUM(total_paid),0) AS total_paid FROM(
					SELECT 
					invoice_topaid AS total_paid
					,CASE WHEN (YEARWEEK(DATE(status_updated_datetime),1) = YEARWEEK(CURDATE(),1)) 
					THEN invoice_topaid ELSE 0 END AS weekly_paid
					,CASE WHEN MONTH(status_updated_datetime) = MONTH(CURDATE()) 
					AND YEAR(status_updated_datetime) = YEAR(CURDATE()) 
					THEN invoice_topaid ELSE 0 END AS monthly_paid
					FROM invoice_details t1
					LEFT JOIN customer_details AS c ON c.cust_id=t1.invoice_cust_id
					LEFT JOIN vendor_details AS v ON vendor_cust_id=t1.invoice_cust_id AND v.vendor_id=t1.invoice_vendor_id
					WHERE c.cust_id='$cust_id' AND invoice_id NOT IN('$invoice_array') AND invoice_status IN('Verified','Paid','Approved')
					 AND is_subsidiary='Y'
					)paid");
				$paid_amts_subsidiary=$query->result_array();
				$paid_amt_subsidiary=$paid_amts_subsidiary['0'];				
				
				$subsidiary_total_pay=$paid_amt_subsidiary['total_paid']+$subsidiary_to_pay['payment'];				
				$subsidiary_month_pay=$paid_amt_subsidiary['monthly_paid']+$subsidiary_to_pay['payment'];				
				$subsidiary_week_pay=$paid_amt_subsidiary['weekly_paid']+$subsidiary_to_pay['payment'];				
				
				$total_bal_amount_subsidiary=(($cust_loan_limit['total_bal_amount']/100)*$vendor_company_limit);
				$cust_monthly_loan_limit_subsidiary=(($cust_loan_limit['cust_monthly_loan_limit']/100)*$vendor_company_limit);
				$paid_cur_inv_amt_week_subsidiary=(($cust_loan_limit['cust_weekly_loan_limit']/100)*$vendor_company_limit);
											
				// Weekly limit checking for subsidiary company				
				if($paid_cur_inv_amt_week_subsidiary<$subsidiary_week_pay)
				{
					$flag=3;
				}		
				// Monthly limit checking for subsidiary company
				if($cust_monthly_loan_limit_subsidiary<$subsidiary_month_pay)
				{
					$flag=2;
				}	
				// Total limit checking for subsidiary company
				if($total_bal_amount_subsidiary<$subsidiary_total_pay)
				{
					$flag=1;
				}
			}
					
		//return $paid_cur_inv_amt_week_subsidiary.'/'.$cust_loan_limit['cust_weekly_loan_limit'].'/'.$paid_cur_inv_amt_week;
		
		
		return $flag;
	}
   function limitcheckforcustomers($cust_id,$topaid)
        {
            $flag = 0;
            $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$cust_id),'*');
            
            $cust_current_loan_balance = $customerDetails->cust_current_loan_balance;
            $actualWeekLimit = $customerDetails->cust_weekly_loan_limit;
            $actualMonthLimit = $customerDetails->cust_monthly_loan_limit;
            $TotalLoanLimit = $customerDetails->cust_loan_limit;
            
            $getSumofWeek = $this->dashboard_model->getweeklylimit($cust_id);            
            $weekamount = $getSumofWeek[0]->week_amount;
            $weekamount = $weekamount+$topaid;
			
            $getSumofMonth = $this->dashboard_model->getmonthlylimit($cust_id);
            $monthamount = $getSumofMonth[0]->month_amount;
            $monthamount = $monthamount+$topaid;			
           			
            if($cust_current_loan_balance<$topaid)
			{
				 $flag = 1;
			}
            if($actualWeekLimit<=$weekamount)
            {
                $flag = 2;
            }
            if($actualMonthLimit<=$monthamount)
            {
                $flag = 3;
            }           
            
            return $flag;
        }     
}