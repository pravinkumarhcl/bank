<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Sessiondata{
    var $CI;

    function __construct()
	{
		
        $this->CI =& get_instance();
		$this->CI->load->library('session');
    }
    function initializeData() 
	{
			$active_cust_id=$this->CI->session->userdata('active_cust_id');
			$active_cust_type=$this->CI->session->userdata('active_cust_type');
			
			$customer_login=$this->CI->session->userdata('customer_login');
			if(isset($customer_login['cust_id']))
			{
				$active_cust_id=$customer_login['cust_id'];
				$active_cust_type=$customer_login['cust_type'];
			}
			
		   if($active_cust_id!='')
		   {
				$active_cust=$active_cust_id;	
				$this->CI->load->model('dashboard_model');	
				if($active_cust_type=='sub')
				{
					$CustomerData = $this->CI->dashboard_model->GetCustomerDataBySub($active_cust);
				}else{
					$CustomerData = $this->CI->dashboard_model->GetCustomerData($active_cust);
				}				
				
				
		   }		
		$this->CI->session->set_userdata('CustomerData',$CustomerData); 		
    }
}
?>