<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bankadmin extends CI_Controller {

	public function __construct()
        {
            /*Site Settings loaded in construct for non-repeat model code in every function*/
            parent::__construct();
            $this->load->library('excel');
            $this->load->helper('url');
            $this->load->helper('vfemail');
            $this->data['siteSettings'] = $this->vendor_model->get_DatabyCommon('site_settings',array('id'=>1),'*');
			$this->active_user="";
			   $active_cust_id=$this->session->userdata('active_cust_id');
			   if($active_cust_id!='')
			   {
				 $active_cust_id=$active_cust_id;
				 $this->active_user=$active_cust_id;
				 $this->active_invoice_user=" AND invoice_cust_id=$active_cust_id";
				 $this->active_vendor_user=" AND vendor_cust_id=$active_cust_id";
			   } 
			   $this->load->model('customer/customer_model');
        }   
        public function TestMail()
        {
			vfemail('jk@icmindia.com','test subject','test message','');
		}
        /* public function Sendmail($to,$subject,$message)
        {
           
             $configMail = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.googlemail.com',
                'smtp_port' => 465,
                'smtp_user' => 'developermailphp@gmail.com',
                'smtp_pass' => 'phptostart',
                'mailtype'  => 'html', 
                'charset'   => 'iso-8859-1'
            );
            $this->load->library('email', $configMail);
            $this->email->set_newline("\r\n");
            $from = 'developermailphp@gmail.com';
            
            $this->email->initialize();
            $this->email->from($from,'Vendor Finance');
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($message);
            $result = $this->email->send();
            return $result;
        }   
         */
        public function referralabilityforcustomers($cust_id)
        {
            if($cust_id!='' && $cust_id!='0')
            {
                $where = array('cust_referral_id'=>'0','cust_id !='=>$cust_id);
            }
            else {
                $where = array('cust_referral_id'=>'0');
            }
            $referralcodes = $this->vendor_model->get_DatabyCommonwithOrderby('customer_details',$where,array('cust_id','cust_user_code','cust_name'),' cust_name asc ');
            return $referralcodes;
        }
        public function IsloggedIn()
        {
            /*This function validates member logged valid or not. If not logged in page will redirect to login page
             *              */
            $result = $this->session->userdata('member');
            $member_id = $result['member_id'];
            if($member_id!='' && $member_id!=false)
            {
                $returnID = $member_id;
            }
            else
            {
                redirect(ADMINBASEURL.'bankadmin/index','refresh');
            }
            return $returnID; 
        }
	        
        public function index()
        {
		
            /*This function validates member logged valid or not. If logged in page will redirect to dashboard page*/
            $result = $this->session->userdata('member');
            $member_id = $result['member_id'];
            if($member_id=='')
            {
                $data['siteSettings'] = $this->data['siteSettings'];
                
                $this->load->view('admin/login',$data);
            }
            else{
                redirect(ADMINBASEURL.'bankadmin/dashboard','refresh');
            }
          
        }        
        public function loginfunction()
        {
            /*login validation and member data set in session as logged in*/
            
            $data['siteSettings'] = $this->data['siteSettings'];
                    
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            //$this->form_validation->set_rules('email', 'email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'password', 'required');
            
            $email    = $this->input->post('email');
            $password = $this->input->post('password');
            
            if ($this->form_validation->run()=='TRUE') {
                $userdetails = $this->vendor_model->logincheck($email,$password);
                if(strtolower($userdetails->user_login_name)==strtolower($email) && $userdetails->user_login_password==md5($password))
                {
                   $memberdata = array('member_id'=>$userdetails->user_id,'user_type'=>$userdetails->user_type,'loggedin'=>true);
                   $this->session->set_userdata('member',$memberdata);                   
                   $log_message = $this->vendor_model->logdetails($userdetails->user_name.' logged in','login',$userdetails->user_id);
                   redirect(ADMINBASEURL.'bankadmin/customerlist','refresh');
                }
                else {
                    
                    $this->session->set_flashdata('error', ERROR_A101);
                    redirect(ADMINBASEURL.'bankadmin/index','refresh');
                }
            }
            else{
                $this->load->view('admin/login',$data);
            }
        }      
		public function clearCustomer()
        {
			$this->IsloggedIn();
			if($this->session->userdata("active_cust_type")=="parent"){
				$this->session->unset_userdata('active_cust_id_re_list'); 
				$this->session->unset_userdata('active_parent_id_for_re_list'); 
				$this->session->unset_userdata('active_cust_type_list'); 
			}	
				$this->session->unset_userdata('active_cust_id');            
				$this->session->unset_userdata('active_cust_type'); 				
				redirect(ADMINBASEURL.'bankadmin/customerlist','refresh');
		} 
		public function activateCustomer()
        {
			$this->IsloggedIn();			
			$cust_id= $this->input->get('cust_id');
			
			if($cust_id!='')
			{
				$where = array('cust_id'=>$cust_id);				
				$userdetails = $this->dashboard_model->GetCustomerData($cust_id);
				
				$this->session->set_userdata('active_cust_id_re_list',$cust_id);				
				$this->session->set_userdata('active_cust_id',$cust_id);				
				$this->session->userdata('active_cust_id');
				$this->session->set_userdata('active_cust_type',$userdetails['cust_type']);
				$this->session->set_userdata('active_cust_type_list',$userdetails['cust_type']);
				$this->session->set_userdata('active_parent_id_for_re_list',$userdetails['cust_referral_id']);				
				$this->session->set_userdata('active_parent_id',$userdetails['cust_referral_id']);
				$where_cond=array('cust_referral_id'=>$cust_id);
 				$res_sub=$this->vendor_model->get_table('customer_details',$where_cond);	
				$sub_company_data=$res_sub->result_array();
				$this->session->set_userdata('sub_company_data',$sub_company_data);

				redirect(ADMINBASEURL.'bankadmin/dashboard','refresh');
			}else{
				redirect(ADMINBASEURL.'bankadmin/customerlist','refresh');
			}           
		}
        public function dashboard()
        {
            /*DashBoard acts as short review of all elements includes in this project*/           
			$this->load->model('vendor_model');
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/dashboard';
            $data['siteSettings'] = $this->data['siteSettings'];                  
            $data['dashboard'] = $arrayElements;  
			$data['filter_from']=$this->input->post('filter_from');
			$data['filter_to']=$this->input->post('filter_to');						
            $data['InvoiceReport'] = $this->dashboard_model->InvoiceStatusReport($data['filter_from'],$data['filter_to']);
			$cust_id=$this->session->userdata('active_cust_id');
			
			$data['RatesMaster'] = $this->dashboard_model->get_MCLR_Active($cust_id);				
			if(strtotime($this->input->post('filter_from')) > strtotime($this->input->post('filter_to'))){				
		
				 $this->session->set_flashdata('error', ERROR_A106);
			}else{
			$this->session->set_flashdata('error', '');	
			}
            $CustomerData=$this->session->userdata("CustomerData"); 
			
			if(isset($CustomerData['cust_name']) && $CustomerData['cust_name']!=''){
			#get sub companies details
			$child_data=array();
			if($CustomerData['cust_type']=='parent'){
				$where_array_sub=array(
					'cust_referral_id'=>$result['cust_id']
				);
			}else{
				$where_array_sub=array(
					'cust_referral_id'=>$CustomerData['cust_referral_id'],
					'cust_id !='=>$result['cust_id'],
				);
				$parent_loan_usage=$this->dashboard_model->GetCustomerData($CustomerData['cust_referral_id']);
				$data['parent_loan_usage']=$parent_loan_usage;
				 
			}
			
			$array_sub_record=$this->customer_model->get_table('customer_details',$where_array_sub);
			$array_sub_data=$array_sub_record->result_array(); 
			if(!empty($array_sub_data)){
				foreach($array_sub_data as $array_sub_in_data){
				#get loan limits and weekly paid invoices
				$child_data[$array_sub_in_data['cust_id']] = $this->dashboard_model->GetCustomerData($array_sub_in_data['cust_id']);
				}
			}  
			#sum amounts of sub companies paid 
			$weeklyPainIvoice=0;
			$monthlyPainIvoice=0;
			$cust_loan_used=0; 
			foreach($child_data as $child_data_in){                      
					$weeklyPainIvoice +=$child_data_in["weeklyPainIvoice"];
					$monthlyPainIvoice +=$child_data_in["monthlyPainIvoice"];
					$cust_loan_used +=str_replace(',','',$child_data_in["cust_loan_used"]);
			}
			//$data['child_data']=$child_data;
			$data['sub_weeklyPainIvoice']=$weeklyPainIvoice;
			$data['sub_monthlyPainIvoice']=$monthlyPainIvoice;
			$data['sub_cust_loan_used']=$cust_loan_used;
			 }
			$rep_dues=$this->customer_model->get_replenishments_due();
			
			foreach( $rep_dues as $rep_dues_details){
					$gross_amount_rate=0;
					#FORMULA FOR GROSS = PERCENT*INV_AMOUNT*NUMBER_OF_DAYS/365;
					$gross_amount_rate=$CustomerData['interest_rate']*$rep_dues_details['invoice_amount']*($rep_dues_details['invoice_deduction_days']/365);
					$gross_amount_rate=$gross_amount_rate/100;				
						 
					 $Receivable_amount +=(strtolower($rep_dues_details['invoice_net'])=='net'?$rep_dues_details['invoice_amount']: $gross_amount_rate+$rep_dues_details['invoice_amount']); 
			}
			
			 $data['Receivable_amount']=$Receivable_amount;
			$data['receivableData']=$this->customer_model->homepage_replenishments_due($cust_id);			
            $this->load->view('admin/template',$data);
        }        
        public function logout()
        {
            /*Logout function will destory the current user session*/
            $result = $this->session->userdata('member'); 
			if(!empty($result)){
            $member_id = $result['member_id'];
            $where = array('user_id'=>$member_id);
			
            $userdetails = $this->vendor_model->get_DatabyCommon('user_details',$where,'*');
			
				$this->vendor_model->logdetails($userdetails->user_name.' logged out','login');
            }
            $this->session->sess_destroy();
            redirect(ADMINBASEURL.'bankadmin/index','refresh');
        }
        
	
		public function userManagement(){			
			$this->IsloggedIn();					
            $data['page'] = 'admin/pages/userList';      
	$data['active_cust_id'] = $this->session->userdata('active_cust_id');     		
            $data['siteSettings'] = $this->data['siteSettings'];          
            $this->load->view('admin/template',$data);			
		}
		
	
		public function userForm(){
				$this->IsloggedIn();	
				$data['siteSettings'] = $this->data['siteSettings'];	

				$id=$this->input->get('id');    

				if($id!='' && is_numeric($id))
				{          
				$data['title'] = 'Edit';
				$data['userdetails'] = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$id),'*');		

				}
				else {
				$data['title'] = 'Add';
				}

				$data['page'] = 'admin/pages/addUser';			
				$this->load->view('admin/template',$data);			
			
		}
		public function submitUser(){
			$this->IsloggedIn();	
			
			$message ="";
			$data['siteSettings'] = $this->data['siteSettings'];	
			
			$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('user_name', 'User Name', 'required');
            #$this->form_validation->set_rules('user_login_name', 'Login Name', 'required');           
            $this->form_validation->set_rules('user_type', 'User Type', 'required');
            $this->form_validation->set_rules('user_phone', 'Phone Number', 'required');
            $this->form_validation->set_rules('user_email', 'Email Address', 'required|valid_email|callback_check_email');
			$this->form_validation->set_rules('user_department', 'User Department', 'required');
			$this->form_validation->set_rules('user_designation', 'User Designation', 'required');
			$department=$this->input->post('user_department');
			$designation=$this->input->post('user_designation');
			$user_id = $this->input->post('id');
			
            if ($this->form_validation->run()=='TRUE') {
					$result = $this->session->userdata('member'); 
					if(!empty($result)){
					$member_id = $result['member_id'];
					}
					$insert['user_name']   = $this->input->post('user_name');
					$insert['user_login_name']  = $this->input->post('user_email');					
			 	    $insert['user_type']  = $this->input->post('user_type');
					$insert['user_phone']  = $this->input->post('user_phone');
					$insert['user_email']  = $this->input->post('user_email');
					$insert['user_department']  = $this->input->post('user_department');
					$insert['user_designation']  = $this->input->post('user_designation');
					$insert['created_by']  = $member_id;
					$insert['created_date']  = date('Y-m-d H:i:s');
					  
					if($user_id=='' ){
						$data['title'] = 'Add';
						$temp_password = 'admin123';
						  $password = $this->passwordGenerator(8);
						$insert['user_login_password']   = md5($password);
						//Activity log
						$this->vendor_model->logdetails('New user '.$insert['user_name'].' of type '.$insert['user_type'].'  added ','user',$user_id);					
						$user_id =  $this->vendor_model->InsertCommon('user_details',$insert);
						$text = INFO_A103;
						$email_data=array(
						'user_name'=>$insert['user_email'],
						'customer_name'=>$insert['user_name'],
						'role_name'=>ucfirst($insert['user_type']),
						'password'=>$password,
						'customer_url'=>ADMINBASEURL."bankadmin/"
						);
						$this->send_email_by_template(7,$email_data);
				/* $to_email = $this->input->post('user_email');
					 $subject="From ".FROM_EMAILR_NAME." Account details for ".$username."at ".SITE_NAME;
						$message .=$insert['user_name'].' ,<br/>';
						$message .= 'Your account at '.SITE_NAME.' has been activated.'.'<br/>';
						$message .= 'you will be able to log in at '.ADMINBASEURL.' in the future using:'.'<br/>';
						$message .= "Username : ".$insert['user_login_name'].'<br/>';
						$message .= "Password : ".$insert['user_login_password'].'<br/>';
					  
					$res = vfemail($to_email,$subject,$message,'');
					if($res){
					 $user_id =  $this->vendor_model->InsertCommon('user_details',$insert);
					 $text = INFO_A103;
					}else{
						$this->session->set_flashdata('Error', ERROR_A106);
						
					}*/
					}
					else{
						
						$data['title'] = 'Edit';
						$temp_password = 'admin123';
						$insert['user_login_password']   = md5($temp_password);
						$previous = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$user_id),'*'); 
						$changedItems = $this->vendor_model->validateUpdatedElements($previous,$insert);
					
                    if($changedItems!='')
                    {
                        $this->vendor_model->logdetails($previous->user_name.' '.$changedItems.' details updated ','user',$user_id);
                    }
						$where = array('user_id'=>$user_id); 
						$this->vendor_model->UpdateDatabyCommon('user_details',$where,$insert);	
						$user = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$user_id),'*');	
						$code = '{USER_NAME}';	
						$text = str_replace($code,$user->user_name,INFO_A102);
					}
					$data['userdetails'] = $insert;    
					$data['page'] = 'admin/pages/addUser';
					$this->session->set_flashdata('Success', $text);
                redirect(ADMINBASEURL.'bankadmin/userManagement','refresh');
                $this->load->view('admin/template',$data);
			}
			else{
				if($user_id=='' ){
						  $data['title'] = 'Add';
				}else{
					
					 $data['title'] = 'Edit';
				}
			
				$insert->user_name  = $this->input->post('user_name');
					$insert->user_login_name  = $this->input->post('user_login_name');					
			 	    $insert->user_type = $this->input->post('user_type');
					$insert->user_phone  = $this->input->post('user_phone');
					$insert->user_email  = $this->input->post('user_email');
					$insert->user_department  = $this->input->post('user_department');
					$insert->user_designation  = $this->input->post('user_designation');
					$insert->created_by  = $member_id;
					$insert->created_date = date('Y-m-d H:i:s');
				$insert->user_id       =$user_id;
				$data['userdetails'] = $insert;    
				$data['page'] = 'admin/pages/addUser';
                $data['siteSettings'] = $this->data['siteSettings'];
					
                $this->load->view('admin/template',$data);
				
			}
			
		}
        public function siteSettings()
        {
            /*Site related settings included in this function*/
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/settings';
            $data['siteSettings'] = $this->data['siteSettings'];
            $this->load->view('admin/template',$data);
        }
        
        public function metafunction()
        {
            /*Site related settings validation and update in datebase with site_settings table included in this function*/
            $this->IsloggedIn();
            
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('site_name', 'site name', 'required');
            $this->form_validation->set_rules('site_url', 'site url', 'required');
            $this->form_validation->set_rules('meta_title', 'meta title', 'required');
            $this->form_validation->set_rules('meta_description', 'meta description', 'required');
            $this->form_validation->set_rules('meta_keywords', 'meta keywords', 'required');
            $this->form_validation->set_rules('copy_rights', 'copy rights', 'required');
            
            if ($this->form_validation->run()=='TRUE') {
            
                $arrayUpdate['site_url']  = $this->input->post('site_url');
                $arrayUpdate['site_name']  = $this->input->post('site_name');
                $arrayUpdate['meta_title']  = $this->input->post('meta_title');
                $arrayUpdate['meta_description']  = $this->input->post('meta_description');
                $arrayUpdate['meta_keywords']  = $this->input->post('meta_keywords');
                $arrayUpdate['copy_rights']  = $this->input->post('copy_rights');
                
                //Activity log
                $changedItems = $this->vendor_model->validateUpdatedElements($this->data['siteSettings'],$arrayUpdate);
                $this->vendor_model->UpdateDatabyCommon('site_settings',array('id'=>1),$arrayUpdate);                
                if($changedItems!='')
                {
                    $this->vendor_model->logdetails('Site settings '.$changedItems.' changed ','site_settings');
                }
                $this->session->set_flashdata('Success', INFO_A101);
                redirect(ADMINBASEURL.'bankadmin/siteSettings','refresh');
            }
            else {
                $data['page'] = 'admin/pages/settings';
                $data['siteSettings'] = $this->data['siteSettings'];
                $this->load->view('admin/template',$data);
            }
        }
        
        function callEmailTemplate($id,$stringTochange,$replaceArray)
        {
            $mailTemplate = $this->vendor_model->get_DatabyCommon('mail_templates',array('id'=>$id),'*'); 
                    
            $mailMessage = html_entity_decode($mailTemplate->message);
            $message = str_replace('\n','',$mailMessage);
            $message = str_replace('\r','',$message);
            $message = str_replace($stringTochange, $replaceArray, $message);
            
            $array[] = $mailTemplate->subject;
            $array[] = $message;
            
            return $array;
        }       
        
        public function check_sum($code)
        {   
            $mclr_percent              = $this->input->post('mclr_percent');
            $strategic_premium_rate    = $this->input->post('strategic_premium_rate');
            $risk_premium_rate         = $this->input->post('risk_premium_rate');
            
            $interstRate = $mclr_percent+$strategic_premium_rate+$risk_premium_rate;
            
            if($interstRate>=100)
            {
                $this->form_validation->set_message('check_sum', ERROR_A102);
                return false;
            }
            else
            {
                return true;
            }
        }
        
        public function check_code($code)
        {   
            /*Unique validation for cust_code in customer_details table while 
              insert or update cust_code from customer_details table*/
            
            $cust_id = $this->input->post('id');
            $user_code  = $this->input->post('user_code');
            if($cust_id!='' && is_numeric($cust_id))
            {
                $where = array('cust_user_code'=>$user_code, 'cust_id !='=>$cust_id);
            }
            else {
                $where = array('cust_user_code'=>$user_code);
            }
            $count = $this->vendor_model->get_DatabyCommon('customer_details',$where,'count(*) as existcount');
            if($count->existcount==0)
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('check_code', ERROR_A103);
                return false; 
            }
        }
        
        public function check_referral_code($code)
        {   
            /*Unique validation for cust_code in customer_details table while 
              insert or update cust_code from customer_details table*/
            
            $cust_id = $this->input->post('id');
            $user_code  = $this->input->post('referral_code');
            if($user_code!='')
            {
                if($cust_id!='' && is_numeric($cust_id))
                {
                    $where = array('cust_user_code'=>$user_code, 'cust_id !='=>$cust_id);
                }
                else {
                    $where = array('cust_user_code'=>$user_code);
                }
                $custdetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
                if(count($custdetails)>0)
                {

                    return true;
                }
                else
                {
                    $this->form_validation->set_message('check_referral_code', ERROR_A104);
                    return false; 
                }
            }
            else {
                return true;
            }
        }  
	public function check_email($email)
        {   
           #Check Duplicate Email Address
            
            $cust_id = $this->input->post('id');
            $email  = $this->input->post('email');
            if($cust_id!='')
            {
                $where = array('cust_email'=>$email, 'cust_id !='=>$cust_id);
            }
            else {
                $where = array('cust_email'=>$email);
            }
            $count = $this->vendor_model->get_DatabyCommon('customer_details',$where,'count(*) as existcount');
            if($count->existcount==0)
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('check_email', ERROR_A105);
                return false; 
            }
        }
        
        function addInterestRate($cust_id,$interest_rate,$type)
        {
            $member_id = $this->IsloggedIn();
            $now['cust_mclr'] = $this->input->post('mclr');
            $now['mclr_percent'] = $this->input->post('mclr_percent');
            $now['strategic_premium_rate'] = $this->input->post('strategic_premium_rate');
            $now['risk_premium_rate'] = $this->input->post('risk_premium_rate');
            $now['interest_rate'] = $this->input->post('interest_rate');            
                         
            $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$cust_id),'cust_mclr,mclr_percent,strategic_premium_rate,risk_premium_rate,interest_rate');
            $customerDetailsDB = (array)$customerDetails;
            
            $changed ='';
            $arrayKey = array_keys($now);  
            foreach($customerDetailsDB as $key=>$previous)
            {
                if($now[$key]==$previous)
                {
                    unset($now[$key]);
                }
            }
            
            $insertarray = array();
            if(count($now)>0)
            {
                $where = array('cust_rate_cust_id'=>$cust_id);
                $insertarray['cust_rate_mclr'] = $this->input->post('mclr');
                $insertarray['cust_rate_mclr_percent'] = $this->input->post('mclr_percent');
                $insertarray['cust_rate_strategic_premium'] = $this->input->post('strategic_premium_rate');
                $insertarray['cust_rate_risk_premium'] = $this->input->post('risk_premium_rate');
                $insertarray['cust_interest_rate'] = $insertarray['cust_rate_mclr_percent']+$insertarray['cust_rate_strategic_premium']+$insertarray['cust_rate_risk_premium'];
                $insertarray['modified_by'] = $member_id;
                $insertarray['modified_date'] = date('Y-m-d H:i:s');
                $insertarray['status'] = 'Pending';
                if($type=='update')
                {
                    $updatenew = $this->vendor_model->UpdateDatabyCommon('customer_interest_rate',$where,$insertarray);
                }
                else if($type=='insert') {
                    $insertarray['cust_rate_cust_id'] = $cust_id;
                    $insertnew = $this->vendor_model->InsertCommon('customer_interest_rate',$where,$insertarray);
                }
            }
        }
        
        function verifyInterestRate($cust_id)
        {
           $where = array('cust_rate_cust_id' => $cust_id);
           $interestRate = $this->vendor_model->get_DatabyCommonwithOrderby('customer_interest_rate',$where,'*','created_date desc',array(0,1));
            
           $details = $interestRate[0];
           if($details->status=='Pending')
           {
               $displayInterestPending = $details;
           }
           
           return $displayInterestPending; 
        }
        
        function customerform()
        {
			$id=$this->input->get('id');
		
            $res = $this->IsloggedIn();
            /*Admin can add a new customer with form elements*/
			
            if($id!='' && is_numeric($id))
            {
                //$data['balance'] = $this->balanceCalculations($id);
                $data['displayInterestPending'] = $this->verifyInterestRate($id);
                $data['title'] = 'Edit';
                $data['customerdetails'] = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$id),'*');			
                $referralCodeArray = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$data['customerdetails']->cust_referral_id),'*'); 
                $data['referral_code'] = $referralCodeArray->cust_user_code;
            }
            else {
                $data['title'] = 'Add';
            }
			 
			
			$data['ratesMasterActive'] = $this->dashboard_model->get_RatesMasterActive();
            $data['page'] = 'admin/pages/addnewCustomer';            
            $data['referralCodes'] = $this->referralabilityforcustomers($id);
            $data['siteSettings'] = $this->data['siteSettings'];
            $this->load->view('admin/template',$data);
        }        
        function CustomerVerification()
        {
			error_reporting(0);
            /*Add a new customer validation for each fields in form and query to save in database*/
            $member_id = $this->IsloggedIn();
            $data['siteSettings'] = $this->data['siteSettings'];          
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('name', 'customer name', 'required');
            $this->form_validation->set_rules('phone', 'Office number', 'required');
            $this->form_validation->set_rules('email', 'email address', 'required|valid_email|callback_check_email');
            $this->form_validation->set_rules('account_no', 'account number', 'required');
            $this->form_validation->set_rules('ifsc_code', 'ISFC code', 'required');
            $this->form_validation->set_rules('user_code', 'customer code', 'required|callback_check_code');
            $this->form_validation->set_rules('address1', 'address1', 'required');
            $this->form_validation->set_rules('city', 'city', 'required');
            
			$this->form_validation->set_rules('financing_date', 'Financing Date', 'required');           
			$this->form_validation->set_rules('three_mclr', '3 Months MCLR', 'required|numeric'); 
			$this->form_validation->set_rules('six_mclr', '6 Months MCLR', 'required|numeric'); 
			$this->form_validation->set_rules('nine_mclr', '9 Months MCLR', 'required|numeric'); 
			$this->form_validation->set_rules('mclr_twelve', '1 Year MCLR', 'required|numeric'); 
			$this->form_validation->set_rules('strategic_premium_rate', 'Strategic Premium Rate', 'required|numeric'); 
			$this->form_validation->set_rules('risk_premium_rate', 'Risk Premium Rate', 'required|numeric');
			$this->form_validation->set_rules('contact_name', 'Point of Contact Name', 'required');
			$this->form_validation->set_rules('mobile', 'Mobile number', 'required');
			
			
			$referral_code='';
			$cust_type='Parent Company';
			$cust_id = $this->input->post('id');
			
			if($cust_type=='Parent Company')				
			{
				$this->form_validation->set_rules('loan_limit', 'loan limit', 'required|numeric|greater_than[0]');
				$this->form_validation->set_rules('weekly_loan_limit', 'weekly loan limit', 'required|numeric|greater_than[0]');
				$this->form_validation->set_rules('monthly_loan_limit', 'monthly loan limit', 'required|numeric|greater_than[0]');
				$this->form_validation->set_rules('vendor_company_limit', 'vendor company limit', 'required|numeric|greater_than[0]');
				
				/* 
				if($this->input->post('mclr')=='6')
				{
					$this->form_validation->set_rules('six_mclr', '6mclr percent', 'required|numeric');
				}elseif($this->input->post('mclr')=='9')
				{
					$this->form_validation->set_rules('nine_mclr', '9mclr percent', 'required|numeric');
				}elseif($this->input->post('mclr')=='12')
				{
					$this->form_validation->set_rules('mclr_twelve', '12mclr percent', 'required|numeric');
				}else{
					$this->form_validation->set_rules('three_mclr', '3mclr percent', 'required|numeric');
				}	 		
				$this->form_validation->set_rules('strategic_premium_rate', 'strategic premium rate', 'required|numeric');
				$this->form_validation->set_rules('risk_premium_rate', 'risk premium rate', 'required|numeric');				
				$this->form_validation->set_rules('interest_rate', 'risk premium rate', 'callback_check_sum');				
				*/	
			}			
			
            $data['balance'] = $this->balanceCalculations($id);
			$data['ratesMasterActive'] = $this->dashboard_model->get_RatesMasterActive();
           
		   if ($this->form_validation->run()=='TRUE') {
			   
                $insert['cust_name']   			= $this->input->post('name');
                $insert['cust_phone']  			= $this->input->post('phone');
                $insert['cust_email']  			= $this->input->post('email');
                $insert['cust_account_no']		= $this->input->post('account_no');
                $insert['cust_ifsc_code']		= $this->input->post('ifsc_code');
                $insert['cust_user_code']		= $this->input->post('user_code');
                $insert['cust_address1']		= $this->input->post('address1');
                $insert['cust_address2']		= $this->input->post('address2');
                $insert['cust_city']			= $this->input->post('city');
                $insert['cust_state']			= $this->input->post('state');
                $insert['cust_contact_name']	= $this->input->post('contact_name');
                $insert['cust_mobile']			= $this->input->post('mobile');
				
				
				if($referral_code!='' && $referral_code>0)
				{
					$customerlist = $this->dashboard_model->referralCompanyByCodeToSave($referral_code);					
				    $insert['cust_monthly_loan_limit']   = $customerlist['cust_monthly_loan_limit']/100*40;
					$insert['cust_weekly_loan_limit']    = $customerlist['cust_weekly_loan_limit']/100*40;
					$insert['cust_loan_limit']   = $customerlist['cust_loan_limit']/100*40;
				    $insert['cust_mclr']   = $customerlist['cust_mclr'];				
					$insert['strategic_premium_rate']   = $customerlist['strategic_premium_rate'];
					$insert['risk_premium_rate']   = $customerlist['risk_premium_rate'];
				}else{		
                    		
					$insert['vendor_company_limit']     = $this->input->post('vendor_company_limit');
					$insert['cust_monthly_loan_limit']     = $this->input->post('monthly_loan_limit');
					$insert['cust_weekly_loan_limit']    = $this->input->post('weekly_loan_limit');
					$insert['cust_loan_limit']   = $this->input->post('loan_limit');				
					$insert['cust_mclr']              = $this->input->post('mclr');
					$insert['strategic_premium_rate']    = $this->input->post('strategic_premium_rate');
					$insert['risk_premium_rate']   = $this->input->post('risk_premium_rate');
				}     
				
                $insert['cust_mclr']=0;
				$insert['financing_date']     = $this->input->post('financing_date');
				$insert['three_mclr']     = $this->input->post('three_mclr');
				$insert['six_mclr']     = $this->input->post('six_mclr');
				$insert['nine_mclr']     = $this->input->post('nine_mclr');
				$insert['mclr_twelve']     = $this->input->post('mclr_twelve');
				
				$insert_mclr['mclr_3']=$insert['three_mclr'];
				$insert_mclr['mclr_6']=$insert['six_mclr'];
				$insert_mclr['mclr_9']=$insert['nine_mclr'];
				$insert_mclr['mclr_12']=$insert['mclr_twelve'];
				$insert_mclr['strategic']=$insert['strategic_premium_rate'];
				$insert_mclr['risk']=$insert['risk_premium_rate'];
				$insert_mclr['financing_date']=$insert['financing_date'];
				
                $insert['cust_created_by']   = $member_id;
                $insert['cust_created_date'] = date('Y-m-d H:i:s');               
                              
                if($cust_id=='')
                {
					
                    /* if( $insert['cust_mclr']==12)
					{
						$insert['mclr_percent']= $data['ratesMasterActive']['0']['12mclr'];
					}
				    if( $insert['cust_mclr']==9)
					{
						$insert['mclr_percent']= $data['ratesMasterActive']['0']['9mclr'];
					}
				    if( $insert['cust_mclr']==6)
					{
						$insert['mclr_percent']= $data['ratesMasterActive']['0']['6mclr'];
					}
				    if( $insert['cust_mclr']==3)
					{
						$insert['mclr_percent']= $data['ratesMasterActive']['0']['6mclr'];
					}  */
					
					if($referral_code!='' && $referral_code>0)
					{
						$insert['cust_type']='sub';
					}else{
						$insert['cust_type']='parent';
					}
					
				   $insert['cust_referral_id'] = $referral_code;					
				   $insert['cust_current_loan_balance'] = $insert['cust_loan_limit'];
 				   $insert['strategic_premium_rate']=$data['ratesMasterActive']['0']['strategic_premium'];
 				   $insert['risk_premium_rate']=$data['ratesMasterActive']['0']['risk_premium'];
				   
				   $interest_rate=$insert['strategic_premium_rate']+$insert['risk_premium_rate'];
				   $insert['interest_rate']=$interest_rate;
				   
                    $insert['cust_status'] = '1';
                    //Activity log
                    $this->vendor_model->logdetails('New '.$insert['cust_name'].' customer added ','customer');
					
					$result = $this->session->userdata('member');
                    $member_id = $result['member_id'];
					
                    $customer_id =  $this->vendor_model->InsertCommon('customer_details',$insert);
                   	
					$insert_mclr['cus_id']=$customer_id;
					$insert_mclr['created_by']=$member_id;
					
					$this->vendor_model->InsertCommon('mclr_history',$insert_mclr);
					 
                    $usertable =array();
                    
                    $password = $this->passwordGenerator(8);
					$password = 'admin123';
                    $usertable['user_login_password'] = md5($password);
                    $usertable['user_type'] = 'customer';
                    $usertable['cust_id'] = $customer_id;
                    $usertable['user_login_name'] = $insert['cust_email']; 
                    $usertable['user_email'] = $insert['cust_email']; 
                    $usertable['user_phone'] = $insert['cust_phone'];  
                    $usertable['user_name'] = $insert['cust_name'];  
                    $usertable['user_status'] = '1';
                    $usertable['created_date'] = date('Y-m-d H:i:s');
                    $usertable['created_by'] = $member_id;
                  
                    $stringTochange = array('#USERNAME#','#PASSWORD#','#FIRSTNAME#');
                    $replaceArray  = array($insert['cust_email'],$password,$insert['cust_name']);
					$email_data=array(
					'user_name'=>$insert['cust_email'],
					'customer_name'=>$insert['cust_name'],
					'password'=>$password,
					'customer_url'=>CUSTOMERBASEURL."customer/"
					);
					$this->send_email_by_template(1,$email_data);
                    #$this->Sendmail($insert['cust_email'], $returnArray[0],$returnArray[1]);
                //    $returnArray = $this->callEmailTemplate('1',$stringTochange,$replaceArray); 
                    $this->vendor_model->InsertCommon('user_details',$usertable);  
                    $this->addInterestRate($customer_id,$interest_rate,'insert');
                    $text = INFO_C209;
					
					$user_folder = str_replace('{CUST_CODE}',$insert['cust_user_code'],UPLOADS_CUST);
					if (!is_dir($user_folder)) {
						mkdir($user_folder, 0777, TRUE);						
						mkdir(str_replace('{CUST_CODE}',$insert['cust_user_code'],UPLOADS_CUST_INVOICE), 0777, TRUE);
						mkdir(str_replace('{CUST_CODE}',$insert['cust_user_code'],UPLOADS_CUST_DOC), 0777, TRUE);
						mkdir(str_replace('{CUST_CODE}',$insert['cust_user_code'],UPLOADS_CUST_INV_DONE), 0777, TRUE);
						mkdir(str_replace('{CUST_CODE}',$insert['cust_user_code'],UPLOADS_CUST_INV_ERROR), 0777, TRUE);
					}
                }
                else
                {	
			   /*Updating sub customer details if parent customer details changed.*/
                  
				   if($referral_code==0 || $referral_code==''){	
					$sub_customer_list =array();				   
			       	$parent_customer = $this->dashboard_model->referralCompanyByCodeToSave($cust_id);						
				    $sub_customer_list[$parent_customer['cust_id']] = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_referral_id'=>$parent_customer['cust_id']),'*'); 					
					foreach($sub_customer_list as $key=>$sub_customer){
				    $sub_customer->cust_monthly_loan_limit = $parent_customer['cust_monthly_loan_limit']/100*40;
					$sub_customer->cust_weekly_loan_limit =$parent_customer['cust_weekly_loan_limit']/100*40;
					$sub_customer->cust_loan_limit = $parent_customer['cust_loan_limit']/100*40;				
					$sub_customer->cust_mclr  = $parent_customer['cust_mclr'] ;
					$sub_customer->strategic_premium_rate    = $parent_customer['strategic_premium_rate'] ;
					$sub_customer->risk_premium_rate  = $parent_customer['risk_premium_rate'] ;				 
				    $where = array('cust_id'=>$sub_customer->cust_id); 					
                    $this->vendor_model->UpdateDatabyCommon('customer_details',$where,$sub_customer);
					}
					
				   }
			
					unset($insert['cust_user_code']);				
                    //Activity log
                    $previous = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$cust_id),'*'); 
					
					
					
					/* if($insert['cust_mclr']!=$previous->cust_mclr)
					 {
						if( $insert['cust_mclr']==12)
						{
							$insert['mclr_percent']= $data['ratesMasterActive']['0']['12mclr'];
						}
						if( $insert['cust_mclr']==9)
						{
							$insert['mclr_percent']= $data['ratesMasterActive']['0']['9mclr'];
						}
						if( $insert['cust_mclr']==6)
						{
							$insert['mclr_percent']= $data['ratesMasterActive']['0']['6mclr'];
						}
						if( $insert['cust_mclr']==3)
						{
							$insert['mclr_percent']= $data['ratesMasterActive']['0']['6mclr'];
						}
						
						$insert['strategic_premium_rate']=$data['ratesMasterActive']['0']['strategic_premium'];
						$insert['risk_premium_rate']=$data['ratesMasterActive']['0']['risk_premium'];
						
						$interest_rate=$insert['mclr_percent']+$insert['strategic_premium_rate']+$insert['risk_premium_rate'];
						$insert['interest_rate']=$interest_rate;
					 }else{
						 unset($insert['cust_mclr']);
						 unset($insert['mclr_percent']);
						 unset($insert['strategic_premium_rate']);
						 unset($insert['risk_premium_rate']);
						 unset($insert['interest_rate']);
					 } */
					 
					/* if($referral_code=='' || $referral_code=='0')
					{
						$customerlist = $this->dashboard_model->referralCompanyByCodeToSave($cust_id);					
						$insert_sub['cust_monthly_loan_limit']   = $customerlist['cust_monthly_loan_limit'];
						$insert_sub['cust_weekly_loan_limit']    = $customerlist['cust_weekly_loan_limit'];
						$insert_sub['cust_loan_limit']   = $customerlist['cust_loan_limit'];
						$insert_sub['cust_mclr']   = $customerlist['cust_mclr'];
						$insert_sub['strategic_premium_rate']   = $customerlist['strategic_premium_rate'];
						$insert_sub['risk_premium_rate']   = $customerlist['risk_premium_rate'];
						if($insert['cust_loan_limit']!=$previous->cust_loan_limit)
						{						
							$diff_amount=($insert['cust_loan_limit']-$previous->cust_loan_limit);
							
							$insert_sub['cust_current_loan_balance'] = (($previous->cust_current_loan_balance)+($diff_amount));	
						}
					} */ 
					
					if($insert['cust_loan_limit']!=$previous->cust_loan_limit)
					{						
						$diff_amount=($insert['cust_loan_limit']-$previous->cust_loan_limit);
						
						$insert['cust_current_loan_balance'] = (($previous->cust_current_loan_balance)+($diff_amount));	
					}
					
					
					if($referral_code!='' && $referral_code>0)
					{
						$insert['cust_type']='sub';
					}else{
						$insert['cust_type']='parent';
					}
                    $changedItems = $this->vendor_model->validateUpdatedElements($previous,$insert);
					
                    if($changedItems!='')
                    {
                        $this->vendor_model->logdetails($previous->cust_name.' '.$changedItems.' details updated ','customer');
                    }
					$insert['cust_modified_by']=$member_id;
					$insert['cust_modified_date']=date('Y-m-d H:i:s');
					$usertable =array();
                    $result = $this->session->userdata('member');                
                    
                    $usertable['user_login_name'] = $insert['cust_email']; 
                    $usertable['user_email'] = $insert['cust_email']; 
                    $usertable['user_phone'] = $insert['cust_phone'];  
                    $usertable['user_name'] = $insert['cust_name'];            
					$usertable['modified_date'] = date('Y-m-d H:i:s'); 
					$usertable['modifed_by'] = $member_id; 
                    $where = array('cust_id'=>$cust_id); 
					
                    $this->vendor_model->UpdateDatabyCommon('customer_details',$where,$insert);
					$this->vendor_model->UpdateDatabyCommon('user_details',$where,$usertable);
					
					if($insert['three_mclr']!=$previous->three_mclr OR $insert['six_mclr']!=$previous->six_mclr OR $insert['nine_mclr']!=$previous->nine_mclr OR $insert['mclr_twelve']!=$previous->mclr_twelve OR $insert['strategic_premium_rate']!=$previous->strategic_premium_rate OR $insert['risk_premium_rate']!=$previous->risk_premium_rate OR $insert['financing_date']!=$previous->financing_date)
					{
						$insert_mclr['cus_id']=$cust_id;
						$insert_mclr['created_by']=$member_id;					
						$this->vendor_model->InsertCommon('mclr_history',$insert_mclr);
					}
					
					
					$text = INFO_C209;
                    $this->addInterestRate($cust_id,$interest_rate,'update');
                }
                $this->session->set_flashdata('Success', $text);
                redirect(ADMINBASEURL.'bankadmin/customerlist','refresh');
            }
            else {
                
                if($cust_id!='' && is_numeric($cust_id))
                {
                    $data['title'] = 'Edit';
                }
                else {
                    $data['title'] = 'Add';
                   
                }
                $insert->cust_name   = $this->input->post('name');
                $insert->cust_phone  = $this->input->post('phone');
                $insert->cust_email  = $this->input->post('email');
                $insert->cust_account_no   = $this->input->post('account_no');
                $insert->cust_ifsc_code    = $this->input->post('ifsc_code');
                $insert->cust_user_code    = $this->input->post('user_code');
                $insert->cust_created_by   = $member_id;
                $insert->cust_address1     = $this->input->post('address1');
                $insert->cust_address2     = $this->input->post('address2');
                $insert->cust_city    = $this->input->post('city');
                $insert->cust_state   = $this->input->post('state');
                $insert->cust_contact_name   = $this->input->post('contact_name');
                $insert->cust_mobile   = $this->input->post('mobile');
               // $insert->cust_type   = $this->input->post('cust_type');
				//$insert->cust_referral_id   = $this->input->post('referral_code');
				$insert->financing_date   = $this->input->post('financing_date');
				$insert->three_mclr   = $this->input->post('three_mclr');
				$insert->six_mclr   = $this->input->post('six_mclr');
				$insert->nine_mclr   = $this->input->post('nine_mclr');
				$insert->mclr_twelve   = $this->input->post('mclr_twelve');
        /*        if($referral_code!='')				
				{
					$insert->referral_code   = $this->input->post('referral_code');
				} */
				$referral_code='';
				if($referral_code=='')				
				{
					$insert->cust_loan_limit     = $this->input->post('loan_limit');
					$insert->cust_weekly_loan_limit    = $this->input->post('weekly_loan_limit');
					$insert->cust_monthly_loan_limit   = $this->input->post('monthly_loan_limit');
					$insert->vendor_company_limit   = $this->input->post('vendor_company_limit');
				  
				   if($this->input->post('mclr')=='6')
					{	
						$insert->six_mclr     = $this->input->post('six_mclr');
					}elseif($this->input->post('mclr')=='9')
					{
						$insert->nine_mclr     = $this->input->post('nine_mclr');
					}elseif($this->input->post('mclr')=='12')
					{
						$insert->mclr_twelve     = $this->input->post('mclr_twelve');
					}else{
						$insert->three_mclr     = $this->input->post('three_mclr');
					}
					
					$insert->cust_mclr     = $this->input->post('mclr');
					$insert->mclr_percent  = $this->input->post('mclr_percent');
					$insert->risk_premium_rate    = $this->input->post('risk_premium_rate');
					$insert->strategic_premium_rate   = $this->input->post('strategic_premium_rate');
					$insert->cust_id       = $cust_id;
					$insert->interest_rate = $this->input->post('mclr_percent')+$this->input->post('risk_premium_rate')+$this->input->post('strategic_premium_rate');
				}
                //$data['referral_code'] = $this->input->post('referral_code');     

           
                $data['customerdetails'] = $insert;    
                $data['page'] = 'admin/pages/addnewCustomer';
                $data['referralCodes'] = $this->referralabilityforcustomers($cust_id);
                $this->load->view('admin/template',$data);
            }
        }
        public function referralCompanyByCode()
        {
			$this->IsloggedIn();
			$cust_id=$this->input->post('cust_id');
			if($cust_id!='')
			{
				$customerlist = $this->dashboard_model->referralCompanyByCode($cust_id);
				echo json_encode($customerlist);
			}else{
				echo '';
			}
		}
        public function customerlist()
        {
			
            /*Get data of entire constomers from customer_details table and listed in below page*/
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/customerlist'; 
			$data['active_cust_id'] = $this->session->userdata('active_cust_id');
		  
            $data['customerlist'] = $this->vendor_model->get_DatabyCommonwithOrderby('customer_details',$where,'*','cust_name asc');
             $data['siteSettings'] = $this->data['siteSettings'];
            $this->load->view('admin/template',$data);
        }
        
        public function invoiceDelete()
        {
            /*Delete option for single invoice record from invoice_details via ajax*/
            $id = $this->input->post('del_id');
            $this->vendor_model->deleteCommon('invoice_details',array('invoice_id'=>$id));
            
            //Activity log
            $this->vendor_model->logdetails('#'.$id.' Invoice deleted','invoice');
            
            $this->session->set_flashdata('Success', INFO_C401);
            echo "Success";
        }
        
        public function Customerdelete()
        {
            /*Delete option for single customer record from customer_details via ajax*/
            $id = $this->input->post('del_id');
           /* $this->vendor_model->deleteCommon('customer_details',array('cust_id'=>$id));*/
		    $this->vendor_model->UpdateDatabyCommon('customer_details',array('cust_id'=>$id),array('cust_status'=>0)); 
            $this->vendor_model->UpdateDatabyCommon('user_details',array('cust_id'=>$id),array('user_status'=>0)); 
            //Activity log
            $this->vendor_model->logdetails('#'.$id.' Customer disabled','customer');
            
            $this->session->set_flashdata('Success', INFO_C208);
            echo "Success";
        }
		
		
        public function Userdelete(){
			 $id = $this->input->post('del_id');
			 $user = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$id));
            $this->vendor_model->deleteCommon('user_details',array('user_id'=>$id));            
            //Activity log
            $this->vendor_model->logdetails('#'.$id.' User deleted','user');
            $code = '{USER_NAME}';
            $this->session->set_flashdata('Success', str_replace($code,$user->user_name,INFO_A104));           
            echo "Success";
		}
		public function CustomerDisable(){
			$id = $this->input->post('disable_cus_id');
              $user = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$id));
            $this->vendor_model->UpdateDatabyCommon('customer_details',array('cust_id'=>$id),array('cust_status'=>0));  
            $this->vendor_model->UpdateDatabyCommon('user_details',array('cust_id'=>$id),array('user_status'=>0));
			$this->vendor_model->update_sub_companies($id,0);   			
            $this->vendor_model->logdetails('#'.$id.' Customer disabled','user');

            $code = '{USER_NAME}';
            $this->session->set_flashdata('Success', str_replace($code,$user->user_name,INFO_A105));
            echo "Success";
			
		}
		public function CustomerEnable(){
			$id = $this->input->post('enable_cus_id');
           $user = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$id));
            $this->vendor_model->UpdateDatabyCommon('customer_details',array('cust_id'=>$id),array('cust_status'=>1)); 
				$this->vendor_model->UpdateDatabyCommon('user_details',array('cust_id'=>$id),array('user_status'=>1));   
				$this->vendor_model->update_sub_companies($id,1);			
            $this->vendor_model->logdetails('#'.$id.' Customer enabled','user');
            $code = '{USER_NAME}';
            $this->session->set_flashdata('Success', str_replace($code,$user->user_name,INFO_C212));
            echo "Success";
			
		}
		 public function Userdisable(){
			 
			 $id = $this->input->post('disable_id');
             $user = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$id));
            $this->vendor_model->UpdateDatabyCommon('user_details',array('user_id'=>$id),array('user_status'=>0));  
 $this->vendor_model->UpdateDatabyCommon('customer_details',array('cust_id'=>$user->cust_id),array('cust_status'=>0)); 			
            $this->vendor_model->logdetails('#'.$id.' User disabled','user');
            $code = '{USER_NAME}';
            $this->session->set_flashdata('Success', str_replace($code,$user->user_name,INFO_C211));
            echo "Success";
		}
		public function Userenable(){
			 
			 $id = $this->input->post('enable_id');
			 $user = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$id));
            $this->vendor_model->UpdateDatabyCommon('user_details',array('user_id'=>$id),array('user_status'=>1));   
 $this->vendor_model->UpdateDatabyCommon('customer_details',array('cust_id'=>$user->cust_id),array('cust_status'=>1)); 			
            $this->vendor_model->logdetails('#'.$id.' User enabled','user');
            $code = '{USER_NAME}';
            $this->session->set_flashdata('Success', str_replace($code,$user->user_name,INFO_A106));            
            echo "Success";
		}
		
        public function Vendordelete()
        {
            /*Delete option for single vendor record from vendor_details via ajax*/
            $id = $this->input->post('del_id');
            $this->vendor_model->deleteCommon('vendor_details',array('vendor_id'=>$id));
            
            //Activity log
            $this->vendor_model->logdetails('#'.$id.' Vendor deleted','vendor');
            
            $this->session->set_flashdata('Success', INFO_A301);
            echo "Success";
        }
        
        public function repaydelete()
        {
            /*Delete option for single vendor record from vendor_details via ajax*/
            $id = $this->input->post('del_id');
            $this->vendor_model->deleteCommon('cust_replenishment',array('id'=>$id));
            
            //Activity log
            $this->vendor_model->logdetails('#'.$id.' replenishment deleted','vendor');
            
            $this->session->set_flashdata('Success',INFO_A601 );
            echo "Success";
        }
		/*returns data to User Profile Page*/
         public function userView($user_id)
        {
            $this->IsloggedIn();          
            $data['page'] = 'admin/pages/userView';
			
            $data['user_details'] = $this->vendor_model->get_DatabyCommon('user_details',array('user_id'=>$user_id),"*");			
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['user_id'] = $cust_id;           
            $this->load->view('admin/template',$data);
        }
        public function customerview($cust_id)
        {
            $this->IsloggedIn();
            /*Page displays the information of single customer details*/
            $data['page'] = 'admin/pages/customerview';
			
            $data['customerdetails'] = $this->dashboard_model->GetCustemerByID($cust_id);			
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['cust_id'] = $cust_id;
            $data['balance'] = $this->balanceCalculations($cust_id);
            $this->load->view('admin/template',$data);
        }
        
        public function passwordGenerator($limit)
        {
            /*passwordGenerator for customers. This function will call while admin add a new customer*/
            $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890|@';
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < $limit; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            return implode($pass); 
        }
        
        public function vendorform()
        {    
            /*Vendor form for axdding vendors by admin*/
            $this->IsloggedIn();
            $cust_id = $this->input->get('id');
            $vid = $this->input->get('vid');
            $data['title'] = 'Add';
            $data['page'] = 'admin/pages/addvendor';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['cust_id'] = $cust_id;
            if($vid==''){
                $data['title'] = 'Add';
            }
            else {
                $data['title'] = 'Edit';
            }
            $data['vendor_id'] = $vid;
            $data['vendor_cust_id'] = $cust_id;
            $data['vendordetails'] = $this->vendor_model->get_DatabyCommon('vendor_details',array('vendor_id'=>$vid),'*'); 
            $this->load->view('admin/template',$data);
        }
        
        public function vendorVerification()
        {
            /*Vendor form verification for each fields*/
            
            $member_id = $this->IsloggedIn();
            $data['siteSettings'] = $this->data['siteSettings'];          
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('name', 'vendor name', 'required');
            $this->form_validation->set_rules('phone', 'phone number', 'required');
            $this->form_validation->set_rules('email', 'email address', 'required|valid_email');
            $this->form_validation->set_rules('account_no', 'account number', 'required');
            $this->form_validation->set_rules('ifsc_code', 'ISFC code', 'required');
            $this->form_validation->set_rules('user_code', 'vendor code', 'required|callback_check_vendor_code');
            $this->form_validation->set_rules('address1', 'address1', 'required');
            $this->form_validation->set_rules('city', 'city', 'required');
            $this->form_validation->set_rules('company_name', 'company name', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('bank_name', 'bank name', 'required');
            $this->form_validation->set_rules('bank_branch', 'bank branch', 'required');
            $this->form_validation->set_rules('is_subsidiary', 'subsidiary vendor', 'required');
            
            $vendor_cust_id = $this->input->post('vendor_cust_id');
            $vendor_id = $this->input->post('vendor_id');
            if ($this->form_validation->run()=='TRUE') {
                $vendor['vendor_name']   = $this->input->post('name');
                $vendor['vendor_phone']  = $this->input->post('phone');
                $vendor['vendor_city']   = $this->input->post('city');
                $vendor['vendor_state']  = $this->input->post('state');
                $vendor['vendor_email']  = $this->input->post('email');
                $vendor['vendor_account_no']   = $this->input->post('account_no');
                $vendor['vendor_ifsc_code']    = $this->input->post('ifsc_code');
                $vendor['vendor_code']    = $this->input->post('user_code');
                $vendor['vendor_address1']     = $this->input->post('address1');
                $vendor['vendor_address2']     = $this->input->post('address2');
                $vendor['vendor_bank_name']    = $this->input->post('bank_name');
                $vendor['vendor_bank_branch']   = $this->input->post('bank_branch');
                $vendor['is_subsidiary']   = $this->input->post('is_subsidiary');
                $vendor['vendor_company_name']   = $this->input->post('company_name');
                $vendor['vendor_created_by']   = $member_id;
                $vendor['vendor_created_date'] = date('Y-m-d H:i:s');
                $vendor['vendor_cust_id'] = $vendor_cust_id;
                if($vendor_id=='')
                {
                    $this->vendor_model->InsertCommon('vendor_details',$vendor);
                    //Activity log
                    $this->vendor_model->logdetails('New '.$vendor['vendor_name'].' added','vendor');
                    $text = "Added";
                }
                else
                {
                    //Activity log
                    $previous = $this->vendor_model->get_DatabyCommon('vendor_details',array('vendor_id'=>$vendor_id),'*'); 
                    $changedItems = $this->vendor_model->validateUpdatedElements($previous,$vendor);
                    if($changedItems!='')
                    {
                        $this->vendor_model->logdetails($previous->vendor_name.' '.$changedItems.' details updated ','vendor');
                    }
                    
                    $where = array('vendor_id'=>$vendor_id);
                    $this->vendor_model->UpdateDatabyCommon('vendor_details',$where,$vendor);
                    $text = "Updated";
                }
				$code = '{STATUS_TEXT}';				        
	
                $this->session->set_flashdata('Success',  str_replace($code,$text,INFO_A303));
                redirect(ADMINBASEURL.'bankadmin/vendorlist','refresh');
            }
            else {
                
                if($vendor_cust_id!='' && is_numeric($vendor_cust_id))
                {
                    $data['title'] = 'Edit';
                }
                else {
                    $data['title'] = 'Add';
                }

                $insert->vendor_name   = $this->input->post('name');
                $insert->vendor_phone  = $this->input->post('phone');
                $insert->vendor_email  = $this->input->post('email');
                $insert->vendor_account_no   = $this->input->post('account_no');
                $insert->vendor_ifsc_code    = $this->input->post('ifsc_code');
                $insert->vendor_code    = $this->input->post('user_code');
                $insert->cust_created_by   = $member_id;
                $insert->vendor_city    = $this->input->post('city');
                $insert->vendor_state   = $this->input->post('state');
                $insert->vendor_company_name = $this->input->post('company_name');
                $insert->vendor_address1   = $this->input->post('address1');
                $insert->vendor_address2 = $this->input->post('address2');
                $insert->vendor_bank_name   = $this->input->post('bank_name');
                $insert->vendor_bank_branch = $this->input->post('bank_branch');
                $insert->is_subsidiary = $this->input->post('is_subsidiary');
                
                $data['vendordetails'] = $insert;    
                $data['vendor_id'] = $vendor_id;
                $data['vendor_cust_id'] = $vendor_cust_id;
                $data['page'] = 'admin/pages/addvendor';
                
                $this->load->view('admin/template',$data);
            }
        }   
        
        public function check_vendor_code($code)
        {     
            /*Vendor unique code check for add/update vendor in vendor_details table*/
            $vendor_id = $this->input->post('vendor_id');
            $user_code  = $this->input->post('user_code');
            if($vendor_id!='' && is_numeric($vendor_id))
            {
                $where = array('vendor_code'=>$user_code, 'vendor_id !='=>$vendor_id);
            }
            else {
                $where = array('vendor_code'=>$user_code);
            }
            
            $count = $this->vendor_model->get_DatabyCommon('vendor_details',$where,'count(*) as existcount');
            if($count->existcount==0)
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('check_vendor_code', ERROR_A301);
                return false; 
            }
        }
        
        public function vendorInvoiceList()
        {
            
            /*List of invoice based on vendorcode listed in this page*/
            $this->IsloggedIn();
            $id = $this->input->get('id');
            $status = $this->input->get('status');
            if($status!='')
            {
                $invoiceArray = array('invoice_vendor_id'=>$id,'invoice_status'=>$status);
            }
            else {
                $invoiceArray = array('invoice_vendor_id'=>$id);
            }
            $data['page'] = 'admin/pages/invoicelist';
            $invoiceListArray = $this->vendor_model->get_DatabyCommonwithOrderby('invoice_details',$invoiceArray,'*','created_date asc');
            $this->load->model('invoice_loan_limit');
            foreach($invoiceListArray as $each)
            {
                $arrayList ='';
                $where = array('cust_id'=>$each->invoice_cust_id);
                $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');                
                $arrayList = $each;
                $arrayList->interestRate = $customerDetails->interest_rate;
                $arrayList->limitcheck = $this->invoice_loan_limit->customerBasedLoanLimit($each->invoice_id,$each->invoice_cust_id);
                $data['invoicelist'][] = $arrayList;
            }
            $data['vendordetails'] = $this->vendor_model->get_DatabyCommon('vendor_details',array('vendor_id'=>$id),'*');
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['vendor_id'] = $id;
            
            $this->load->view('admin/template',$data);
        }

        public function vendorList()
        {
            /*List of vendors from vendor_details table listed in this page*/
            $this->IsloggedIn();
			$CustomerData=$this->session->userdata("CustomerData");
            $id = $CustomerData['cust_id'];
            $data['page'] = 'admin/pages/vendorList';
            $data['customerVendorlist'] = $this->vendor_model->get_DatabyCommonwithOrderby('vendor_details',array('vendor_cust_id'=>$id),'*',' vendor_name asc');
            $data['customerdetails'] = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$data['customerVendorlist'][0]->vendor_cust_id),'*');
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['cust_id'] = $id;
            $this->load->view('admin/template',$data);
        }
        
        public function vendorsMainPage()
        {
            /*vendors count based on customer code and listed below */
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/vendorMainPage';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['vendorsList'] = $this->dashboard_model->customerCodeandvendorCount();
            $this->load->view('admin/template',$data);
        }
        
        public function logDetails()
        {
            /*List of vendors from vendor_details table listed in this page*/
            $this->IsloggedIn();
            $id = $this->input->get('id');
            $data['page'] = 'admin/pages/logdetails';
			$filter_from=date("d-m-Y",strtotime('yesterday'));
			$from_date=date('Y-m-d',strtotime($filter_from));
			$filter_to= date("d-m-Y", strtotime('tomorrow'));
			$to_date=date('Y-m-d',strtotime($filter_to));
			if($this->input->post('filter_from') != ""){
				 $filter_from = $this->input->post('filter_from');
				 $from_date=date('Y-m-d',strtotime($filter_from));
			}
			if($this->input->post('filter_to') != ""){
				 $filter_to = $this->input->post('filter_to');
				 $to_date=date('Y-m-d',strtotime($filter_to));
			}
			    $path = "application/logs/";               
                $this->load->library('csvreader');
                $this->load->helper('directory');
				$map = directory_map($path);				
				#$this->p($map);				
				$log_files = array();
				foreach($map as $key => $val)
				{				
					$val_date = substr(substr($val,5),0,10);
					$file_date =date('Y-m-d',strtotime($val_date));
					
					if(strtotime($file_date)>strtotime($from_date) && strtotime($file_date)<strtotime($to_date)){		
					
					$log_files[$key]=$val;
					}
				}
			if(strtotime($filter_from) > strtotime($filter_to)){
				
				 $this->session->set_flashdata('error', ERROR_A106);
			}
			$data['filter_from'] =	$filter_from;
			$data['filter_to'] =	$filter_to;
            $data['logdetails'] = $log_files;
            $data['siteSettings'] = $this->data['siteSettings'];
            $this->load->view('admin/template',$data);
        }
      
        public function importvendor()
        {            
            /*Option is available to add vendor by excel file by import. This option is not used now */          
            $this->IsloggedIn();
            $id = $this->input->get('id');
            $data['page'] = 'admin/pages/importvendor';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['cust_id'] = $id;
            $data['customerdetails'] = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$id),'*');
            $this->load->view('admin/template',$data);
        }
        
        public function saveimport()
        {
            $this->load->library('excel');
        
            $cust_id = $this->input->post('cust_id');
            if ($_FILES['userfile']!='') 
            {
                $path = './excel/importvendors/';
                $config['upload_path'] = $path;
                $config['allowed_types'] = 'xlsx|xls|jpg|png';
                $config['remove_spaces'] = TRUE;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
                } else {
                    $data = array('upload_data' => $this->upload->data());
                }
                if (!empty($data['upload_data']['file_name'])) {
                    $import_xls_file = $data['upload_data']['file_name'];
                } else {
                    $import_xls_file = 0;
                }
                $inputFileName = $path . $import_xls_file;
                try {
                    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                    $objPHPExcel = $objReader->load($inputFileName);
                } catch (Exception $e) {
                    $text = 'Error loading file ": ' . $e->getMessage();
                    $this->session->set_flashdata('import_error', $text);
                    redirect(ADMINBASEURL.'bankadmin/importvendor?id='.$cust_id,'refresh');
                }
                $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
                
                if(count($allDataInSheet)>0)
                {
                    $keylist = $allDataInSheet[1];//echo '<pre>'; print_r($allDataInSheet);
                    unset($allDataInSheet[1]);
                    foreach($allDataInSheet as $insertData)
                    {
                        $insertDataArray='';
                        foreach($insertData as $key=>$data)
                        {
                            $insertDataArray[str_replace(' ','_', strtolower(trim($keylist[$key])))] = $data;
                        }
                        $insertDataArray['vendor_cust_id'] = $cust_id;
                        $this->vendor_model->InsertCommon('vendor_details',$insertDataArray);
                    }
                    
                     $this->session->set_flashdata('Success', INFO_A302);
                     redirect(ADMINBASEURL.'bankadmin/vendorlist','refresh');
                }
                else
                {
                    $this->session->set_flashdata('import_error', ERROR_A302);
                    redirect(ADMINBASEURL.'bankadmin/importvendor?id='.$cust_id,'refresh');
                }
           
            }
        }
		
        public function ValidateArraywithColumns($invoiceArray,$donePath)
        {    
//echo "dd<pre>";print_r($invoiceArray);exit();   
			
            $myarrayColumns = array('customer_code','vendor_code','beneficiary_number','beneficiary_ifsc_code',
                'beneficiary_name','invoice_number','invoice_date[dd-mm-yyyy]','invoice_amount','net_or_gross','deduction_days');
           $net_or_gross = array("GROSS","NET");
		  $flag = 1;
		$i=2;  
		$error_report=array();			
		foreach($invoiceArray as $eachRecord)
           {
				$onlyKeys = array_keys($eachRecord);
				$result   = array_diff($myarrayColumns,$onlyKeys);
				
				$invoice_date = $eachRecord['invoice_date[dd-mm-yyyy]'];
				/*CHECK if invoice already processed*/
				$where = array('cust_user_code'=>trim($eachRecord['customer_code']));
				$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');

				$arrayCheckInvoice = array('invoice_number'=>$eachRecord['invoice_number'],'invoice_cust_id'=>$customerDetails->cust_id);
				$results_inv = $this->vendor_model->get_DatabyCommon('invoice_details',$arrayCheckInvoice,'*');
				if(count($results_inv) >0){
					$flag = 0;
					$error_report[$i]['invoice_number']=ERROR_C419;
				}			
											
				if(count($result)>0)
				{
					$flag = 0;
				}				
				if(file_exists($donePath)){
					
					$flag = 0;
					$error_report[$i]['customer_code']=ERROR_C419;
				}
				if(empty($eachRecord['customer_code']) && trim($eachRecord['customer_code'])!='')
				{
					$flag = 0;
					$error_report[$i]['customer_code']=ERROR_A401;
				}				
				if(empty($eachRecord['vendor_code']))
				{
					$flag = 0;
					$error_report[$i]['vendor_code']=ERROR_A401;
				}				
				if(empty($eachRecord['beneficiary_number']))
				{
					$flag = 0;
					$error_report[$i]['beneficiary_number']=ERROR_A401;
				}				
				if(empty($eachRecord['beneficiary_ifsc_code']))
				{
					$flag = 0;
					$error_report[$i]['beneficiary_ifsc_code']=ERROR_A401;
				}				
				if(empty($eachRecord['invoice_number']))
				{
					$flag = 0;
					$error_report[$i]['invoice_number']=ERROR_A401;
				}				
				if($invoice_number[$eachRecord['vendor_code']]==$eachRecord['invoice_number']){
					$flag = 0;					
					$code = array('{INVOICE_CODE}','{VENDOR_CODE}');					
					$meg  = array($eachRecord['invoice_number'],$eachRecord['vendor_code']);						
					$error_report[$i]['duplicate_entry']= str_replace($code,$meg,ERROR_A403); 
					$invoice_number[$eachRecord['vendor_code']]=$eachRecord['invoice_number'];
				}else{
					$invoice_number[$eachRecord['vendor_code']]=$eachRecord['invoice_number'];
				}				
				if(empty($eachRecord['invoice_date[dd-mm-yyyy]']))
				{
					$flag = 0;
					$error_report[$i]['invoice_date[dd-mm-yyyy]']=ERROR_A401;
				}
				
				if(strpos($invoice_date,'-') !== false)
				{
					list($dd,$mm,$yyyy) = explode('-',$invoice_date);
				}else{
					list($dd,$mm,$yyyy) = explode('/',$invoice_date);
				}				
				if (!checkdate($mm,$dd,$yyyy)) {
					$flag = 0;
					$error_report[$i]['invoice_date[dd-mm-yyyy]']=ERROR_A402;
				}				
				if(empty($eachRecord['invoice_amount']) OR is_numeric($eachRecord['invoice_amount'])==false)
				{
					$flag = 0;
					$error_report[$i]['invoice_amount']=ERROR_A402;
				}				
				if(empty($eachRecord['deduction_days']) OR is_numeric($eachRecord['deduction_days'])==false)
				{
					$flag = 0;
					$error_report[$i]['deduction_days']=ERROR_A402;
				}
				if(in_array(strtoupper($eachRecord['net_or_gross']),$net_or_gross)==false)
				{
					$flag = 0;
					$error_report[$i]['net_or_gross']=ERROR_A402;
				}	
				
				$result_inv=$this->dashboard_model->ValidateInvoice(trim($eachRecord['customer_code']),$eachRecord['vendor_code'],$eachRecord['invoice_number']);
				
				if($result_inv['cust_id']==0)
				{
					$flag = 0;					
					$code = array('{CUSTOMER_CODE}');					
					$msg  = array(trim($eachRecord['customer_code']));						
					$error_report[$i]['customer']= str_replace($code,$msg,ERROR_A404); 					
				}
				if($result_inv['same_vendor']==1)
				{
					$flag = 0;
					$code = array('{CUSTOMER_CODE}','{VENDOR_CODE}');					
					$msg  = array(trim($eachRecord['customer_code']),$eachRecord['vendor_code']);						
					$error_report[$i]['duplicate_invoice']= str_replace($code,$msg,ERROR_A405);				
				}
				if($flag==0)
				{
					$JSON = json_encode($eachRecord);
					$jsonarray = array('detailed_array'=>$JSON,'date_created'=>date('Y-m-d H:i:s'));
					$this->vendor_model->InsertCommon('invoice_error',$jsonarray);
				} 
			$i++;				
		   }		   
		   if($flag==0)
		   {
			   
			   foreach($error_report AS $key=>$data)
			   {
					$error_throw.='<h4>Row Number :'.$key.'</h4>';
				    $columns=array_keys($data);
					$error_throw.='<ul>';					
				    for($j=0; $j<count($columns); $j++)
					{
						$error_throw.='<li>'.ucwords(str_replace("_"," ",$columns[$j]))." => ".$data[$columns[$j]].'</li>';
					}
					$error_throw.='</ul>';
			   }
			   
			   			  
		   }		
		   
		   $respons['flag']=$flag;
		   $respons['error_report']=$error_report;		  
		   $respons['error_report_list']=$error_throw;		  
		   return $respons;
        }
        function p($v)
		{
			echo '<pre>';
			print_R($v);
			echo '<pre>';			
		}
		
        function readExcel()
        {
			
			
            /* Reading invoice excel files from directory.  invoiceFile
             * 
             * After based on vendor_code and customer code, Vendor details add or update in vendor_details table.
             * 
             * Invoice records are inserted in invoice_details table.
             * 
             * If any column value or column missing, Data will save in invoice_errors table with JSON Format.  invoice_ids
             * 
             */
			  	$data['siteSettings'] = $this->data['siteSettings'];			
                $member_id = $this->IsloggedIn();
                $cust_id = $this->input->get('id');
                $path = CUS_INVOICE_READFROM;
                $newpath = INVOICE_MOVETO;
                $this->load->library('csvreader');
                $this->load->helper('directory');
				$map = directory_map($path);
				$processed =0;
				#$this->p($map);
				
				$custoInvoices = array();
				#by SIMI- get the files from table.
				/* foreach($map as $cusK => $cusV) 
				{
					$cusId = trim(str_replace( '/', '', stripslashes($cusK)));	
						
					foreach($cusV as $keyIn => $valIn)
					{	
						$keyIn = str_replace( '/', '', stripslashes($keyIn));
						if(trim($keyIn) == "invoice" && count($valIn)>0)
						{
							$custoInvoices[$cusId] = $valIn;
						}	
						
					}
				} */
				 #by SIMI- get the files from table.
				 $custoInvoices=$this->vendor_model->get_uploaded_invoice();
//echo $_POST['invoices_ids'];exit();				
				if(isset($_POST['invoices_ids']))
				{	
			
                    $postInvoiceId = array(); 					
				    $invoice_files_key = explode(",",$_POST['invoices_ids']);
					
					$custoInvoices_posted=$this->vendor_model->get_uploaded_invoice($invoice_files_key);
					
					/* foreach($invoice_files_key as $keyNum => $valUniq)
					{
						$split_cusId_fileId = explode("=>",$valUniq);
						$cusId = $split_cusId_fileId[0];
						$postInvoiceId[$cusId][] = $split_cusId_fileId[1];
					}	 */	
				
				
					
					
				   // foreach($custoInvoices as $key=>$eachfiles)
                    //{
						//print_r($eachfiles);
					
						//if(array_key_exists($key,$postInvoiceId))
						//{
							//echo "Testttt 123";
							//$findOneCusFiles = $postInvoiceId[$key];
							
							//print_r($findOneCusFiles);
					
						//}
						
					//}				
							foreach($custoInvoices_posted as $keyCF => $cust_in_details)
							{
								
								
								$valCF=$cust_in_details['filename'];
								 $key=$cust_in_details['cust_user_code'];
								
								//echo "Testttt 123 4";
								
								//if(in_array($valCF,$eachfiles))
								//{
									//echo "Testttt 123 5";
									   
										 $readPath = $path.$key."/invoice/".$valCF;
										 $donePath = CUS_INVOICE_READFROM.$key."/invoice_done/".$valCF;
										 $errorPath = CUS_INVOICE_READFROM.$key."/invoice_error/".$valCF;
										
										$decrypted_file_path=$this->decrypt_invoice($path.$key."/invoice/",$valCF);
										$invoiceArray =   $this->csvreader->parse_file($decrypted_file_path);//path to csv file
										$respons = $this->ValidateArraywithColumns($invoiceArray,$donePath);
 
										$flg=$respons['flag']; 
										$error_report_list=$respons['error_report_list'];
										
										$dir_temp = CUS_INVOICE_READFROM.$key."/invoice/tmper/";
										if (is_dir($dir_temp)) {
											array_map('unlink', glob("$dir_temp/*.*"));
											rmdir(CUS_INVOICE_READFROM.$key."/invoice/tmper/");
										}
									
								
										if($flg==1)
										{
										 	
											foreach($invoiceArray as $eachRecord)
											{
											
												$invoice =array(); $userexist=0; $vendor=array();

												$where = array('cust_user_code'=>trim($eachRecord['customer_code']));
												$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');

												$arrayCheck = array('vendor_code'=>$eachRecord['vendor_code'],'vendor_cust_id'=>$customerDetails->cust_id);
												$results = $this->vendor_model->get_DatabyCommon('vendor_details',$arrayCheck,'*');
												$invoice_date=$eachRecord['invoice_date[dd-mm-yyyy]'];
												
												
											
												/*If folders not already created creating now
												sreeja.m
												*/
												$user_folder = str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST);
												if (!is_dir($user_folder)) {
													mkdir($user_folder, 0777, TRUE);
												}
												$UPLOADS_CUST_INVOICE_FOLDER = str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INVOICE);
												if (!is_dir($UPLOADS_CUST_INVOICE_FOLDER)) {
													mkdir(str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INVOICE), 0777, TRUE);
												}
												$UPLOADS_CUST_DOC = str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_DOC);
												if (!is_dir($UPLOADS_CUST_DOC)) {
													mkdir(str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_DOC), 0777, TRUE);
												}
												$UPLOADS_CUST_INV_DONE = str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INV_DONE);
												if (!is_dir($UPLOADS_CUST_INV_DONE)) {
													mkdir(str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INV_DONE), 0777, TRUE);
												}

												$UPLOADS_CUST_INV_ERROR = str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INV_ERROR);
												if (!is_dir($UPLOADS_CUST_INV_ERROR)) {
														mkdir(str_replace('{CUST_CODE}',$eachRecord['customer_code'],UPLOADS_CUST_INV_ERROR), 0777, TRUE);
												}												
												
												
												
												if(strpos($invoice_date,'-') === false)
												{
													$eachRecord['invoice_date[dd-mm-yyyy]']=str_replace("/","-",$invoice_date);
												}
												
												if(count($customerDetails)>0 && $eachRecord['vendor_code']!='')
												{
													
													if(count($results)>0)
													{
														$userexist = 1;
														$invoice['invoice_vendor_id'] = $results->vendor_id;
														$invoice['invoice_cust_id']   = $results->vendor_cust_id;			
														
														$vendor['vendor_name'] = $eachRecord['beneficiary_name'];
														$vendor['vendor_account_no'] = $eachRecord['beneficiary_number'];
														$vendor['vendor_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];

														$where = array('vendor_id'=>$results->vendor_id);
														$this->vendor_model->UpdateDatabyCommon('vendor_details',$where,$vendor);

													}
													else{

														$vendor['vendor_code']    = ($eachRecord['vendor_code'])?$eachRecord['vendor_code']:'';
														$vendor['vendor_cust_id'] = ($customerDetails->cust_id)?$customerDetails->cust_id:'';
														$vendor['vendor_name'] = ($eachRecord['beneficiary_name'])?$eachRecord['beneficiary_name']:'';
														$vendor['vendor_account_no'] = ($eachRecord['beneficiary_number'])?$eachRecord['beneficiary_number']:'';
														$vendor['vendor_ifsc_code'] = ($eachRecord['beneficiary_ifsc_code'])?$eachRecord['beneficiary_ifsc_code']:'';
														$vendor_id = $this->vendor_model->InsertCommon('vendor_details',$vendor);
														$invoice['invoice_vendor_id'] = $vendor_id;
													}
													
														$invoiceResults = $this->vendor_model->get_DatabyCommon('invoice_details',
														array('invoice_vendor_id'=>$invoice['invoice_vendor_id'],'invoice_number'=>$eachRecord['invoice_number']),'*');
														$invoice['invoice_cust_id'] = $customerDetails->cust_id;
														$invoice['invoice_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];
														$invoice['invoice_number'] = $eachRecord['invoice_number'];
														$invoice['invoice_beneficiary_name'] = $eachRecord['beneficiary_name'];
														$invoice['invoice_beneficiary_number'] = $eachRecord['beneficiary_number'];
														$invoice['invoice_amount'] = $eachRecord['invoice_amount'];
														$invoice['invoice_date'] = date('Y-m-d',strtotime($eachRecord['invoice_date[dd-mm-yyyy]']));
														$invoice['invoice_deduction_days'] = $eachRecord['deduction_days'];
														$invoice['invoice_net']=  $eachRecord['net_or_gross']; 
														$invoice['invoice_status']=  'Pending';
														
														if(strtoupper($invoiceDetails->invoice_net)=='NET')
														{					
															$invoice['invoice_discount'] = ($customerDetails->interest_rate*($eachRecord['invoice_amount']*$eachRecord['deduction_days'])/365)/100;
															$invoice['invoice_topaid'] = $invoice['invoice_amount']-$invoice['invoice_discount'];
														}else{
															$invoice['invoice_discount'] = 0;
															$invoice['invoice_topaid'] = $invoice['invoice_amount'];
														} 
														
														if(count($invoiceResults)==0)
														{
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->InsertCommon('invoice_details',$invoice);
														}
														else 
														{
															$where = array('invoice_number'=>$eachRecord['invoice_number'],'invoice_vendor_id' => $invoice['invoice_vendor_id'],'invoice_status'=>'Pending');
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$invoice);
														}
														
													
												}
												
											}
											
											$code = '';                     
											$res = copy($readPath, $donePath); 
											
											if($res)
											{
												$processed =1;
											//rmdir(CUS_INVOICE_READFROM.$key."/invoice/tmper/");
											//$unlink = INVOICE_UNLINK.$valCF;
											$unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF;
											$unlink_temp_file = CUS_INVOICE_READFROM.$key."/invoice/tmper/".$valCF;
											$res = unlink($unlink);
											$res = unlink($unlink_temp_file);
											$dir_temp = CUS_INVOICE_READFROM.$key."/invoice/tmper/";
										array_map('unlink', glob("$dir_temp/*.*"));
										rmdir(CUS_INVOICE_READFROM.$key."/invoice/tmper/");
											
										
												
											}
											#UPDATE STATUS IN INVOICE UPLOAD TABLE AS PROCESSED.
											$where_to_doc=array('id'=>$cust_in_details['id']); 
											$data_to_invoice=array('processed_date'=>date('Y-m-d H:i:s'),'status'=>'2');
											$this->vendor_model->UpdateDatabyCommon('invoice_csv_uploads',$where_to_doc,$data_to_invoice);
											#UPDATE STATUS IN INVOICE UPLOAD TABLE AS PROCESSED.
											$this->vendor_model->logdetails('Cron details updated for invoice file name:'.$valCF,'invoice');
											
									    	  $this->session->set_flashdata('Success', 'Vendor invoice details imported successfully');
											  redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
										
											
										}
										else
										{
											$this->session->set_flashdata('invoice_import_error', $error_report_list);
											//echo $unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF; exit;
											
											/*$res = copy($readPath, $donePath); 
											if($res)
											{
												
											$unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF;
											$unlink_temp_file = CUS_INVOICE_READFROM.$key."/invoice/tmper/".$valCF;
											$dir_temp = CUS_INVOICE_READFROM.$key."/invoice/tmper/";
											array_map('unlink', glob("$dir_temp/*.*"));
											rmdir(CUS_INVOICE_READFROM.$key."/invoice/tmper/");
											$res = unlink($unlink);
											$res = unlink($unlink_temp_file);
											$this->vendor_model->logdetails('Cron details not updated for invoice file name:'.$valCF,'invoice');
										
											}*/
											
											
											
											redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
										}

									if($processed ==1)	{
											  $this->session->set_flashdata('Success', 'Vendor invoice details imported successfully');
											  redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
									}else{
										$this->session->set_flashdata('invoice_import_error', $error_report_list);
										    redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
									}

								//}
							 }
							 
							
						//}	
					//}	
				}
				else
				{
					
			    
					$data['page'] = 'admin/pages/readInvoiceExcel';
					$data['invoiceFile'] = $custoInvoices;
					$this->load->view('admin/template',$data);
					

				}

				

                /* exit;

				if(isset($_POST['invoice_ids']))
				{	
						
					foreach($custoInvoices as $key=>$eachfiles)
                    {	
						
						if(array_key_exists($key,$invoice_files_key))
						{
										$readPath = $path.$eachfiles;
										$movePath = $newpath.$eachfiles;
										$invoiceArray =   $this->CSVreader->parse_file($readPath);//path to csv file
										$respons = $this->ValidateArraywithColumns($invoiceArray);
										$flg=$respons['flag'];
										if($flg==1)
										{
											foreach($invoiceArray as $eachRecord)
											{
												$invoice =array(); $userexist=0; $vendor=array();

												$where = array('cust_user_code'=>$eachRecord['customer_code']);
												$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');

												$arrayCheck = array('vendor_code'=>$eachRecord['vendor_code'],'vendor_cust_id'=>$customerDetails->cust_id);
												$results = $this->vendor_model->get_DatabyCommon('vendor_details',$arrayCheck,'*');
												
												if(count($customerDetails)>0 && $eachRecord['vendor_code']!='')
												{
													if(count($results)>0)
													{
														$userexist = 1;
														$invoice['invoice_vendor_id'] = $results->vendor_id;
														$invoice['invoice_cust_id']   = $results->vendor_cust_id;									
														
														$vendor['vendor_name'] = $eachRecord['beneficiary_name'];
														$vendor['vendor_account_no'] = $eachRecord['beneficiary_number'];
														$vendor['vendor_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];

														$where = array('vendor_id'=>$results->vendor_id);
														$this->vendor_model->UpdateDatabyCommon('vendor_details',$where,$vendor);

													}
													else{

														$vendor['vendor_code']    = ($eachRecord['vendor_code'])?$eachRecord['vendor_code']:'';
														$vendor['vendor_cust_id'] = ($customerDetails->cust_id)?$customerDetails->cust_id:'';
														$vendor['vendor_name'] = ($eachRecord['beneficiary_name'])?$eachRecord['beneficiary_name']:'';
														$vendor['vendor_account_no'] = ($eachRecord['beneficiary_number'])?$eachRecord['beneficiary_number']:'';
														$vendor['vendor_ifsc_code'] = ($eachRecord['beneficiary_ifsc_code'])?$eachRecord['beneficiary_ifsc_code']:'';
														

														$vendor_id = $this->vendor_model->InsertCommon('vendor_details',$vendor);
														$invoice['invoice_vendor_id'] = $vendor_id;
														
														$invoiceResults = $this->vendor_model->get_DatabyCommon('invoice_details',
														array('invoice_vendor_id'=>$invoice['invoice_vendor_id'],'invoice_number'=>$eachRecord['invoice_number']),'*');

														$invoice['invoice_cust_id'] = $customerDetails->cust_id;
														$invoice['invoice_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];
														$invoice['invoice_number'] = $eachRecord['invoice_number'];
														$invoice['invoice_beneficiary_name'] = $eachRecord['beneficiary_name'];
														$invoice['invoice_beneficiary_number'] = $eachRecord['beneficiary_number'];
														$invoice['invoice_amount'] = $eachRecord['invoice_amount'];
														$invoice['invoice_date'] = date('Y-m-d',strtotime($eachRecord['invoice_date']));
														$invoice['invoice_deduction_days'] = $eachRecord['deduction_days'];
														$invoice['invoice_net']=  $eachRecord['net_or_gross']; 
														$invoice['invoice_status']=  'Pending';
														
														if(strtoupper($invoiceDetails->invoice_net)=='NET')
														{					
															$invoice['invoice_discount'] = ($customerDetails->interest_rate*($eachRecord['invoice_amount']*$eachRecord['deduction_days'])/365)/100;
															$invoice['invoice_topaid'] = $invoice['invoice_amount']-$invoice['invoice_discount'];
														}else{
															$invoice['invoice_discount'] = 0;
															$invoice['invoice_topaid'] = $invoice['invoice_amount'];
														} 
														
														if(count($invoiceResults)==0)
														{
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->InsertCommon('invoice_details',$invoice);
														}
														else 
														{
															$where = array('invoice_number'=>$eachRecord['invoice_number'],'invoice_vendor_id' => $invoice['invoice_vendor_id'],'invoice_status'=>'Pending');
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$invoice);
														}
														
													}
												}
												
											}
												
											
											
											$code = '';                     
											$res = copy($readPath, $movePath); 
											if($res){
											$unlink = INVOICE_UNLINK.$eachfiles;
											$res = unlink($unlink);
											}
											
											$this->vendor_model->logdetails('Cron details updated for invoice file name:'.$eachfiles,'invoice');
											
											$this->session->set_flashdata('Success', 'Vendor invoice details imported successfully');
											//redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
											
										}
										else
										{
											 $this->vendor_model->logdetails('Cron details not updated for invoice file name:'.$eachfiles,'invoice');
											 $this->session->set_flashdata('invoice_import_error', 'Vendor invoice details not updated');
											 //redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
										}

										
						}
				    } 
				   
				}
				else
				{
					$data['page'] = 'admin/pages/readInvoiceExcel';
					$data['invoiceFile'] = $custoInvoices;
					$this->load->view('admin/template',$data);
					

				} */
        }
			function readExcel_BK_REVAMP() #disabled BY SIMI
        {
            /* Reading invoice excel files from directory. 
             * 
             * After based on vendor_code and customer code, Vendor details add or update in vendor_details table.
             * 
             * Invoice records are inserted in invoice_details table.
             * 
             * If any column value or column missing, Data will save in invoice_errors table with JSON Format. 
             * 
             */
			  	$data['siteSettings'] = $this->data['siteSettings'];			
                $member_id = $this->IsloggedIn();
                $cust_id = $this->input->get('id');
                $path = CUS_INVOICE_READFROM;
                $newpath = INVOICE_MOVETO;
                $this->load->library('csvreader');
                $this->load->helper('directory');
				$map = directory_map($path);
				
				#$this->p($map);
				
				$custoInvoices = array();
				foreach($map as $cusK => $cusV)
				{
					$cusId = trim(str_replace( '/', '', stripslashes($cusK)));	
						
					foreach($cusV as $keyIn => $valIn)
					{	
						$keyIn = str_replace( '/', '', stripslashes($keyIn));
						if(trim($keyIn) == "invoice" && count($valIn)>0)
						{
							$custoInvoices[$cusId] = $valIn;
						}	
						
					}
				}
			
				if(isset($_POST['invoice_ids']))
				{					
                    $postInvoiceId = array(); 					
				    $invoice_files_key = explode(",",$_POST['invoice_ids']);
					foreach($invoice_files_key as $keyNum => $valUniq)
					{
						$split_cusId_fileId = explode("=>",$valUniq);
						$cusId = $split_cusId_fileId[0];
						$postInvoiceId[$cusId][] = $split_cusId_fileId[1];
					}						
					
					
				    foreach($custoInvoices as $key=>$eachfiles)
                    {
						//print_r($eachfiles);
					
						if(array_key_exists($key,$postInvoiceId))
						{
							//echo "Testttt 123";
							$findOneCusFiles = $postInvoiceId[$key];
							
							//print_r($findOneCusFiles);
					
							
							foreach($findOneCusFiles as $keyCF => $valCF)
							{
								//echo "Testttt 123 4";
								
								if(in_array($valCF,$eachfiles))
								{
									//echo "Testttt 123 5";
									    //echo $valCF; exit;
										$readPath = $path.$key."/invoice/".$valCF;
										$donePath = CUS_INVOICE_READFROM.$key."/invoice_done/".$valCF;
										$errorPath = CUS_INVOICE_READFROM.$key."/invoice_error/".$valCF;
										
										$invoiceArray =   $this->csvreader->parse_file($readPath);//path to csv file
										
										$respons = $this->ValidateArraywithColumns($invoiceArray,$donePath);
										$flg=$respons['flag'];
										$error_report_list=$respons['error_report_list'];
										
										if($flg==1)
										{
											foreach($invoiceArray as $eachRecord)
											{
												$invoice =array(); $userexist=0; $vendor=array();

												$where = array('cust_user_code'=>trim($eachRecord['customer_code']));
												$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');

												$arrayCheck = array('vendor_code'=>$eachRecord['vendor_code'],'vendor_cust_id'=>$customerDetails->cust_id);
												$results = $this->vendor_model->get_DatabyCommon('vendor_details',$arrayCheck,'*');
												$invoice_date=$eachRecord['invoice_date[dd-mm-yyyy]'];
												
												if(strpos($invoice_date,'-') === false)
												{
													$eachRecord['invoice_date[dd-mm-yyyy]']=str_replace("/","-",$invoice_date);
												}
												
												if(count($customerDetails)>0 && $eachRecord['vendor_code']!='')
												{
													if(count($results)>0)
													{
														$userexist = 1;
														$invoice['invoice_vendor_id'] = $results->vendor_id;
														$invoice['invoice_cust_id']   = $results->vendor_cust_id;									
														
														$vendor['vendor_name'] = $eachRecord['beneficiary_name'];
														$vendor['vendor_account_no'] = $eachRecord['beneficiary_number'];
														$vendor['vendor_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];

														$where = array('vendor_id'=>$results->vendor_id);
														$this->vendor_model->UpdateDatabyCommon('vendor_details',$where,$vendor);

													}
													else{

														$vendor['vendor_code']    = ($eachRecord['vendor_code'])?$eachRecord['vendor_code']:'';
														$vendor['vendor_cust_id'] = ($customerDetails->cust_id)?$customerDetails->cust_id:'';
														$vendor['vendor_name'] = ($eachRecord['beneficiary_name'])?$eachRecord['beneficiary_name']:'';
														$vendor['vendor_account_no'] = ($eachRecord['beneficiary_number'])?$eachRecord['beneficiary_number']:'';
														$vendor['vendor_ifsc_code'] = ($eachRecord['beneficiary_ifsc_code'])?$eachRecord['beneficiary_ifsc_code']:'';
														

														$vendor_id = $this->vendor_model->InsertCommon('vendor_details',$vendor);
														$invoice['invoice_vendor_id'] = $vendor_id;
													}	
														$invoiceResults = $this->vendor_model->get_DatabyCommon('invoice_details',
														array('invoice_vendor_id'=>$invoice['invoice_vendor_id'],'invoice_number'=>$eachRecord['invoice_number']),'*');

														$invoice['invoice_cust_id'] = $customerDetails->cust_id;
														$invoice['invoice_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];
														$invoice['invoice_number'] = $eachRecord['invoice_number'];
														$invoice['invoice_beneficiary_name'] = $eachRecord['beneficiary_name'];
														$invoice['invoice_beneficiary_number'] = $eachRecord['beneficiary_number'];
														$invoice['invoice_amount'] = $eachRecord['invoice_amount'];
														$invoice['invoice_date'] = date('Y-m-d',strtotime($eachRecord['invoice_date[dd-mm-yyyy]']));
														$invoice['invoice_deduction_days'] = $eachRecord['deduction_days'];
														$invoice['invoice_net']=  $eachRecord['net_or_gross']; 
														$invoice['invoice_status']=  'Pending';
														
														if(strtoupper($invoiceDetails->invoice_net)=='NET')
														{					
															$invoice['invoice_discount'] = ($customerDetails->interest_rate*($eachRecord['invoice_amount']*$eachRecord['deduction_days'])/365)/100;
															$invoice['invoice_topaid'] = $invoice['invoice_amount']-$invoice['invoice_discount'];
														}else{
															$invoice['invoice_discount'] = 0;
															$invoice['invoice_topaid'] = $invoice['invoice_amount'];
														} 
														
														if(count($invoiceResults)==0)
														{
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->InsertCommon('invoice_details',$invoice);
														}
														else 
														{
															$where = array('invoice_number'=>$eachRecord['invoice_number'],'invoice_vendor_id' => $invoice['invoice_vendor_id'],'invoice_status'=>'Pending');
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$invoice);
														}
														
													
												}
												
											}
											
											$code = '';                     
											$res = copy($readPath, $donePath); 
											if($res)
											{
											//$unlink = INVOICE_UNLINK.$valCF;
											$unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF;
											$res = unlink($unlink);
											}
											
											$this->vendor_model->logdetails('Cron details updated for invoice file name:'.$valCF,'invoice');
											
											$this->session->set_flashdata('Success', 'Vendor invoice details imported successfully');
											//redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
											
										}
										else
										{
											
											//echo $unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF; exit;
											$res = copy($readPath, $errorPath);
											$res = copy($readPath, $donePath); 
											if($res)
											{
												
											$unlink = CUS_INVOICE_READFROM.$key."/invoice/".$valCF;
											$res = unlink($unlink);
											echo "File Successfully deleted"; exit;
											}

											$this->vendor_model->logdetails('Cron details not updated for invoice file name:'.$valCF,'invoice');
											$this->session->set_flashdata('invoice_import_error', $error_report_list);
											//redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
										}

										

								}
							}
						}	
					}	
				}
				else
				{
					$data['page'] = 'admin/pages/readInvoiceExcel';
					$data['invoiceFile'] = $custoInvoices;
					$this->load->view('admin/template',$data);
					

				}

				

                /* exit;

				if(isset($_POST['invoice_ids']))
				{	
						
					foreach($custoInvoices as $key=>$eachfiles)
                    {	
						
						if(array_key_exists($key,$invoice_files_key))
						{
										$readPath = $path.$eachfiles;
										$movePath = $newpath.$eachfiles;
										$invoiceArray =   $this->CSVreader->parse_file($readPath);//path to csv file
										$respons = $this->ValidateArraywithColumns($invoiceArray);
										$flg=$respons['flag'];
										if($flg==1)
										{
											foreach($invoiceArray as $eachRecord)
											{
												$invoice =array(); $userexist=0; $vendor=array();

												$where = array('cust_user_code'=>$eachRecord['customer_code']);
												$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');

												$arrayCheck = array('vendor_code'=>$eachRecord['vendor_code'],'vendor_cust_id'=>$customerDetails->cust_id);
												$results = $this->vendor_model->get_DatabyCommon('vendor_details',$arrayCheck,'*');
												
												if(count($customerDetails)>0 && $eachRecord['vendor_code']!='')
												{
													if(count($results)>0)
													{
														$userexist = 1;
														$invoice['invoice_vendor_id'] = $results->vendor_id;
														$invoice['invoice_cust_id']   = $results->vendor_cust_id;									
														
														$vendor['vendor_name'] = $eachRecord['beneficiary_name'];
														$vendor['vendor_account_no'] = $eachRecord['beneficiary_number'];
														$vendor['vendor_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];

														$where = array('vendor_id'=>$results->vendor_id);
														$this->vendor_model->UpdateDatabyCommon('vendor_details',$where,$vendor);

													}
													else{

														$vendor['vendor_code']    = ($eachRecord['vendor_code'])?$eachRecord['vendor_code']:'';
														$vendor['vendor_cust_id'] = ($customerDetails->cust_id)?$customerDetails->cust_id:'';
														$vendor['vendor_name'] = ($eachRecord['beneficiary_name'])?$eachRecord['beneficiary_name']:'';
														$vendor['vendor_account_no'] = ($eachRecord['beneficiary_number'])?$eachRecord['beneficiary_number']:'';
														$vendor['vendor_ifsc_code'] = ($eachRecord['beneficiary_ifsc_code'])?$eachRecord['beneficiary_ifsc_code']:'';
														

														$vendor_id = $this->vendor_model->InsertCommon('vendor_details',$vendor);
														$invoice['invoice_vendor_id'] = $vendor_id;
														
														$invoiceResults = $this->vendor_model->get_DatabyCommon('invoice_details',
														array('invoice_vendor_id'=>$invoice['invoice_vendor_id'],'invoice_number'=>$eachRecord['invoice_number']),'*');

														$invoice['invoice_cust_id'] = $customerDetails->cust_id;
														$invoice['invoice_ifsc_code'] = $eachRecord['beneficiary_ifsc_code'];
														$invoice['invoice_number'] = $eachRecord['invoice_number'];
														$invoice['invoice_beneficiary_name'] = $eachRecord['beneficiary_name'];
														$invoice['invoice_beneficiary_number'] = $eachRecord['beneficiary_number'];
														$invoice['invoice_amount'] = $eachRecord['invoice_amount'];
														$invoice['invoice_date'] = date('Y-m-d',strtotime($eachRecord['invoice_date']));
														$invoice['invoice_deduction_days'] = $eachRecord['deduction_days'];
														$invoice['invoice_net']=  $eachRecord['net_or_gross']; 
														$invoice['invoice_status']=  'Pending';
														
														if(strtoupper($invoiceDetails->invoice_net)=='NET')
														{					
															$invoice['invoice_discount'] = ($customerDetails->interest_rate*($eachRecord['invoice_amount']*$eachRecord['deduction_days'])/365)/100;
															$invoice['invoice_topaid'] = $invoice['invoice_amount']-$invoice['invoice_discount'];
														}else{
															$invoice['invoice_discount'] = 0;
															$invoice['invoice_topaid'] = $invoice['invoice_amount'];
														} 
														
														if(count($invoiceResults)==0)
														{
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->InsertCommon('invoice_details',$invoice);
														}
														else 
														{
															$where = array('invoice_number'=>$eachRecord['invoice_number'],'invoice_vendor_id' => $invoice['invoice_vendor_id'],'invoice_status'=>'Pending');
															$invoice['created_by'] = $member_id;
															$invoice['created_date'] = date('Y-m-d H:i:s');
															$this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$invoice);
														}
														
													}
												}
												
											}
												
											
											
											$code = '';                     
											$res = copy($readPath, $movePath); 
											if($res){
											$unlink = INVOICE_UNLINK.$eachfiles;
											$res = unlink($unlink);
											}
											
											$this->vendor_model->logdetails('Cron details updated for invoice file name:'.$eachfiles,'invoice');
											
											$this->session->set_flashdata('Success', 'Vendor invoice details imported successfully');
											//redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
											
										}
										else
										{
											 $this->vendor_model->logdetails('Cron details not updated for invoice file name:'.$eachfiles,'invoice');
											 $this->session->set_flashdata('invoice_import_error', 'Vendor invoice details not updated');
											 //redirect(ADMINBASEURL.'bankadmin/readExcel','refresh');
										}

										
						}
				    } 
				   
				}
				else
				{
					$data['page'] = 'admin/pages/readInvoiceExcel';
					$data['invoiceFile'] = $custoInvoices;
					$this->load->view('admin/template',$data);
					

				} */
        }
     public function vendorInvoiceMainPage()
        {
            /*Invoice count based on vendor code and listed below. for now not linked in menu*/
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/vendorInvoiceMainpage';
            $data['siteSettings'] = $this->data['siteSettings'];
            $invoiceListArray = $this->dashboard_model->vendorCodeandCountMainPage();
            
            foreach($invoiceListArray as $each)
            {
                $arrayList ='';
                $where = array('cust_id'=>$each->vendor_cust_id);
                $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
                
                $mclr = $customerDetails->mclr_percent;
                $perimum = $customerDetails->strategic_premium_rate;
                $risk = $customerDetails->risk_premium_rate;
                $interestRate = $mclr+$perimum+$risk;
                
                $arrayList = $each;
                $arrayList->interestRate = $interestRate;
                $data['invoiceList'][] = $arrayList;
            }
            
            $this->load->view('admin/template',$data);
        }
        
        public function Invoiceviewandupdate()
        {
            
            /*Single invoice with status change status option */
            $this->IsloggedIn();          
			$id=$this->encryption->decrypt(str_replace(" ","+",$this->input->get('id')));
			
			$this->load->model('invoice_loan_limit');
            $data['page'] = 'admin/pages/invoiceview';
            $data['siteSettings'] = $this->data['siteSettings'];
            $invoicedetailsarray = $this->vendor_model->get_DatabyCommon('invoice_details',array('invoice_id'=>$id),'*');
            $data['invoicedetails'] = $invoicedetailsarray;
			
			$data['limitcheck'] = $this->invoice_loan_limit->customerBasedLoanLimit($invoicedetailsarray->invoice_id,$invoicedetailsarray->invoice_cust_id);			
			
            $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$invoicedetailsarray->invoice_cust_id),'*');
            
			if($invoicedetailsarray->invoice_deduction_days<=90)
			{
				$mclr_cal=$customerDetails->three_mclr; 
			}elseif($invoicedetailsarray->invoice_deduction_days<=180)
			{
				$mclr_cal=$customerDetails->six_mclr; 
			}elseif($invoicedetailsarray->invoice_deduction_days<=270)
			{
				$mclr_cal=$customerDetails->nine_mclr; 
			}else{
				$mclr_cal=$customerDetails->mclr_twelve; 	
			}
			
			$data['interestRate'] = $mclr_cal+$customerDetails->strategic_premium_rate+$customerDetails->risk_premium_rate;   
			
			$all_invoice_document=$this->vendor_model->get_all_invoice_document($id);   
 			$data['documents']=$all_invoice_document; 
 			$data['cust_user_code']=$customerDetails->cust_user_code; 
			$customer_path=str_replace('{CUST_CODE}',$customerDetails->cust_user_code,UPLOADS_CUST_DOC);
			$customer_path=str_replace('./',CUSTOMERBASEURL,$customer_path);
			$data['customer_path']=$customer_path;
            $this->load->view('admin/template',$data);
        }
        
        public function Invoicestatusupdate()
        {		
            
            /*Single invoice with status change status option update in database */
            $this->IsloggedIn();
            $id_array = $this->input->post('invoice_id');
		
			$this->load->model('invoice_loan_limit');			
			
			 $status=$this->encryption->decrypt(str_replace(" ","+",$this->input->post('status')));
			 $customer_id=str_replace(" ","+",$this->input->post('customer_id'));			
			
			foreach($id_array as $each) 
			{	
				$invoice_array[]=$this->encryption->decrypt($each);
			}
		
			$flag=4;
			if(count($invoice_array)>0)
			{
				$cust_id=$customer_id;				
				$flag=$this->invoice_loan_limit->customerBasedLoanLimit($invoice_array,$cust_id);
			}
			
		
			
			$customer_id=str_replace(" ","+",$this->input->post('customer_id'));		
			$status_url=str_replace(" ","+",$this->input->post('status'));			
            $invoice_status = $this->input->post('invoice_status');
			if($invoice_status == 'Rejected'){
				if(count($invoice_array)>0)
				{		
					foreach($invoice_array as $key=>$invoice_id){						
						$reason =$this->input->post('reject_reason');											
						$this->customer_model->update_rejected_reason($invoice_id,$reason,'Rejected');	;
					}
				}
			}
			
			if($id_array!=''){
				
			$success=0;
			$error=0;
			$error_msg='<b>Limit Exceeded For The Bellow Invoice</b>';
			if($invoice_status=='Rejected' OR $invoice_status=='Pending')
			{
				$flag=0;
			}
			/* $flag=0 */;
			if($flag==0)	
			{
				foreach($id_array as $each) 
				{		  
					$each=$this->encryption->decrypt($each);
					$where = array('invoice_id'=>$each);
					$invoiceDetails = $this->vendor_model->get_DatabyCommon('invoice_details',$where,'*');		   			
					$where = array('invoice_id'=>$each);          				
					$interestRateCalc = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$invoiceDetails->invoice_cust_id),'*');

					if($invoiceDetails->invoice_deduction_days<=90)
						{
							$mclr=$interestRateCalc->three_mclr; 
						}elseif($invoiceDetails->invoice_deduction_days<=180)
						{
							$mclr=$interestRateCalc->six_mclr; 
						}elseif($invoiceDetails->invoice_deduction_days<=270)
						{
							$mclr=$interestRateCalc->nine_mclr; 
						}else{
							$mclr=$interestRateCalc->mclr_twelve; 	
						}
						
					$interestRate = $interestRateCalc->strategic_premium_rate+$mclr+$interestRateCalc->risk_premium_rate;
					
					
					
				  
					if(strtoupper($invoiceDetails->invoice_net)=='NET')
					{					
						$discount = ($interestRate*($invoiceDetails->invoice_amount*$invoiceDetails->invoice_deduction_days)/365)/100;
					}else{
						$discount = 0;
					}  

					$topaid = $invoiceDetails->invoice_amount - $discount;               
										
					 $limitcheck = $this->invoice_loan_limit->customerBasedLoanLimit($each,$invoiceDetails->invoice_cust_id);
					
					$error_msg.='<ul>';					
					if($invoice_status=='Rejected' OR $invoice_status=='Pending')
					{
						$limitcheck=0;
					}	
			
					if($limitcheck==0 && $flag==0)
					{						
						$where   = array('invoice_id'=>$each);                
						$options = array('invoice_status'=>$invoice_status,'invoice_discount'=>$discount,'invoice_topaid'=>$topaid,'status_updated_datetime'=>date('Y-m-d H:i:s'));
						$this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$options);
						if($invoice_status=='Paid')
						{
							$balance_amt=(($interestRateCalc->cust_current_loan_balance)-($topaid));
							$where_cus  = array('cust_id'=>$invoiceDetails->invoice_cust_id);                
							$options_cus = array('cust_current_loan_balance'=>$balance_amt);
							$this->vendor_model->UpdateDatabyCommon('customer_deails',$where_cus,$options_cus);
						}
						//Activity log
						$desc = '#'.$each.' invoice status updated as '.$invoice_status; 
						$this->vendor_model->logdetails($desc,'invoice');
						$success=1;
					 }else{					
						$error=1;
						
						if($limitcheck=='1')
						{
							$error_msg.='<li><b>Exceeded:</b> Yearly limit</li>';
						}elseif($limitcheck=='2')
						{
							$error_msg.='<li><b>Exceeded:</b> Weekly limit</li>';
						}else
						{
							$error_msg.='<li><b>Exceeded:</b> Monthly limit</li>';
						}
						
						$error_msg.='<li><b>Invoice Number:</b> '.$invoiceDetails->invoice_number.'</li>';			
						$error_msg.='<li><b>Customer Name:</b> '.$interestRateCalc->cust_name.'</li>';							
						$error_msg.='</ul>----------------------------';					
					}
				} 
			}else{
				$error=1;
				if($flag=='1')
					{
						$error_msg='<div><b>Yearly</b> Limit Exceeded</div>';
					}elseif($flag=='2')
					{
						$error_msg='<div><b>Monthly</b> Limit Exceeded</div>';
					}else
					{
						$error_msg='<div><b></b>Weekly Limit Exceeded</div>';
					}				
			}
			
					
				if($success==1)
				{					
					 $json_data = array(
						"message"            => 1,
						"data"            => INFO_C402   
					);				
				}
				
				if($error==1)
				{					
					 $json_data = array(
						"message"            => 0,
						"data"            => $error_msg   
					);
				}
			
			}else{
				 $json_data = array(
					"message"            => 0,
					"data"            => ERROR_C416   
				);				
			}	
			
			echo json_encode($json_data); 
			exit; 			
        }
        
        public function vendorInvoiceDues()
        {			
            $this->IsloggedIn(); #invoiceList			
            $data['page'] = 'admin/pages/vendorInvoiceDues';
            $data['siteSettings'] = $this->data['siteSettings'];			
            $id=$this->active_user;
			$data['customer_id'] = $this->session->userdata('active_cust_id');
			$this->load->model('invoice_loan_limit');			
			$data['status']=$this->encryption->decrypt(str_replace(" ","+",$this->input->get('status')));
            $data['mode'] = 'update';
            $this->load->view('admin/template',$data);
        }
        
        public function ApprovedInvoice()
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/approvedInvoice';
            $data['siteSettings'] = $this->data['siteSettings'];
            
                  
            $this->load->view('admin/template',$data);
        }
		
        public function RegictedInvoice()
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/approvedInvoice';
            $data['siteSettings'] = $this->data['siteSettings'];
            
            $invoiceListArray = $this->dashboard_model->approvedInvoicegroupbyAccountno();
         
            foreach($invoiceListArray as $each)
            {
                $arrayList ='';
                $where = array('cust_id'=>$each->invoice_cust_id);
                $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
                
                $mclr = $customerDetails->mclr_percent;
                $perimum = $customerDetails->strategic_premium_rate;
                $risk = $customerDetails->risk_premium_rate;
                $interestRate = $mclr+$perimum+$risk;
                
                $arrayList = $each;
                $arrayList->interestRate = $interestRate;
                $data['invoiceList'][] = $arrayList;
            }           
            $this->load->view('admin/template',$data);
        }
        
        public function viewmapped()
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/vendorInvoiceDues';
            $data['siteSettings'] = $this->data['siteSettings'];
            
         
			$number=$this->encryption->decrypt(str_replace(" ","+",$this->input->get('id')));
			$cpage=$this->input->get('cpage');
            $invoiceListArray = $this->dashboard_model->getInvoicebyAccountno($number);
            
            foreach($invoiceListArray as $each)
            {
                $arrayList ='';
                $where = array('cust_id'=>$each->invoice_cust_id);
                $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
                
                $mclr = $customerDetails->mclr_percent;
                $perimum = $customerDetails->strategic_premium_rate;
                $risk = $customerDetails->risk_premium_rate;
                $interestRate = $mclr+$perimum+$risk;                                
                $arrayList = $each;
                $arrayList->interestRate = $interestRate;
                $data['invoiceList'][] = $arrayList;
            }
			
			$data['number'] = $number;
            $data['mode'] = 'view';
			$data['cpage'] = $cpage;
            $this->load->view('admin/template',$data);
        }
        
        public function viewmappedpaid($param='') 
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/vendorInvoiceDues';
            $data['siteSettings'] = $this->data['siteSettings'];
            
            $number = $this->input->get('id');
			$cpage=$this->input->get('cpage');
            
            
           
			 $data['number'] = $number;
            $data['mode'] = 'view';
			 $data['cpage'] = $cpage;
			
            $this->load->view('admin/template',$data);
        }        
        public function approvedNEFT()
        {
            $invoiceListAccount = $this->dashboard_model->approvedInvoicegroupbyAccountno();
            $i = 1; 
            foreach($invoiceListAccount as $eachAccount)
            {
                $transactionid = 'TXN'.date('Ymdhis').$i;
                $invoiceListArray = $this->dashboard_model->getInvoicebyAccountno($eachAccount->invoice_beneficiary_number);
            
                foreach($invoiceListArray as $invoice)
                {
					
					$cust_current_loan_balance=($invoice->cust_current_loan_balance-$invoice->invoice_topaid);					
					$where_cus = array('cust_id'=>$invoice->cust_id);
                    $update_cus = array('cust_current_loan_balance'=>$cust_current_loan_balance);
					$this->vendor_model->UpdateDatabyCommon('customer_details',$where_cus,$update_cus);					
                    $where = array('invoice_id'=>$invoice->invoice_id);
                    $update = array('invoice_transactionid'=>$transactionid,'invoice_status'=>'Paid','payment_datetime'=>date('Y-m-d H:i:s'));
					$changedItems="Invoice id:".$invoice->invoice_id.", Amount:".$invoice->invoice_topaid;
					if($changedItems!='')
					{
						$this->vendor_model->logdetails('NEFT Transaction Details '.$changedItems.'','invoice');
					}					
                    $this->vendor_model->UpdateDatabyCommon('invoice_details',$where,$update);
					
                }  
                $i++;
            }
            $this->session->set_flashdata('Success', INFO_C405);
            redirect(ADMINBASEURL.'bankadmin/ApprovedInvoice','refresh');
        }        
        public function paidInvoices()
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/paidInvoice';
            $data['siteSettings'] = $this->data['siteSettings'];
            $invoiceListArray = $this->dashboard_model->paidInvoicegroupbytransactionID();
            $data['invoiceList'] = $invoiceListArray;
            $this->load->view('admin/template',$data);
        }        
        public function limitcheckforcustomers($cust_id,$topaid=0)
        {
            $flag = 0;
            $customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',array('cust_id'=>$cust_id),'*');
            
            $cust_current_loan_balance = $customerDetails->cust_current_loan_balance;
            $actualWeekLimit = $customerDetails->cust_weekly_loan_limit;
            $actualMonthLimit = $customerDetails->cust_monthly_loan_limit;
            $TotalLoanLimit = $customerDetails->cust_loan_limit;
            
            $getSumofWeek = $this->dashboard_model->getweeklylimit($cust_id);            
            $weekamount = $getSumofWeek[0]->week_amount;
            $weekamount = $weekamount+$topaid;
			
            $getSumofMonth = $this->dashboard_model->getmonthlylimit($cust_id);
            $monthamount = $getSumofMonth[0]->month_amount;
            $monthamount = $monthamount+$topaid;
			
            /*
			$getTotalSum = $this->dashboard_model->getTotallimit($cust_id);
            $TotalLimit  = $getTotalSum[0]->total_amount;
            if($TotalLoanLimit<=$TotalLimit)
            {
                $flag = 1;
            }*/
			
            if($cust_current_loan_balance<$topaid)
			{
				 $flag = 1;
			}
            if($actualWeekLimit<=$weekamount)
            {
                $flag = 2;
            }
            if($actualMonthLimit<=$monthamount)
            {
                $flag = 3;
            }
            echo $flag;
            
            return $flag;
        }        
        function balanceCalculations($cust_id)
        {
            
            $actual_limit = $this->vendor_model->get_DatabyCommon('customer_details',
                    array('cust_id'=>$cust_id),'cust_current_loan_balance AS cust_current_loan_balance');
            $full_limit = $actual_limit->cust_current_loan_balance;
            $used = $this->vendor_model->get_DatabyCommon('invoice_details',
                    array('invoice_status ='=>'Paid',
                    'invoice_cust_id'=>$cust_id),'sum(invoice_amount) as amountused');
            
            $paid = $this->vendor_model->get_DatabyCommon('cust_replenishment',
                    array('cust_id'=>$cust_id),'sum(amount) as amountpaid');
            
         
            $full_limit_with_paid = $full_limit+$paid->amountpaid;
            
            $balance = $full_limit_with_paid - $used->amountused;		

            /*echo "Full Limit ".$full_limit;
            echo '<br>';echo '<br>';
            
            echo "Amount Paid ".$paid->amountpaid;
            echo '<br>'; echo '<br>';
            echo "Amount Used ".$used->amountused;
            echo '<br>'; echo '<br>';
            echo "Amount Remaining ".$balance;*/
            
            return $balance;
        }        
        function replenishment()
        {
            $id = $this->input->post('id');
            if($id!='' && is_numeric($id))
            {
                $where = array('id'=>$id);
            }
            else {
                $where = '';
            }
            /*repayment of admin */
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/replenishment';
            $data['siteSettings'] = $this->data['siteSettings'];
            $repay = $this->dashboard_model->getreplenishmentlist($id);
            
            $data['repay'] = $arraged;
            $this->load->view('admin/template',$data);
        }
        
        function replenishmentVerification()
        {
            
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('cust_id', 'customer id', 'required');
            $this->form_validation->set_rules('amount', 'amount desposited', 'required|numeric');
            $this->form_validation->set_rules('transaction_number', 'transaction number', 'required');
            $this->form_validation->set_rules('date_created', 'date of Transaction', 'required');
            $this->form_validation->set_rules('drawn_bank', 'Cheque drawn on bank', 'required');
            $this->form_validation->set_rules('transition_remarks', 'Transition remarks', 'required');
            if ($this->form_validation->run()=='TRUE') {
                
                $date_created = $this->input->post('date_created');
                $cust_name   = $this->input->post('cust_name');
                preg_match('#\((.*?)\)#', $cust_name, $match);
                $cust_code = $match[1];
                
				$cust_id=$this->encryption->decrypt(str_replace(" ","+",$this->input->post('cust_id')));
				
				if($cust_id>0)
				{
					$repay['cust_id']      = $cust_id;
					$repay['amount']      = $this->input->post('amount');
					$repay['transaction_number'] = $this->input->post('transaction_number');
					$repay['date_created']  = date('Y-m-d',strtotime($date_created));
					$repay['drawn_bank']      = $this->input->post('drawn_bank');
					$repay['transition_remarks']      = $this->input->post('transition_remarks');                
					$this->vendor_model->InsertCommon('cust_replenishment',$repay);		
					$result = $this->session->userdata('member'); 
					if(!empty($result)){
					$member_id = $result['member_id'];
					$where = array('user_id'=>$member_id);

					$userdetails = $this->vendor_model->get_DatabyCommon('user_details',$where,'*');

					$this->vendor_model->logdetails($userdetails->user_name.' New entry for Replenishment added','Master Details');
					}					
					$this->session->set_flashdata('Success', INFO_A602);
				}else{
					 $this->session->set_flashdata('Error', ERROR_A601);
				}
                redirect(ADMINBASEURL.'bankadmin/replenishment','refresh');
            }
            else
            {
                $repay->cust_id   = $this->input->post('cust_id');
                $repay->amount      = $this->input->post('amount');
                $repay->transaction_number = $this->input->post('transaction_number');
                $repay->date_created  = $this->input->post('date_created');
                $repay->drawn_bank  = $this->input->post('drawn_bank');
                $repay->transition_remarks  = $this->input->post('transition_remarks');   
            }
            
            $data['page'] = 'admin/pages/replenishment';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['repay'] = $repay;
            $this->load->view('admin/template',$data);
        }
		
        function replenishmentlist()
        {
            /*repayment of admin listing*/
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/replenishmentlist';
            $data['siteSettings'] = $this->data['siteSettings'];
           /*  $replenishmentArray = $this->dashboard_model->getreplenishmentlist();
            
            $data['replenishmentlist'] = $replenishmentArray; */
            $this->load->view('admin/template',$data);
        }
        public function getReplenishmentListJson(){
			
			$columns = array( 
							0 =>'id',
							1 =>'cust_name',
							2 =>'transaction_number',
							3 =>'amount',
							4 =>'drawn_bank',
							5 =>'date_created',	
								
							); 	
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];	
				$select_query=$this->dashboard_model->getreplenishmentlist_query(); 
				 $groupby =" ";
				 $totalData = $this->dashboard_model->allJoinPostsCount('',$select_query,$groupby);

				 $totalFiltered = $totalData; 

				if(empty($this->input->post('search')['value']))
				{   
			
				$posts = $this->dashboard_model->allJoinPosts('',$limit,$start,$order,$dir,$select_query,$groupby);    
				}
				else { 
				$search = $this->input->post('search')['value']; 
				$posts =  $this->dashboard_model->JoinPostsSearch('',$limit,$start,$search,$order,$dir,$columns,$select_query,$groupby);
				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount('',$search,$columns,$select_query,$groupby);
			 	} 	
				
				$data = array();
				if(!empty($posts))
				{
					$i=1;
					foreach ($posts as $post)
					{
								$nestedData['id'] = $post->id;
						$nestedData['cust_name'] =  $post->cust_name;	
						$nestedData['transaction_number'] = $post->transaction_number;						
						$nestedData['amount'] = $post->amount;
						$nestedData['drawn_bank'] =  $post->drawn_bank;
						$nestedData['date'] = date('Y-m-d',strtotime($post->date_created));
						$nestedData['delete'] = " &nbsp;&nbsp;<i class='fa fa-trash clickrepaydelete' title='Delete' data-id=".$post->id."></i>
                       &nbsp;&nbsp;";

						$data[] = $nestedData;
						$i++;
					} 
				}
			
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
		}
        function pendingInterestRates()
        {
            /*Interest rates of admin listing*/
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/interestRateList';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['interestlist'] = $this->dashboard_model->getInterestlist();
            
            $this->load->view('admin/template',$data);
        }
		
		
		function masterRatesActivate()
        { 
			$this->IsloggedIn();
			$rate_id=0;
			if($this->uri->segment(3)>0)
			{
				$rate_id=$this->uri->segment(3);
				$this->dashboard_model->ActivateMasterRate($rate_id); 
				$this->session->set_flashdata('Success', INFO_C403);
			}
			 redirect(ADMINBASEURL.'bankadmin/masterRates','refresh');
		}
        function masterRates()
        {
            /*Interest rates of admin listing*/
            $this->IsloggedIn();					
            $data['page'] = 'admin/pages/master_rates';
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['interestlist'] = $this->dashboard_model->getMasterRates();            
            $this->load->view('admin/template',$data);
        }
		function getMasterRates(){
		
		 $columns = array( 
				0 =>'rate_id', 				
				1 =>'3mclr',		
				2 =>'6mclr',
				3 =>'9mclr',
				4 =>'12mclr',	
				5 =>'strategic_premium',	
				6 =>'risk_premium',		
				7 =>'cust_interest_rate',				
				8 =>'status',
				9 =>'effective_from',
				10 =>'effective_to',					
				); 	
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];
				 $select_query = $this->dashboard_model->getMasterRates(); 
		$group_by ="";
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{   

				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
               
			}
			else {
				$search = $this->input->post('search')['value']; 

				 $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}
		
		       $data = array();
				$i=1;
					foreach ($posts as $post)
					{						
						$arrayClasses = array('Approved'=>'label-success','Pending'=>'label-warning');
						$nestedData['rate_id'] = $post->rate_id;
						$nestedData['threemclr'] =$post->threemclr;
						$nestedData['sixmclr'] =$post->sixmclr;
						$nestedData['ninemclr'] =$post->ninemclr;
						$nestedData['twelvemclr'] =$post->twelvemclr;
						$nestedData['strategic_premium'] =$post->strategic_premium;
						$nestedData['risk_premium'] =$post->risk_premium;
						$nestedData['status'] =$post->status;
						$nestedData['effective_from'] =$post->effective_from;
						$nestedData['effective_to'] =$post->effective_to;
						$nestedData['action'] ="";
						
						if($post->status=='Pending'){
							$link =ADMINBASEURL.'/bankadmin/masterRatesActivate/'.$post->rate_id;
							 $nestedData['action']="<a class='btn btn-primary btn-xs' href=".$link." onclick='return confirm('Are you sure you want to approve this?');' name='cust_interest_id'/>Approve</a> ";
						} 
							
						$data[] = $nestedData;
						$i++;
					}
				
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 			
		
		}
		
        function masterrateslist()
		{
			/* Interest rates list form of admin */
			$this->IsloggedIn();
			$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
			$this->form_validation->set_rules('mclr3','values','required|trim|numeric|less_than[100]|greater_than[0]');
			$this->form_validation->set_rules('mclr6','values','required|numeric|less_than[100]|greater_than[0]');
			$this->form_validation->set_rules('mclr9','values','required|numeric|less_than[100]|greater_than[0]');
			$this->form_validation->set_rules('mclr12','values','required|numeric|less_than[100]|greater_than[0]');
			$this->form_validation->set_rules('strategic_premium','values','required|numeric|less_than[100]|greater_than[0]');
			$this->form_validation->set_rules('risk_premium','values','required|numeric|less_than[100]|greater_than[0]');
	
			if($this->form_validation->run() == 'TRUE')
			{
				$insert['3mclr'] = $this->input->post('mclr3');
				$insert['6mclr'] = $this->input->post('mclr6');
				$insert['9mclr'] = $this->input->post('mclr9');
				$insert['12mclr'] = $this->input->post('mclr12');
				$insert['strategic_premium'] = $this->input->post('strategic_premium');
				$insert['risk_premium'] = $this->input->post('risk_premium');
				$res = $this->vendor_model->masterlist($insert);
				 $result = $this->session->userdata('member'); 
			if(!empty($result)){
            $member_id = $result['member_id'];
            $where = array('user_id'=>$member_id);
			
            $userdetails = $this->vendor_model->get_DatabyCommon('user_details',$where,'*');
			
				$this->vendor_model->logdetails($userdetails->user_name.' New entry for Master Details added','Master Details');
            }
				$this->session->set_flashdata('Success',INFO_C502);
				redirect(ADMINBASEURL."bankadmin/masterRates","refresh");
			}
			else
			{
				$insert->mclr3 = $this->input->post('mclr3');
				$insert->mclr6 = $this->input->post('mclr6');
				$insert->mclr9 = $this->input->post('mclr9');
				$insert->mclr12 = $this->input->post('mclr12');
				$insert->strategic_premium = $this->input->post('strategic_premium');
				$insert->risk_premium = $this->input->post('risk_premium');
			}
			$data['interestrate'] = $insert;
			$data['page'] = 'admin/pages/masterrateslist';
            $data['siteSettings'] = $this->data['siteSettings'];		
            $this->load->view('admin/template',$data);
		}
        function InterestRateUpdate()
        {
            $array = $this->input->post('cust_interest_id');
            $status = $this->input->post('interest_status');
            
            foreach($array as $id)
            {
                $interestDetails = $this->vendor_model->get_DatabyCommon('customer_interest_rate',array('cust_rate_id'=>$id),'*');
                
                
                if($status=='Approved')
                {
                    $this->vendor_model->UpdateDatabyCommon('customer_details',
                            array('cust_id'=>$interestDetails->cust_rate_cust_id),array('interest_rate'=>$interestDetails->cust_interest_rate));
                }
                
                $this->vendor_model->UpdateDatabyCommon('customer_interest_rate',
                            array('cust_rate_cust_id'=>$interestDetails->cust_rate_cust_id),array('status'=>$status));
            }
            $this->session->set_flashdata('Success', INFO_C503);
            redirect(ADMINBASEURL.'bankadmin/pendingInterestRates','refresh');
        }
        
        function autocompleteofcustomers()
        {
            $this->dashboard_model->autocompleteCustomers();
            
        }
		public function customerBasedReport()
		{
			
			if(isset($_POST['reset']))
			{		
			$this->session->set_userdata('filter_from',  '');
				$this->session->set_userdata('filter_to', '');
				$_POST['filter_from']='';
				$_POST['filter_to']='';
			
			}elseif(count($_POST)>0)
			{
				
				$this->session->set_userdata('filter_from', $this->input->post('filter_from'));
				$this->session->set_userdata('filter_to', $this->input->post('filter_to'));
					
			} 
			
			$_POST['filter_from']=$this->session->userdata('filter_from');
			$_POST['filter_to']=$this->session->userdata('filter_to');
			
			$data['filter_from']=$this->input->post('filter_from');
			$data['filter_to']=$this->input->post('filter_to');
			
			$this->IsloggedIn();
            $data['page'] = 'admin/pages/customerBasedReport';
            $data['siteSettings'] = $this->data['siteSettings'];
            $invoiceReport = $this->dashboard_model->customerBasedReport($data['filter_from'],$data['filter_to']);
            $data['invoiceReport'] = $invoiceReport;
            $this->load->view('admin/template',$data);
		}		
		public function reportCustomerReceivable() {
			
			$this->IsloggedIn(); #is logged in ..? 
			 $customer_id =	$this->session->userdata('active_cust_id');
		
            $data['siteSettings'] = $this->data['siteSettings'];
			$where_array=array(
					'cust_id'=>$customer_id
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			
			$invoice_data=$this->customer_model->get_replenishments_due();
            
			$data['invoice_data']=$invoice_data; 
			$data['resul_customer']=$resul_customer; 
			$data['page']='admin/pages/reportReplenishmentDue'; 
			$data['basic_active']='active';
			$this->load->view('admin/template',$data);
			
		}
		public function reportVendorPayments(){
			$this->IsloggedIn();
			$customer_id =	$this->session->userdata('active_cust_id');
			$data['siteSettings'] = $this->data['siteSettings'];
			$where_Array=array();
			$filter_from_date_R=$_POST['filter_from'];
			$filter_to_date_R=$_POST['filter_to'];
			
			if($this->input->get('filter_from')!=""){
				$filter_from_date_R=$this->input->get('filter_from');
			}
			if($this->input->get('filter_to')!=""){
				$filter_to_date_R=$this->input->get('filter_to');
				$where_Array['invoice_status']='Paid';
			}
		
			 if($filter_from_date_R!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($filter_from_date_R));
				$where_Array['payment_datetime >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if($filter_to_date_R!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($filter_to_date_R));
				$where_Array['payment_datetime <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			
			 $invoice_data=$this->customer_model->get_all_invoice_by_vendor($where_Array);
			
			 $data['invoice_data']=$invoice_data; 
			$data['invoice_type']='Vendor'; 
			$data['page']='admin/pages/reportVendorPayments';
			$data['vp_active']='active';
            $this->load->view('admin/template',$data);
		}
		
	public function report_invoice_by_vendor($vendor)
        { 
			$this->IsloggedIn(); #is logged in ..? 
			if($vendor==''){
				redirect(ADMINBASEURL.'bankadmin');
			}
			$customer_id =	$this->session->userdata('active_cust_id');
			$where_Array=array();
			 if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
				$where_Array['invoice_date >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if(count($_POST)>0&& $_POST['filter_to']!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
				$where_Array['invoice_date <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			
            $data['siteSettings'] = $this->data['siteSettings'];
			$invoice_data=$this->customer_model->get_all_invoice_by_vendor_list($vendor,$where_Array);  
		//	echo $this->db->last_query();
			$data['invoice_data']=$invoice_data; 
			$data['invoice_type']=base64_decode($vendor); 
			$data['page']='admin/pages/reportInvoiceByVendor';
			$data['vp_active']='active';
            $this->load->view('admin/template',$data);
            
        } 
		public function vendorBasedReport()
		{
			$this->IsloggedIn();
			$cust_id=0;
			if($this->uri->segment(3)>0)
			{
				$cust_id=$this->uri->segment(3);
			}
			
			/* if(isset($_POST['reset']))
			{		
				$this->session->set_userdata('filter_from',  '');
				$this->session->set_userdata('filter_to', '');
				$_POST['filter_from']='';
				$_POST['filter_to']='';			
			}elseif(count($_POST)>0)
			{
				
				$this->session->set_userdata('filter_from', $this->input->post('filter_from'));
				$this->session->set_userdata('filter_to', $this->input->post('filter_to'));
					
			} 
			
			$_POST['filter_from']=$this->session->userdata('filter_from');
			$_POST['filter_to']=$this->session->userdata('filter_to');
			
			$data['filter_from']=$this->input->post('filter_from');
			$data['filter_to']=$this->input->post('filter_to');
			
           
			$data['customer_deails'] = $this->dashboard_model->GetCustomerByID($cust_id);
            //$invoiceReport = $this->dashboard_model->vendorBasedReport($cust_id,$data['filter_from'],$data['filter_to']);
			$qry = $this->dashboard_model->vendorBasedReport($cust_id,$data['filter_from'],$data['filter_to']); */
            $data['cust_id'] = $cust_id;		   
		    $data['page'] = 'admin/pages/vendorBasedReport';
            $data['siteSettings'] = $this->data['siteSettings'];			
		    $data['invoiceReport'] = $invoiceReport;
            $this->load->view('admin/template',$data);
		}
		public function invoiceBasedReport()
		{
			$this->IsloggedIn();
			$vendor_id=0;			
			if($this->uri->segment(3)>0)
			{
				$vendor_id=$this->uri->segment(3);
			}
			if(isset($_POST['reset']))
			{		
			$this->session->set_userdata('filter_from',  '');
				$this->session->set_userdata('filter_to', '');
				$_POST['filter_from']='';
				$_POST['filter_to']='';
			
			}elseif(count($_POST)>0)
			{				
				$this->session->set_userdata('filter_from', $this->input->post('filter_from'));
				$this->session->set_userdata('filter_to', $this->input->post('filter_to'));					
			} 
			
			$_POST['filter_from']=$this->session->userdata('filter_from');
			$_POST['filter_to']=$this->session->userdata('filter_to');
			
			$data['filter_from']=$this->input->post('filter_from');
			$data['filter_to']=$this->input->post('filter_to');
			
            $data['page'] = 'admin/pages/invoiceBasedReport';
			 $data['vendor_id'] = $vendor_id;
            $data['siteSettings'] = $this->data['siteSettings'];			
			$data['vendor_deails'] = $this->dashboard_model->GetVendorByID($vendor_id);
            $invoiceReport = $this->dashboard_model->invoiceBasedReport($vendor_id,$data['filter_from'],$data['filter_to']);
            $data['invoiceReport'] = $invoiceReport;
            $this->load->view('admin/template',$data);
		}
		function getInvoiceBasedReportJson(){
			
			
			
			if($this->input->post('filter_from')){
				$filter_from= $this->input->post('filter_from');
			}
			
			
			if($this->input->post('filter_to')){
				$filter_to= $this->input->post('filter_to');
			}
			
			$active_cust_id="";	
			 $vendor_id =$this->input->get('vendor_id');
			$columns = array( 
				0 =>'invoice_id', 				
				1 =>'invoice_beneficiary_name', 
				2 =>'invoice_beneficiary_number', 
				3 =>'invoice_ifsc_code', 
				4 =>'invoice_transactionid', 
				5 =>'invoice_number', 
				6 =>'invoice_amount', 
				7 =>'invoice_discount', 
				8 =>'invoice_topaid', 
				9 =>'invoice_deduction_days', 
				10 =>'invoice_net', 
				11 =>'invoice_status', 				
				); 				
			
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
			
		    $select_query =  $this->dashboard_model->invoiceBasedReport($vendor_id,$filter_from,$filter_to);	
			$group_by ="";
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			 if(empty($this->input->post('search')['value']))
			{   

				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
               	
			}
			else {
				$search = $this->input->post('search')['value']; 

				 $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}
		
			
			
				$data = array();
				$vendor_details =array();
				$i=1;
					foreach ($posts as $post)
					{
					   		
						$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['invoice_beneficiary_name'] = $post->invoice_beneficiary_name;
						$nestedData['invoice_beneficiary_number'] = $post->invoice_beneficiary_number;
						$nestedData['invoice_ifsc_code'] = $post->invoice_ifsc_code;
						$nestedData['invoice_transactionid'] = $post->invoice_transactionid;
						$nestedData['invoice_number'] = $post->invoice_number;
						$nestedData['invoice_amount'] = $post->invoice_amount;
						$nestedData['invoice_discount'] = $post->invoice_discount;
						$nestedData['invoice_topaid'] = $post->invoice_topaid;
						$nestedData['invoice_deduction_days'] = $post->invoice_deduction_days;
						$nestedData['invoice_net'] = $post->invoice_net;
						$nestedData['invoice_status'] = $post->invoice_status;
						$vendor_details = "<span class='vsub_head' >Beneficiary Name : ".$post->invoice_beneficiary_name."</span><span class='vsub_head' >Beneficiary Number : ".$post->invoice_beneficiary_number."</span><span class='vsub_head' >IFSC Code : ".$post->invoice_ifsc_code."</span>";
						
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data  ,
				"vendor_details"            => $vendor_details  				
				);

				echo json_encode($json_data);  	 
		}
		
		function invoiceByCustomer()
		{
			$this->IsloggedIn();
			$status=$this->encryption->decrypt(str_replace(" ","+",$this->input->get('status')));		
            $data['page'] = 'admin/pages/invoiceByCustomer';
            $data['status'] = $status;			
            $data['siteSettings'] = $this->data['siteSettings'];			
            $customerInvoice = $this->dashboard_model->invoiceByCustomer($status);
            $data['customerInvoice'] = $customerInvoice;
            $this->load->view('admin/template',$data);
		}
		function DatatableAjax()
		{
			$this->IsloggedIn();					
            $data['page'] = 'admin/pages/DatatableAjax';           		
            $data['siteSettings'] = $this->data['siteSettings'];          
            $this->load->view('admin/template',$data);
		}
		

		
		
		
		/*Json result for paid Invoices*/
		public function getPaidInvoices(){
			$active_cust_id=$this->session->userdata('active_cust_id');			
		    $columns = array( 
				0=>'invoice_transactionid',
				1 =>'invoice_beneficiary_name',
				2 =>'invoice_beneficiary_name',
				3 =>'invoice_beneficiary_number',
				4 =>'invoice_amount',
				5 =>'invoice_topaid',	
				6 =>'invoice_date',	
				7 =>'payment_datetime',		
				8 =>'invoice_status',
9 =>'invoice_id',	
						
				); 
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];		
				$status= $this->input->get('status');
				$arrayClasses = array('Paid'=>'label-success','Verified'=>'label-info','Approved'=>'label-success','Rejected'=>'label-danger','Pending'=>'label-warning','Hold'=>'label-info');
			$select_query = "SELECT invoice_id ,payment_datetime,invoice_transactionid,invoice_cust_id,invoice_vendor_id,invoice_beneficiary_name, invoice_beneficiary_number, sum(invoice_amount) as invoice_amount,sum(invoice_discount) as invoice_discount,sum(invoice_topaid) as invoice_topaid,invoice_date,invoice_status FROM "
. "invoice_details where invoice_status ='Paid' AND invoice_cust_id=$active_cust_id ";
			$groupby=" group by invoice_transactionid ";	
	    $totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$groupby);
          
        $totalFiltered = $totalData; 
       
        if(empty($this->input->post('search')['value']))
        {   
	
            $posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$groupby);
		
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$groupby);

            $totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$groupby);
        }		
		
			    $data = array();
				if(!empty($posts))
				{
					$i=1;
					foreach ($posts as $post)
					{
								$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['invoice_transactionid'] = "<a href=".ADMINBASEURL."bankadmin/viewmappedpaid?id=".$post->invoice_transactionid."&cpage=paid_invoices>".$post->invoice_transactionid."</a>";			
						$nestedData['invoice_beneficiary_name'] = $post->invoice_beneficiary_name;						
						$nestedData['invoice_beneficiary_number'] = $post->invoice_beneficiary_number;
						$nestedData['invoice_topaid'] = number_format($post->invoice_topaid,2);
						$nestedData['payment_datetime'] = date('Y-m-d',strtotime($post->payment_datetime));
							
						$nestedData['status'] = "<span class='label ".$arrayClasses[$post->invoice_status]."'>".$post->invoice_status."</span> ";							
						$data[] = $nestedData;
						$i++;
					} 
				}
				
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
		}
		
		/*Returns json data for replenishments list*/
		public function getReplenishmentList(){
		$active_cust_id=$this->session->userdata('active_cust_id');
		    $columns = array( 
			    0 =>'replenishment_id',
				1 =>'transaction_number',
				2 =>'amount',
				3 =>'type',				
				4 =>'date_created',
					
				); 	
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];				
			$select_query = $this->dashboard_model->getreplenishmentlist_query();
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{ 
				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);             
			}
			else {
				$search = $this->input->post('search')['value']; 

				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}
			$data = array();
				$i=1;
					foreach ($posts as $post)
					{					
						$nestedData['replenishment_id'] = $post->id;
						$nestedData['transaction_number'] =$post->transaction_number;						
						$nestedData['amount'] =$post->amount;
						$nestedData['type'] =$post->type;
						$nestedData['date_created'] =date('Y-m-d',strtotime($post->date_created));
						$nestedData['delete'] ="   &nbsp;&nbsp;<i class='fa fa-trash clickrepaydelete' title='Delete' data-id=".$repay->id."></i>  &nbsp;&nbsp;";
									$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 		
		}
		/*Returns json data for CustomerReceivableReport*/
		public function getCustomerReceivableReport(){
			$active_cust_id=$this->session->userdata('active_cust_id');
			$columns = array( 
			    0 =>'invoice_id',
				1 =>'vendor_code',
				2 =>'invoice_amount',
				3 =>'invoice_net',
				
				4 =>'invoice_deduction_days',
				5 =>'payment_datetime',	
				6 =>'invoice_topaid',	
				7 =>'customer_remark',	
				8 =>'invoice_id',		
				
				); 
				
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
			$where_array=array(
					'cust_id'=>$active_cust_id,
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			
			$select_query=$this->customer_model->get_replenishments_due_query();
			$group_by =" ";
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{ 
				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);             
			}
			else {
				$search = $this->input->post('search')['value']; 

				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}

				$data = array();
				$i=1;
					foreach ($posts as $post)
					{
						$gross_amount_rate=0;
						#FORMULA FOR GROSS = PERCENT*INV_AMOUNT*NUMBER_OF_DAYS/365;
						$gross_amount_rate=$resul_customer['interest_rate']*$post->invoice_amount*($post->invoice_deduction_days/365);
						$gross_amount_rate=$gross_amount_rate/100;					
						$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['vendor_code'] =$post->vendor_code;
						
						$nestedData['invoice_amount'] =number_format($post->invoice_amount,2);
						$nestedData['type'] =(strtolower($post->invoice_net)=='net'?'Net':'Gross');
						$nestedData['interest_rate'] =$resul_customer['interest_rate'];
						$nestedData['invoice_deduction_days'] =$post->invoice_deduction_days;
						$nestedData['payment_datetime'] =date('d-m-Y',strtotime($post->payment_datetime));
						$nestedData['invoice_topaid'] =number_format($post->invoice_topaid,2);
						$nestedData['invoice_gross_rate'] =number_format($gross_amount_rate,2);
						$nestedData['due_date'] =date('d-m-Y',strtotime($post->payment_datetime.'+'.$post->invoice_deduction_days.' days')) ;
						$nestedData['due_amount'] =($post->invoice_net=='Net'?number_format($post->invoice_amount,2): number_format($gross_amount_rate+$post->invoice_topaid,2));
						$nestedData['status'] =($post->paid_by_customer=="No"?"Due":"Paid");
						$nestedData['customer_remark'] =($post->customer_remark==""?"N/A":$post->customer_remark);
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 			
		}
		/*Validate dates and return to ajax*/
		function validateDates(){
            $flag =1;
			if($this->input->post('filter_from')){
				$filter_from= $this->input->post('filter_from');
			}
			/* else{$filter_from= $this->input->get('filter_from');} */
			
			if($this->input->post('filter_to')){
				$filter_to= $this->input->post('filter_to');
			}
			
			if(strtotime($filter_from) > strtotime($filter_to)){
				
				 $flag =0;
			}
			$json_data = array(
					"message"            => $flag,
					"data"            => ERROR_A106   
				);				
			
			
			echo json_encode($json_data); 
			exit; 			
		}
		
		
		
		/*Returns json data for vendor based report*/
		public function getVendorReport(){
			
		    $active_cust_id=$this->session->userdata('active_cust_id');
			  $columns = array( 
				0=>'vendor_id',
				1 =>'vendor_code',
				2 =>'vendor_name',
					
				7 =>'invoice_date',		
				); 
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
			if($this->input->post('cust_id')){$cust_id= $this->input->post('cust_id');}			
			else{$cust_id= $this->input->get('cust_id');}
			
			if($this->input->post('filter_from')){
				$filter_from= $this->input->post('filter_from');
			}
			/* else{$filter_from= $this->input->get('filter_from');} */
			
			if($this->input->post('filter_to')){
				$filter_to= $this->input->post('filter_to');
			}
			/* else{$filter_to= $this->input->get('filter_to');} */
			
              $select_query = $this->dashboard_model->vendorBasedReport($cust_id,$filter_from,$filter_to);	
			  $group_by ="";			
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			 $totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{   

				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
               
			}
			else {
				$search = $this->input->post('search')['value']; 

				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}		

			    $data = array();
				$i=1;
					foreach ($posts as $post)
					{
						$vendor_code_link =ADMINBASEURL."bankadmin/invoiceBasedReport/".$post->vendor_id;					
						$nestedData['vendor_id'] = $post->vendor_id;
						$nestedData['vendor_code'] ="<a href=".$vendor_code_link.">".$post->vendor_code."</a>";
						$nestedData['vendor_name'] =$post->vendor_name;
						$nestedData['invoice_amount'] =$post->invoice_amount;
						$nestedData['discount'] =$post->discount;
						$nestedData['invoice_date'] =$post->invoice_date;
						$nestedData['paid_amount'] =$post->paid_amount;
						$nestedData['pending_amount'] =$post->pending_amount;
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 

		}
		
		
		/*Json result of Approved Invoice list*/
		public function getApprovedInvoiceList(){
			$active_cust_id=$this->session->userdata('active_cust_id');
		
			
		    $columns = array( 
				0=>'invoice_cust_id',
				1 =>'invoice_status',
				2 =>'invoice_beneficiary_name',
				3 =>'invoice_beneficiary_number',
				4 =>'invoice_amount',
				5 =>'invoice_discount',	
				6 =>'invoice_topaid',	
				7 =>'invoice_date',		
				8 =>'invoice_id',			
				); 
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];		
				 $status= $this->input->get('status');
				$arrayClasses = array('Paid'=>'label-success','Verified'=>'label-info','Approved'=>'label-success','Rejected'=>'label-danger',
							'Pending'=>'label-warning','Hold'=>'label-info');
							
							
				$select_query ="SELECT invoice_id,invoice_cust_id,invoice_vendor_id,invoice_beneficiary_name, invoice_beneficiary_number, sum(invoice_amount) as invoice_amount,invoice_deduction_days,sum(invoice_discount) as invoice_discount,sum(invoice_topaid) as invoice_topaid,invoice_date,invoice_status 
				FROM invoice_details
				where invoice_status ='Approved'  AND invoice_cust_id=$active_cust_id ";
				
				
	    $totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
          $group_by =" group by invoice_beneficiary_number ";
        $totalFiltered = $totalData; 
       
        if(empty($this->input->post('search')['value']))
        {   
	
            $posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
		
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

            $totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
        }		
		
			    $data = array();
				if(!empty($posts))
				{
					$i=1;
					foreach ($posts as $post)
					{
								
						$nestedData['invoice_id'] = $post->invoice_id;									
						$nestedData['invoice_beneficiary_name'] = "<a href=".ADMINBASEURL."bankadmin/viewmapped?id=".$this->encryption->encrypt($post->invoice_beneficiary_number)."&cpage=approved_invoices>".$post->invoice_beneficiary_name."</a>";						
						$nestedData['invoice_beneficiary_number'] = $post->invoice_beneficiary_number;
						$nestedData['invoice_amount'] = number_format($post->invoice_amount,2);
						 $where = array('cust_id'=>$post->invoice_cust_id);
						$customerDetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
						
						//$mclr = $customerDetails->mclr_percent;
						
						if($post->invoice_deduction_days<=90)
						{
							$mclr=$customerDetails->three_mclr; 
						}elseif($post->invoice_deduction_days<=180)
						{
							$mclr=$customerDetails->six_mclr; 
						}elseif($post->invoice_deduction_days<=270)
						{
							$mclr=$customerDetails->nine_mclr; 
						}else{
							$mclr=$customerDetails->mclr_twelve; 	
						}
						
						$perimum = $customerDetails->strategic_premium_rate;
						$risk = $customerDetails->risk_premium_rate;
						$interestRate = $mclr+$perimum+$risk;
						$nestedData['rate_of_interest'] =  $interestRate;	
						$nestedData['invoice_discount'] = number_format($post->invoice_discount,2);	
						$nestedData['invoice_topaid'] = number_format($post->invoice_topaid,2);	
						$nestedData['invoice_date'] = date('Y-m-d',strtotime($post->invoice_date));		
						$nestedData['status'] = "<span class='label ".$arrayClasses[$post->invoice_status]."'>".$post->invoice_status."</span> ";							
						$data[] = $nestedData;
						$i++;
					} 
				}
				
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
		}
		/*Json result of Invoice list -status*/
		public function getInvoiceList(){
		
			$active_cust_id=$this->session->userdata('active_cust_id');			
		    $columns = array( 
				0 =>'invoice_id', 
				1 =>'invoice_number',
				2 =>'invoice_beneficiary_name',
				3 =>'invoice_beneficiary_number',
				4 =>'invoice_amount',
				5 =>'interest_rate',
				6 =>'invoice_discount',
				7 =>'invoice_net',				
				8 =>'due_date',					
				9 =>'invoice_date',		
				10 =>'reject_reason',				
				); 				
				
				
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];			
			$status= $this->input->get('status');
			$page= $this->input->get('page');
			if($status=='')
			{
				$status= 'Pending';
			}			
			$mode= $this->input->get('mode');
			$number= $this->input->get('number');
			
			$arrayClasses = array('Paid'=>'label-success','Verified'=>'label-info','Approved'=>'label-success','Rejected'=>'label-danger',
			'Pending'=>'label-warning','Hold'=>'label-info');		
			
			  if($mode == 'update'){		
					 $select_query ="select * from (
					SELECT t1.* , DATE_ADD(DATE(invoice_date), INTERVAL invoice_deduction_days DAY) as due_date,c.cust_name,(
						CASE WHEN invoice_deduction_days<=90 THEN (three_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=180 THEN (six_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=270 THEN (nine_mclr+strategic_premium_rate+risk_premium_rate)
						ELSE (mclr_twelve+strategic_premium_rate+risk_premium_rate) END
					) as interest_rate,c.cust_id
					FROM invoice_details as t1
					LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
					WHERE  t1.invoice_cust_id='$active_cust_id' and t1.invoice_status = '".$status."'
					) 
					as tmp where  invoice_status='".$status."' ";
					$group_by ="";
		
			  }else{
				  if($page == 'paid_invoices'){
		
					$select_query ="select * from (
					SELECT t1.* , DATE_ADD(DATE(invoice_date), INTERVAL invoice_deduction_days DAY) as due_date,c.cust_name,(
						CASE WHEN invoice_deduction_days<=90 THEN (three_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=180 THEN (six_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=270 THEN (nine_mclr+strategic_premium_rate+risk_premium_rate)
						ELSE (mclr_twelve+strategic_premium_rate+risk_premium_rate) END
					) as interest_rate,c.cust_id
					FROM invoice_details as t1
					LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
					WHERE  t1.invoice_transactionid='$number' and t1.invoice_status = 'Paid'
					) 
					as tmp where  invoice_status='Paid' 
					";
				
					$group_by ="";
				  }
				  if($page == 'approved_invoices'){
					  $select_query ="select * from (
					SELECT t1.* , DATE_ADD(DATE(invoice_date), INTERVAL invoice_deduction_days DAY) as due_date,c.cust_name,
					(
						CASE WHEN invoice_deduction_days<=90 THEN (three_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=180 THEN (six_mclr+strategic_premium_rate+risk_premium_rate)
						WHEN invoice_deduction_days<=270 THEN (nine_mclr+strategic_premium_rate+risk_premium_rate)
						ELSE (mclr_twelve+strategic_premium_rate+risk_premium_rate) END
					) as interest_rate,c.cust_id
					FROM invoice_details as t1
					LEFT JOIN customer_details AS c on c.cust_id=t1.invoice_cust_id
					WHERE  t1.invoice_beneficiary_number=$number  
					) 
					as tmp where  invoice_status='Approved' 
					";
					$group_by ="";
				  }
				}
			
	    $totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
           
        $totalFiltered = $totalData; 
      	 
        if(empty($this->input->post('search')['value']))
        {       

            $posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
		
	 
        }
        else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by,$status);

            $totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by,$status);
        }	


			    $data = array();
				if(!empty($posts))
				{
					$i=1;
					foreach ($posts as $post)
					{
					
					  #  $status=$this->encryption->decrypt(str_replace(" ","+",$status));
						$invoice_number_link =ADMINBASEURL."bankadmin/Invoiceviewandupdate?status=".$this->encryption->encrypt($status)."&id=".$this->encryption->encrypt($post->invoice_id);			
						
						$nestedData['invoice_id'] = $post->invoice_id;						
						$nestedData['invoice_number'] = "<a href=".$invoice_number_link." >".$post->invoice_number."</a>&nbsp;&nbsp;";              
						$nestedData['invoice_beneficiary_name'] =  $post->invoice_beneficiary_name; 
						$nestedData['invoice_beneficiary_number'] =  $post->invoice_beneficiary_number; 
						$nestedData['invoice_amount'] = number_format($post->invoice_amount,2); 
						
						
			/* if($post->invoice_deduction_days==90)
			{
				$mclr_cal=$post->three_mclr; 
			}elseif($post->invoice_deduction_days==180)
			{
				$mclr_cal=$post->six_mclr; 
			}elseif($post->invoice_deduction_days==270)
			{
				$mclr_cal=$post->nine_mclr; 
			}else{
				$mclr_cal=$post->mclr_twelve; 	
			} */
						
						$nestedData['interest_rate'] =  $post->interest_rate; 
						//$nestedData['interest_rate'] = $this->invoice_loan_limit->customerBasedLoanLimit($post->invoice_id,$post->invoice_cust_id);		
						if(strtoupper(strtoupper($post->invoice_net))=='NET')
						{
							 $value = $post->interest_rate*($post->invoice_amount*$post->invoice_deduction_days)/365;
							 $valuefin = $value/100;
							 $nestedData['discount_amount'] = number_format($valuefin,2);
							 $sum = $post->invoice_amount-$valuefin;
						}else{
							 $nestedData['discount_amount'] ='0.00';
							 $sum = $post->invoice_amount;
						} 
						$nestedData['invoice_net'] = strtoupper($post->invoice_net);
						
                        $nestedData['amount_due'] = number_format($sum,2);
						$nestedData['invoice_date'] =date('Y-m-d',strtotime($post->invoice_date));		
						
						$nestedData['invoice_status'] ="<span class='label ".$arrayClasses[$post->invoice_status]."'>".$post->invoice_status."</span>";	
						
						$nestedData['reject_reason'] = $post->reject_reason;
						   $this->load->model('invoice_loan_limit');
						$limitcheck = $this->invoice_loan_limit->customerBasedLoanLimit($post->invoice_id,$post->invoice_cust_id);
					
						 if($mode == 'update'){
							if($limitcheck==0){ 
							$nestedData['invoice_select'] ="<input type='checkbox' class='child_class'  name='invoice_id[]' value='".$this->encryption->encrypt($post->invoice_id)."' />";
							}	else{
							$nestedData['invoice_select'] ="<i class='fa fa-ban font-danger'> Limit Exceed</i> ";
							}
						 }
						
						$data[] = $nestedData;
						$i++;
					} 
				
				}
				
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
		}
		
		
       /*Returns Json data for customer listing page*/
	   public function getCustomerList(){
		   $active_cust_id=$this->session->userdata('active_cust_id');
		   $columns = array( 
				0 =>'cust_id', 
				1 =>'cust_user_code',
				2=> 'cust_name',
				3=> 'cust_account_no',
				4=> 'cust_ifsc_code',
				5=> 'cust_phone',								
				); 
				
				/* 6=> 'cust_type', */
				$result_search = $this->dashboard_model->commonAjax('customer_details',$columns);
				//echo "<pre>";
				//print_r($result_search);
				$data = array();
				if(!empty($result_search['posts']))
				{
					
					#MAKE PARENT  SUB TREE
					$master_array=$result_search['posts'];
					foreach($master_array as $data_in){
						/* if($data_in->cust_type=="parent"){ */
							$new_tree[$data_in->cust_id][]=$data_in;
						/* }else{
							$new_tree[$data_in->cust_referral_id][]=$data_in;
						} */
					}
					$re_tree=array();
					foreach($new_tree as $data_in){
						
							foreach($data_in as $data_in_2){
								$re_tree[]=$data_in_2;
						 
							}
						 
					}
					//print_r($re_tree);
					
					$i=1;
					foreach ($re_tree as $post)
					{
						$edit_link="";
						$delete_link="";
						$status_link="";
						$select_link="";
						$disable_link="";
						$nestedData['cust_id'] = $post->cust_id;						
						$nestedData['cust_user_code'] = $post->cust_user_code;               
						$nestedData['cust_name'] = $post->cust_name;               
						$nestedData['cust_account_no'] = $post->cust_account_no;               
						$nestedData['cust_ifsc_code'] = $post->cust_ifsc_code;               
						$nestedData['cust_phone'] = $post->cust_phone;               
						//$nestedData['cust_type'] = $post->cust_type;   
						
						if($active_cust_id==''){
						
						$edit_action =ADMINBASEURL."bankadmin/customerform?id=".$post->cust_id;
						$edit_link ="<a href=".$edit_action." class='tableicons'><i class='fa fa-pencil' title='Edit'></i></a>&nbsp;&nbsp;";
						 if($post->cust_status ==0){
							 $status_link ="<a  onclick='enableCustomer(".$post->cust_id.")' data-id=".$post->cust_id." href='#'>Enable</a>&nbsp;&nbsp;"; 
						 }else{
							 $status_link ="<a  onclick='disableCustomer(".$post->cust_id.")' data-id=".$post->cust_id." href='#'>Disable</a>&nbsp;&nbsp;"; 
						 }
						}else{
						 $view_action = ADMINBASEURL."bankadmin/customerview/".$post->cust_id;
						  $view_link ="<a href=".$view_action." class='tableicons'><i class='fa fa-eye' title='View'></i></a>";	
						}
						if($active_cust_id==$post->cust_id){
							$select_link= '<span class="text-success">Active</span>';
						}else{ 
						$select_action =ADMINBASEURL."bankadmin/activateCustomer?cust_id=".$post->cust_id;
						$select_link="<a class='btn btn-primary btn-xs'  href=".$select_action." class='tableicons'>Select</a>";	
						}
						
						
						
						
					    
                         $nestedData['customer_actions'] =$edit_link.$view_link.$status_link.$select_link;   

						$data[] = $nestedData;
						$i++;
					}
				}
                 
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($result_search['totalData']),  
				"recordsFiltered" => intval($result_search['totalFiltered']), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
	   }
	   /*Returns json data for User List*/
			public function getUserList(){
				  $active_cust_id=$this->session->userdata('active_cust_id');
				$columns = array( 
				0 =>'user_id', 
				1 =>'user_name',
				2=> 'user_type',
				3=> 'user_phone',
				4=> 'user_email',
				5=> 'user_department',
				6=> 'user_designation',									
				);
               $result = $this->session->userdata('member');
               $member_id = $result['member_id'];
				$result_search = $this->dashboard_model->commonAjax('user_details',$columns);
				$data = array();
				if(!empty($result_search['posts']))
				{
					$i=1;
					foreach ($result_search['posts'] as $post)
					{
						$edit_link="";
						$delete_link="";
						$status_link="";
						$disable_link="";
						$nestedData['user_id'] = $post->user_id;
						
						$nestedData['user_name'] = $post->user_name;               
						$nestedData['user_type'] = $post->user_type;               
						$nestedData['user_phone'] = $post->user_phone;               
						$nestedData['user_email'] = $post->user_email;               
						$nestedData['user_department'] = $post->user_department;               
						$nestedData['user_designation'] = $post->user_designation;   
						if($active_cust_id==''){
					    if($post->user_type != 'customer' && $post->user_type != 'bankadmin') { 
						 $edit_action =ADMINBASEURL."bankadmin/userForm?id=".$post->user_id;
						 $edit_link ="<a href=".$edit_action." class='tableicons'><i class='fa fa-pencil' title='Edit'></i></a>";
						 
						 }
						 $view_action = ADMINBASEURL."bankadmin/userView/".$post->user_id;
						  $view_link ="<a href=".$view_action." class='tableicons'><i class='fa fa-eye' title='View'></i></a>";
						  
						 if($post->user_id !=$member_id ) 
						  if( $post->user_id !=$active_user_id){						 
						  if($post->user_type == 'client_manager' || $post->user_type == 'customer' || $post->delete_status ==0 ){
							  if($post->user_status ==0){
								 $status_link ="/<a class='enableuser' onclick='enableUser(".$post->user_id.")' data-id=".$post->user_id." href='#'>Enable</a>"; 
								 }else {	
								$status_link ="/<a class='disableuser' onclick='disableUser(".$post->user_id.")' data-id=".$post->user_id." href='#'>Disable</a>"; 
								 }	
						  }else{
								$delete_link ="/<a class='deleteuser'  onclick='deleteUser(".$post->user_id.")' data-id=".$post->user_id." href='#'>Delete</a>";
						   
								}						  
						  }	 
						}else{
						$view_action = ADMINBASEURL."bankadmin/userView/".$post->user_id;
$view_link ="<a href=".$view_action." class='tableicons'><i class='fa fa-eye' title='View'></i></a>";						
						}
                         $nestedData['user_actions'] =$edit_link.$view_link.$status_link.$delete_link;   
						
						$data[] = $nestedData;
						$i++;
					}
				}
                 
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($result_search['totalData']),  
				"recordsFiltered" => intval($result_search['totalFiltered']), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
			}
			
			
		public function download_cron_csv(){
			$customer_code="";
			$filename="";
			$this->load->helper('download');
			$this->load->library('encryption');
			$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
			$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
			$this->encryption->initialize($config_arr);
			if($this->input->post('customer_code') != ""){
			$customer_code=$this->input->post('customer_code');
			}		
			if($this->input->post('filename') != ""){
			$filename=$this->input->post('filename');
			}		
			$customer_path=str_replace('{CUST_CODE}',$customer_code,UPLOADS_CUST_INVOICE);		
			$files_content = file_get_contents($customer_path.'/'.$filename);	
			$decrypted_file_content = $this->encryption->decrypt($files_content);  		 
			force_download($filename,$decrypted_file_content); 
		}		
	public function download_myfiles($rand_key,$doc_id,$cust_user_code) { 
		 
		//$cust_user_code=$result['cust_user_code'];
		$this->load->library('encryption');
		$this->load->helper('download');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr);
		
		#getting the uploaded file
		$where_array=array(
					'rand_key'=>$rand_key,
					'id'=>$doc_id,
				);
		$uploaded_data=$this->vendor_model->get_table('invoice_documents',$where_array);
		$uploaded_data_set=$uploaded_data->row_array(); 
		$customer_path=str_replace('{CUST_CODE}',$cust_user_code,UPLOADS_CUST_DOC);
		 $file_name=$uploaded_data_set['document_name'];
		 //$file_name=$customer_path."/".$uploaded_data_set['document_name'];
		$files_content = file_get_contents($customer_path.'/'.$file_name);
		$decrypted_file_content = $this->encryption->decrypt($files_content);  
		 force_download($file_name,$decrypted_file_content); 
			
	}
	public function decrypt_invoice($path,$file_name) { 
		 
		//$cust_user_code=$result['cust_user_code'];
		$this->load->library('encryption');
		$this->load->helper('download');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr); 
		 
		$files_content = file_get_contents($path.$file_name);
		$decrypted_file_content = $this->encryption->decrypt($files_content); 
		 mkdir($path."/tmper",0777,true);  
			
		 if(!is_dir($customer_path."/tmper")){
				 mkdir($path."/tmper",0777,true);  
			}
		file_put_contents($path."/tmper/".$file_name,$decrypted_file_content);
		return $path."/tmper/".$file_name;  
			
	}
	public function download_invoice($encrypted_id) { 
		  $id=base64_decode($encrypted_id) ;
		$this->IsloggedIn(); #is logged in ..?  
		$this->load->library('encryption');
		$this->load->helper('download');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr);
		
		#getting the uploaded file
		$where_array=array( 
					'id'=>$id
				);
		$uploaded_data=$this->vendor_model->get_table('invoice_csv_uploads',$where_array);
	 
		$uploaded_data_set=$uploaded_data->row_array();  
		 
		$where_array_2=array( 
					'cust_id'=>$uploaded_data_set['customer_id']
				);
		$result_customer_data=$this->vendor_model->get_table('customer_details',$where_array_2);
	 
		$result_customer=$result_customer_data->row_array(); 
		
		if($uploaded_data_set['status']==1){
			$customer_path=CUS_INVOICE_READFROM.$result_customer['cust_user_code']."/invoice/"; 
		}else{
			$customer_path=CUS_INVOICE_READFROM.$result_customer['cust_user_code']."/invoice_done/"; 
		}
 
		 $file_name=$uploaded_data_set['filename'];
		 //$file_name=$customer_path."/".$uploaded_data_set['document_name'];
		$files_content = file_get_contents($customer_path.'/'.$file_name);
		$decrypted_file_content = $this->encryption->decrypt($files_content);  
		 force_download($file_name,$decrypted_file_content); 
			
	}
	public function forgotpassword()
		{  	  
            $data['siteSettings'] = $this->data['siteSettings'];
		  /*Customer Login Function*/
            if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('user_email', 'Email', 'required|valid_email');
 				$email    = $this->input->post('user_email');
				$password = ''; 
				if ($this->form_validation->run()=='TRUE') {
					$logged_data=$this->vendor_model->check_forgot_email($email,$password);
					if( $logged_data->num_rows()!=0){ 
						$cust_data=$logged_data->row_array();
						$salt_data=$this->vendor_model->forgot_password_request($cust_data);  
						$is_sent=$this->send_otp($cust_data,$salt_data[1]); 
						if($is_sent){
							$where = array('cust_id'=>$cust_data['cust_id']);
							$userdetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
							//$this->customer_model->cust_logdetails($userdetails->cust_name.' Forgot Password request sent','login'); #logging
							//$this->session->set_userdata('info_cust',INFO_C201); 
							$this->session->set_userdata('success_cust',INFO_C203);
							redirect(ADMINBASEURL.'bankadmin/reset_verify/'.$salt_data[0]);
						} 
					}else{
						//$this->customer_model->cust_logdetails($email.' Forgot Password request failure','login'); #logging
						$this->session->set_userdata('error_cust',ERROR_C204);
					}
					
				}
			}
			$this->load->view('admin/forgotpassword',$data);
            
        }	
		public function send_otp($user_data,$otp,$salt='')
		{  	 
			$siteSettings = $this->data['siteSettings'];
			if($salt!=""){
				$template_details=$this->customer_model->get_email_template(6);
				$reset_url=ADMINBASEURL."bankadmin/reset_password/".$salt;
			}else{
				$template_details=$this->customer_model->get_email_template(5);

			}
			$body=$template_details['message'];
			//$template_details
			$replace_data=array(
				'[{CUSTOMER_NAME}]'=>$user_data['user_name'],
				'[{OTP}]'=>$otp, 
				'[{RESET_URL}]'=>$reset_url, 
			);
            foreach($replace_data as $key=>$val ){
				$body=str_replace($key,$val,$body);
			}
			$email_data=array(
				'from_email'=>'admin@vendorfinance.com',
				'from_name'=>'Vendor Finance',
				'to_email'=>$user_data['user_email'],
				'subject'=>$template_details['subject'],
				'body'=>$body
				);
			return $this->cust_send_email($email_data);
        }
		public function reset_verify($salt)
		{  	
		
		if($salt==''){
			redirect(ADMINBASEURL.'bankadmin/index/');
		}
			   $data['siteSettings'] = $this->data['siteSettings'];
		  /*Customer Login Function*/
            if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('user_otp', 'OTP', 'required|numeric');
 				$user_otp    = $this->input->post('user_otp');
				 
				if ($this->form_validation->run()=='TRUE') {
					$logged_data=$this->customer_model->check_otp($user_otp,$salt);
					if( $logged_data->num_rows()!=0){ 
						$logged_data_set=$logged_data->row_array();
						    $cur_date=date('Y-m-d H:i:s');
						 $otp_sent_date=$logged_data_set['created_date'];  
						//echo $plus_expiry_hr=date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s')$logged_data_set['expiry_hrs']."hr"));   
						    $plus_expiry_hr=date('Y-m-d H:i:s',strtotime($otp_sent_date."+".$logged_data_set['expiry_hrs']." hour"));
					
						if(strtotime($cur_date) < strtotime($plus_expiry_hr)){
							 
								$table_name="cust_forgot_password";
								$data_update=array(
									'status'=>'Completed',
									'completed_date'=>$cur_date
								); 
								$where_cond=array('otp'=>$user_otp,'salt_key'=>$salt); 
								$this->customer_model->update_table($table_name,$data_update,$where_cond); 
								redirect(ADMINBASEURL.'bankadmin/reset_password/'.$salt);
						}else{
						 
							#cant process";
							$this->session->set_userdata('error_cust',ERROR_C206);
						}
					
 						if($is_sent){
							$this->session->set_userdata('info_cust',INFO_C204); 
							redirect(ADMINBASEURL.'bankadmin/reset_verify/'.$salt_data[0]);
						} 
					}else{
						$this->session->set_userdata('error_cust',ERROR_C207);
					}
					
				}
			}
			 
			$data['salt']=$salt; 
			$this->load->view('admin/recive_otp',$data);
         }
		public function reset_password($salt_key)
		{  	  
		if($salt_key==''){
			redirect(ADMINBASEURL.'bankadmin/index/');
		}
		$where_cond=array('salt_key'=>$salt_key,'status'=>'Reset');
		$result_data=$this->customer_model->get_table('cust_forgot_password',$where_cond);
		if($result_data->num_rows()!=0){
			redirect(ADMINBASEURL.'bankadmin/index/');

		}
		 if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
				$this->form_validation->set_rules('c_password', 'Confirm Password', 'required|min_length[6]');
 				$password   = $this->input->post('password');
 				$c_password   = $this->input->post('c_password');
				$cur_date=date('Y-m-d H:i:s');
				if($this->form_validation->run()=='TRUE') {
					if($password!=$c_password){
						$this->session->set_userdata('error_cust',ERROR_C208);
					}else{
						$where_cond=array('salt_key'=>$salt_key,'status'=>'Completed');
						$result_data=$this->customer_model->get_table('cust_forgot_password',$where_cond);
					 
						if($result_data->num_rows()!=0){
							$data_detailed=$result_data->row_array();
							$table_name="user_details";
							$data_update=array(
								'user_login_password'=>md5($password),
								'modified_date'=>$cur_date
							); 
							$where_cond_n=array('user_id'=>$data_detailed['cust_id']); 
							$this->customer_model->update_table($table_name,$data_update,$where_cond_n); 
							$table_name="cust_forgot_password";
							$data_update=array(
 								'status'=>'Reset'
							); 
							$where_cond=array('salt_key'=>$salt_key,'status'=>'Completed');
							$this->customer_model->update_table($table_name,$data_update,$where_cond); 
							$this->session->set_userdata('success_cust', INFO_C202);
							redirect(CUSTOMERBASEURL.'bankadmin/index/');
						}	else{
							$this->session->set_userdata('error_cust',ERROR_C205); 
							redirect(ADMINBASEURL.'bankadmin/index/');
						}					
						
					}
				}
		 }
            $data['siteSettings'] = $this->data['siteSettings'];  
            $this->load->view('admin/reset_password',$data);
            
        }
private function cust_send_email($data_rec){ 
			vfemail($data_rec['to_email'],$data_rec['subject'],$data_rec['body']);
			return true; 
		}
public function resend_otp($salt)
		{  	 
		if($salt==''){
			redirect(CUSTOMERBASEURL.'customer/login/');
		}
			$siteSettings = $this->data['siteSettings'];
			$where_array=array('salt_key'=>$salt,'status'=>'Sent');
			$check_otp=$this->customer_model->get_table('cust_forgot_password',$where_array);
			if($check_otp->num_rows()!=0){
				$res_data=$check_otp->row_array();
				$user_id=$res_data['cust_id'];
				$otp=$res_data['otp'];
				$where_array=array('cust_id'=>$user_id);
				$user_details=$this->customer_model->get_table('user_details',$where_array);
				$user_details_arr=$user_details->row_array();
			
			
			
				$template_details=$this->customer_model->get_email_template(5);
				$body=$template_details['message'];
				//$template_details
				$replace_data=array(
					'[{CUSTOMER_NAME}]'=>$user_details_arr['user_name'],
					'[{OTP}]'=>$otp 
				);
				foreach($replace_data as $key=>$val ){
					$body=str_replace($key,$val,$body);
				}
					$email_data=array(
					'from_email'=>'admin@vendorfinance.com',
					'from_name'=>'Vendor Finance',
					'to_email'=>$user_details_arr['user_email'],
					'subject'=>$template_details['subject'],
					'body'=>$body
					);
				  if($this->cust_send_email($email_data)){
					$this->session->set_userdata('success_cust',INFO_C203);

					redirect(ADMINBASEURL.'bankadmin/reset_verify/'.$salt);

				  } 
		  } 
	}
public function send_email_by_template($template_id,$user_data)
		{  	 
			$siteSettings = $this->data['siteSettings'];
			 
				$template_details=$this->customer_model->get_email_template($template_id);
 
			$body=$template_details['message'];
			//$template_details
		 
			$replace_data=array(
				'[{CUSTOMER_NAME}]'=>$user_data['customer_name'],
				'[{USER_DISPLAY_NAME}]'=>$user_data['customer_name'],
				'[{USER_NAME}]'=>$user_data['user_name'], 
				'[{CUST_LOGIN_URL}]'=>$user_data['customer_url'], 
				'[USER_LOGIN_URL}]'=>$user_data['customer_url'], 
				'[{PASSWORD}]'=>$user_data['password'], 
				'[{ROLE_NAME}]'=>$user_data['role_name'] 
			);
            foreach($replace_data as $key=>$val ){
				$body=str_replace($key,$val,$body);
			}
			$email_data=array( 
				'to_email'=>$user_data['user_name'],
				'subject'=>$template_details['subject'],
				'body'=>$body
				);
			return $this->cust_send_email($email_data);
        }
		public function myprofile(){
			$this->IsloggedIn(); 
			$user_data=$this->session->userdata('member');
			$where_array=array('user_id'=>$user_data['member_id']);
			$user_details=$this->customer_model->get_table('user_details',$where_array);
			$user_data_all=$user_details->row_array();
			 if(count($_POST)>0&& isset($_POST['phone_number'])){ 
				$data['data_account']="active";
					$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
					$this->form_validation->set_rules('name', 'Name', 'required');
					$this->form_validation->set_rules('phone_number', 'Phone number', 'required');
 
				if ($this->form_validation->run()=='TRUE') {
					
					$where_to_doc=array('user_id'=>$user_data['member_id']); 
					$data_to_invoice=array('modified_date'=>date('Y-m-d H:i:s'),'user_phone'=>$this->input->post('phone_number'),'user_name'=>$this->input->post('name'));
					$this->vendor_model->UpdateDatabyCommon('user_details',$where_to_doc,$data_to_invoice);
				}	
			}else if(count($_POST)>0&& isset($_POST['email'])){ #email
					$data['data_email']="active";
					$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
					$this->form_validation->set_rules('email', 'Email Address', 'required');
					$this->form_validation->set_rules('password', 'Current Password', 'required');
				if ($this->form_validation->run()=='TRUE') {
					$res=	$this->vendor_model->logincheck($this->input->post('email'),$this->input->post('password'));
						if(!empty($res)){ 
						#IF Email changed set details in to the session variable and waiting for th OTP
								$param_to_otp=array('cust_id'=>$user_data['member_id']);
								$otp_details=$this->customer_model->forgot_password_request($param_to_otp,1); #insert OTP in Table
								$OTP=$otp_details[1]; #OTP
								$salt=$otp_details[0]; #salt
								$user_data['user_email']=$user_data_all['user_email'];
								$user_data['user_name']=$user_data_all['user_name'];
								$is_sent=$this->send_otp($user_data,$OTP,$salt);
								if($is_sent){
									$account_updated_array=array(
 									'password'=>$this->input->post('password'),
									'salt'=>$salt,
									);
									$this->session->set_userdata('account_updated_info',$account_updated_array);
									$this->session->set_userdata('ac_info_message','Password Reset link is sent to your registered Email Address. Please check your inbox');
								}else{
									 
								}
						}else{
							$this->session->set_userdata('ac_info_message','Entered Password is incorrect. Please try again');
						}
				}
			}else{
				$data['data_account']="active";
			}
			
			$data['user_data'] = $user_data_all;
			$data['page'] = 'admin/pages/myprofile';
			$data['siteSettings'] = $this->data['siteSettings']; 
			$this->load->view('admin/template',$data);
		}
}
