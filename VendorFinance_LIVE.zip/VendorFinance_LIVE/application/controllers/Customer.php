<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	public function __construct()
        {
            /*Site Settings loaded in construct for non-repeat model code in every function*/
            parent::__construct();
            $this->load->library(array('excel','session'));
			$this->load->model('vendor_model');
            $this->load->model('customer/customer_model');
			 $this->load->model('dashboard_model');
			$this->load->helper('vfemail'); 
            $this->data['siteSettings'] = $this->vendor_model->get_DatabyCommon('site_settings',array('id'=>1),'*');
			 
        }  
		public function IsloggedIn()
        {
            /*This function validates member logged valid or not. If not logged in page will redirect to login page
             *              */
            $result = $this->session->userdata('customer_login');
            $member_id = $result['member_id'];
            if($member_id!='' && $member_id!=false)
            {
                $returnID = $member_id;
            }
            else
            {
                redirect(CUSTOMERBASEURL.'customer/login','refresh');
            }
            return $returnID; 
        }
        public function index()
        {
			$this->IsloggedIn(); 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
			$cust_id= $result['cust_id'];
            $data['siteSettings'] = $this->data['siteSettings'];
			$condition=array('invoice_cust_id'=>$result['cust_id']);
			$data_rec_arr=$this->customer_model->get_counts('invoice_details','count(invoice_id) as total_invoices',$condition);
			
			$data['total_invoices']=$data_rec_arr['total_invoices'];
			$condition_2=array('invoice_cust_id'=>$result['cust_id'],'invoice_status'=>'Pending');
			$pending_invoices=$this->customer_model->get_counts('invoice_details','count(invoice_id) as pending_invoices',$condition_2);
			
			$data['pending_invoices']=$pending_invoices['pending_invoices'];
			$condition_3=array('invoice_cust_id'=>$result['cust_id'],'invoice_status'=>'Paid');
			$paid_invoices=$this->customer_model->get_counts('invoice_details','count(invoice_id) as paid_invoices',$condition_3);
			$data['paid_invoices']=$paid_invoices['paid_invoices'];
			$condition_4=array('invoice_cust_id'=>$result['cust_id'],'invoice_status'=>'Paid');
			$invoice_paid=$this->customer_model->get_counts('invoice_details','sum(invoice_topaid) as invoice_paid',$condition_4);
			$data['invoice_paid']=$invoice_paid['invoice_paid'];
			$condition_5=array('invoice_cust_id'=>$result['cust_id'],'invoice_status'=>'Paid','paid_by_customer'=>'No');
			$invoice_paid=$this->customer_model->get_counts('invoice_details','sum(invoice_topaid) as Replenishments_amount',$condition_5);
			 
			$invoice_paid=$this->customer_model->get_counts('invoice_details','count(invoice_id) as Replenishments_due',$condition_5);
			$data['Replenishments_due']=$invoice_paid['Replenishments_due'];
			$customer_login=$this->session->userdata('customer_login');
			if(isset($customer_login['cust_id']))
			{
				$cust_id=$customer_login['cust_id'];
			}
			$data['receivableData']=$this->customer_model->homepage_replenishments_due($cust_id);
			
			#get counts
			$pending_amount=$this->customer_model->get_counts('invoice_details','sum(invoice_amount) as pending_amount',$condition_2);
			$data['pending_amount']=$pending_amount['pending_amount'];
			$all_amount=$this->customer_model->get_counts('invoice_details','sum(invoice_amount) as all_amount',$condition);
			$data['all_amount']=$all_amount['all_amount'];
			 
			
			$data_rep_due=$this->replenishments_due('Dashboard');
			$where_array=array(
					'cust_id'=>$result['cust_id']
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			$data['resul_customer']=$resul_customer;
			$CustomerData=$this->session->userdata("CustomerData"); 
			 
			#get sub companies details
			$child_data=array();
			if($CustomerData['cust_type']=='parent'){
				$where_array_sub=array(
					'cust_referral_id'=>$result['cust_id']
				);
			}else{
				$where_array_sub=array(
					'cust_referral_id'=>$CustomerData['cust_referral_id'],
					'cust_id !='=>$result['cust_id'],
				);
				$parent_loan_usage=$this->dashboard_model->GetCustomerData($CustomerData['cust_referral_id']);
				 $data['parent_loan_usage']=$parent_loan_usage;
				 
			}
			
			$array_sub_record=$this->customer_model->get_table('customer_details',$where_array_sub);
			$array_sub_data=$array_sub_record->result_array(); 
			if(!empty($array_sub_data)){
				foreach($array_sub_data as $array_sub_in_data){
				#get loan limits and weekly paid invoices
				$child_data[$array_sub_in_data['cust_id']] = $this->dashboard_model->GetCustomerData($array_sub_in_data['cust_id']);
				}
			}  
			#sum amounts of sub companies paid 
			$weeklyPainIvoice=0;
			$monthlyPainIvoice=0;
			$cust_loan_used=0; 
			foreach($child_data as $child_data_in){
				$weeklyPainIvoice +=$child_data_in["weeklyPainIvoice"];
				$monthlyPainIvoice +=$child_data_in["monthlyPainIvoice"];
				  $cust_loan_used +=str_replace(',','',$child_data_in["cust_loan_used"]);
			}
			//$data['child_data']=$child_data;
			
			#replenishment Due
			$rep_dues=$this->customer_model->get_replenishments_due();
			
			foreach( $rep_dues as $rep_dues_details){
					$gross_amount_rate=0;
					#FORMULA FOR GROSS = PERCENT*INV_AMOUNT*NUMBER_OF_DAYS/365;
					$gross_amount_rate=$resul_customer['interest_rate']*$rep_dues_details['invoice_amount']*($rep_dues_details['invoice_deduction_days']/365);
					$gross_amount_rate=$gross_amount_rate/100;				
						 
					$Replenishments_amount +=(strtolower($rep_dues_details['invoice_net'])=='net'?$rep_dues_details['invoice_amount']: $gross_amount_rate+$rep_dues_details['invoice_amount']); 
			}
			$data['Replenishments_amount']=$Replenishments_amount;
			 
			$data['sub_weeklyPainIvoice']=$weeklyPainIvoice;
			$data['sub_monthlyPainIvoice']=$monthlyPainIvoice;
			$data['sub_cust_loan_used']=$cust_loan_used;
			$data['data_rep_due']=$data_rep_due;
			$data['view_file']='customer/dashboard';
			$data['in_active']='active'; 
            $this->load->view('customer/common/template',$data);
            
        }    
		public function login()
        { 
		  $result = $this->session->userdata('customer_login');
            $member_id = $result['member_id'];
            if($member_id!='' && $member_id!=false)
            {
                redirect(CUSTOMERBASEURL.'customer/index','refresh');
            }
            /*Customer Login Function*/
            if(count($_POST)>0){  
				$data['siteSettings'] = $this->data['siteSettings']; 
				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				//$this->form_validation->set_rules('user_email', 'Email', 'required|valid_email');
				$this->form_validation->set_rules('password', 'Password', 'required'); 
				$email    = $this->input->post('user_email');
				$password = $this->input->post('password');
				
				if ($this->form_validation->run()=='TRUE') {
					$logged_data=$this->customer_model->check_login($email,$password);
					// echo $this->db->last_query();die;
					if( $logged_data->num_rows()!=0){  
						  $cust_data=$logged_data->row_array(); 
						  $data_login=array('member_id'=>$cust_data['user_id'],'logged_in'=>true,'user_name'=>$cust_data['user_name'],'cust_id'=>$cust_data['cust_id'],'cust_type'=>$cust_data['cust_type']);
						  $where = array('cust_id'=>$cust_data['cust_id']);
						  $userdetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
						  $data_login['cust_user_code']=$userdetails->cust_user_code;
						  if($this->session->userdata('customer_login')){
							  $this->session->unset_userdata('active_cust_id');            
								$this->session->unset_userdata('active_cust_type');
								
							}
						  $this->session->set_userdata('customer_login',$data_login);
							
							if($this->input->post('rem_me')!=''){ 
							 setcookie('r_email_customer',$email,time()+ (10 * 365 * 24 * 60 * 60));
							 setcookie('r_ep_customer',base64_encode($password),time()+ (10 * 365 * 24 * 60 * 60));
							}							
						  $this->customer_model->cust_logdetails($userdetails->cust_name.' logged in','login'); #logging
						  redirect(CUSTOMERBASEURL.'customer/index','refresh');
					 }else{  
						$this->customer_model->cust_logdetails($email.' attempted to login','login'); #logging
						$this->session->set_userdata('error_cust', ERROR_C203);
						redirect(CUSTOMERBASEURL.'customer/login','refresh');
					 }  
				}else{

					 
				}
			}
			if($this->session->userdata('error_cust')!=''){
				$data['error_cust']=$this->session->userdata('error_cust');
				$this->session->set_userdata('error_cust','');
			} 
			
            $data['siteSettings'] = $this->data['siteSettings']; 
			$data['view_file']='customer/login';
            $this->load->view('customer/common/template',$data);
            
        }
		  public function logout()
        {
            /*Logout function will destory the current Customer session*/
       	$cust_data=$this->session->userdata('customer_login');  
        $cust_id  = $cust_data['cust_id'];
            $where = array('cust_id'=>$cust_id);
			if(!empty($cust_data)){
				$userdetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
				$this->customer_model->cust_logdetails($userdetails->cust_name.' logged out','login'); 
			}	
            $this->session->sess_destroy();
            redirect(ADMINBASEURL.'customer/login','refresh');
        }
		public function forgotpassword()
		{  	  
            $data['siteSettings'] = $this->data['siteSettings'];
		  /*Customer Login Function*/
            if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('user_email', 'Email', 'required|valid_email');
 				$email    = $this->input->post('user_email');
				$password = ''; 
				if ($this->form_validation->run()=='TRUE') {
					$logged_data=$this->customer_model->check_login($email,$password);
					if( $logged_data->num_rows()!=0){ 
						$cust_data=$logged_data->row_array();
						$salt_data=$this->customer_model->forgot_password_request($cust_data); 
						 
						$is_sent=$this->send_otp($cust_data,$salt_data[1]); 
						if($is_sent){
							$where = array('cust_id'=>$cust_data['cust_id']);
							$userdetails = $this->vendor_model->get_DatabyCommon('customer_details',$where,'*');
							$this->customer_model->cust_logdetails($userdetails->cust_name.' Forgot Password request sent','login'); #logging
							//$this->session->set_userdata('info_cust',INFO_C201); 
							$this->session->set_userdata('success_cust',INFO_C203);
							redirect(ADMINBASEURL.'customer/reset_verify/'.$salt_data[0]);
						} 
					}else{
						$this->customer_model->cust_logdetails($email.' Forgot Password request failure','login'); #logging
						$this->session->set_userdata('error_cust',ERROR_C204);
					}
					
				}
			}
			$data['view_file']='customer/forgotpassword'; 
            $this->load->view('customer/common/template',$data);
            
        }	


       /*Validate dates and return to ajax in datewise search pages*/
		function validateDates(){
            $flag =1;
			if($_REQUEST['filter_from']){
				$filter_from= $_REQUEST['filter_from'];
			}
			/* else{$filter_from= $this->input->get('filter_from');} */
			
			if($_REQUEST['filter_to']){
				$filter_to= $_REQUEST['filter_to'];
			}
			
			if(strtotime($filter_from) > strtotime($filter_to)){
				
				 $flag =0;
			}
			$json_data = array(
					"message"            => $flag,
					"data"            => ERROR_A106   
				);				
			
			
			echo json_encode($json_data); 
			exit; 			
		}
		


		
		public function reset_password($salt_key)
		{  	  
		if($salt_key==''){
			redirect(ADMINBASEURL.'customer/login/');
		}
		$where_cond=array('salt_key'=>$salt_key,'status'=>'Reset');
		$result_data=$this->customer_model->get_table('cust_forgot_password',$where_cond);
		if($result_data->num_rows()!=0){
			redirect(ADMINBASEURL.'customer/login/');

		}
		 if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
				$this->form_validation->set_rules('c_password', 'Confirm Password', 'required|min_length[6]');
 				$password   = $this->input->post('password');
 				$c_password   = $this->input->post('c_password');
				$cur_date=date('Y-m-d H:i:s');
				if($this->form_validation->run()=='TRUE') {
					if($password!=$c_password){
						$this->session->set_userdata('error_cust',ERROR_C208);
					}else{
						$where_cond=array('salt_key'=>$salt_key,'status'=>'Completed');
						$result_data=$this->customer_model->get_table('cust_forgot_password',$where_cond);
					 
						if($result_data->num_rows()!=0){
							$data_detailed=$result_data->row_array();
							$table_name="user_details";
							$data_update=array(
								'user_login_password'=>md5($password),
								'modified_date'=>$cur_date
							); 
							$where_cond_n=array('cust_id'=>$data_detailed['cust_id']); 
							$this->customer_model->update_table($table_name,$data_update,$where_cond_n); 
							$table_name="cust_forgot_password";
							$data_update=array(
 								'status'=>'Reset'
							); 
							$where_cond=array('salt_key'=>$salt_key,'status'=>'Completed');
							$this->customer_model->update_table($table_name,$data_update,$where_cond); 
							$this->session->set_userdata('success_cust', INFO_C202);
							redirect(CUSTOMERBASEURL.'customer/login');
						}	else{
							$this->session->set_userdata('error_cust',ERROR_C205); 
							redirect(ADMINBASEURL.'customer/login/');
						}					
						
					}
				}
		 }
            $data['siteSettings'] = $this->data['siteSettings']; 
			$data['view_file']='customer/reset_password'; 
            $this->load->view('customer/common/template',$data);
            
        }	
		public function send_otp($user_data,$otp,$salt='')
		{  	 
			$siteSettings = $this->data['siteSettings'];
			if($salt!=""){
				$template_details=$this->customer_model->get_email_template(6);
				$reset_url=CUSTOMERBASEURL."customer/reset_password/".$salt;
			}else{
				$template_details=$this->customer_model->get_email_template(5);

			}
			$body=$template_details['message'];
			//$template_details
			$replace_data=array(
				'[{CUSTOMER_NAME}]'=>$user_data['user_name'],
				'[{OTP}]'=>$otp, 
				'[{RESET_URL}]'=>$reset_url, 
			);
            foreach($replace_data as $key=>$val ){
				$body=str_replace($key,$val,$body);
			}
			$email_data=array(
				'from_email'=>'admin@vendorfinance.com',
				'from_name'=>'Vendor Finance',
				'to_email'=>$user_data['user_email'],
				'subject'=>$template_details['subject'],
				'body'=>$body
				);
			return $this->cust_send_email($email_data);
        }

		public function resend_otp($salt)
		{  	 
		if($salt==''){
			redirect(CUSTOMERBASEURL.'customer/login/');
		}
			$siteSettings = $this->data['siteSettings'];
			$where_array=array('salt_key'=>$salt,'status'=>'Sent');
			$check_otp=$this->customer_model->get_table('cust_forgot_password',$where_array);
			if($check_otp->num_rows()!=0){
				$res_data=$check_otp->row_array();
				$user_id=$res_data['cust_id'];
				$otp=$res_data['otp'];
				$where_array=array('cust_id'=>$user_id);
				$user_details=$this->customer_model->get_table('user_details',$where_array);
				$user_details_arr=$user_details->row_array();
			
			
			
				$template_details=$this->customer_model->get_email_template(5);
				$body=$template_details['message'];
				//$template_details
				$replace_data=array(
					'[{CUSTOMER_NAME}]'=>$user_details_arr['user_name'],
					'[{OTP}]'=>$otp 
				);
				foreach($replace_data as $key=>$val ){
					$body=str_replace($key,$val,$body);
				}
					$email_data=array(
					'from_email'=>'admin@vendorfinance.com',
					'from_name'=>'Vendor Finance',
					'to_email'=>$user_details_arr['user_email'],
					'subject'=>$template_details['subject'],
					'body'=>$body
					);
				  if($this->cust_send_email($email_data)){
					$this->session->set_userdata('success_cust',INFO_C203);

					redirect(ADMINBASEURL.'customer/reset_verify/'.$salt);

				  } 
		  } 
        }	
		public function reset_verify($salt)
		{  	 
		if($salt==''){
			redirect(CUSTOMERBASEURL.'customer/login/');
		}
			   $data['siteSettings'] = $this->data['siteSettings'];
		  /*Customer Login Function*/
            if(count($_POST)>0){ 
 				$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
				$this->form_validation->set_rules('user_otp', 'OTP', 'required|numeric');
 				$user_otp    = $this->input->post('user_otp');
				 
				if ($this->form_validation->run()=='TRUE') {
					$logged_data=$this->customer_model->check_otp($user_otp,$salt);
					if( $logged_data->num_rows()!=0){ 
						$logged_data_set=$logged_data->row_array();
						    $cur_date=date('Y-m-d H:i:s');
						 $otp_sent_date=$logged_data_set['created_date'];  
						//echo $plus_expiry_hr=date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s')$logged_data_set['expiry_hrs']."hr"));   
						    $plus_expiry_hr=date('Y-m-d H:i:s',strtotime($otp_sent_date."+".$logged_data_set['expiry_hrs']." hour"));
					
						if(strtotime($cur_date) < strtotime($plus_expiry_hr)){
							 
								$table_name="cust_forgot_password";
								$data_update=array(
									'status'=>'Completed',
									'completed_date'=>$cur_date
								); 
								$where_cond=array('otp'=>$user_otp,'salt_key'=>$salt); 
								$this->customer_model->update_table($table_name,$data_update,$where_cond); 
								redirect(ADMINBASEURL.'customer/reset_password/'.$salt);
						}else{
						 
							#cant process";
							$this->session->set_userdata('error_cust',ERROR_C206);
						}
					
 						if($is_sent){
							$this->session->set_userdata('info_cust',INFO_C204); 
							redirect(ADMINBASEURL.'customer/reset_verify/'.$salt_data[0]);
						} 
					}else{
						$this->session->set_userdata('error_cust',ERROR_C207);
					}
					
				}
			}
			$data['salt']=$salt; 
			$data['view_file']='customer/recive_otp'; 
            $this->load->view('customer/common/template',$data);
        }	
		public function invoices($type="")
        { 
			$this->IsloggedIn(); #is logged in ..? 
			
			$data['invoice_type']=$type;
			if($this->input->get('m')=='yes')
			{
				$file_upload='yes';
			}else{
				$file_upload='no';
			}
			$data['max_file_size']=$this->config->item('max_file_upload_size_label'); 
			$data['file_upload']=$file_upload; 
			$data['view_file']='customer/pending-invoices'; 
			$data['inv_active']='active';
            $this->load->view('customer/common/template',$data);
            
        }
		public function getInvoiceJson($type=""){
			$this->IsloggedIn(); #is logged in ..? 			
			$result = $this->session->userdata('customer_login');
			/* $data['user_name']=$result['user_name'];
			$data['siteSettings'] = $this->data['siteSettings']; */
						$where_Array=array();
			 if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
				$where_Array['invoice_date >=']=$from_date;
			
			 }
			 if(count($_POST)>0&& $_POST['filter_to']!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
				$where_Array['invoice_date <=']=$to_date;
				
			 } 
			  if(count($_POST)>0&& $_POST['type']!=''){ 
				$type=$_POST['type'];	
				
			 } 
			$file_upload = $this->input->post('file_upload'); 
			if($file_upload=='yes')
			{
					$columns = array( 
							0 =>'t1.invoice_id',
							1 =>'t1.invoice_date',
							2 =>'t1.invoice_number',
							3 =>'t1.invoice_transactionid',
							4 =>'t1.invoice_beneficiary_name',
							5 =>'t1.invoice_amount',	
							6 =>'t1.invoice_discount',	
							8 =>'invoice_deduction_days',
							7 =>'t1.invoice_topaid',		
							9 =>'t1.invoice_status',	
							10 =>'t1.reject_reason',		
							); 		
			}else{
			 $columns = array( 
				0 =>'t1.invoice_id',
				1 =>'t1.invoice_date',
				2 =>'t1.invoice_number',
				3 =>'t1.invoice_transactionid',
				5 =>'t1.invoice_amount',	
				6 =>'t1.invoice_discount',	
				7 =>'t1.invoice_topaid',		
				9 =>'t1.invoice_status',		
				); 	
			}
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];	
				 $select_query=$this->customer_model->get_all_invoice_query($type,'',$where_Array); 
				$groupby =" group by t1.invoice_id";
			 //echo $select_query,$groupby;die;
				 $totalData = $this->dashboard_model->allJoinPostsCount('',$select_query,$groupby);
 
				 $totalFiltered = $totalData; 

				if(empty($this->input->post('search')['value']))
				{   
				$posts = $this->dashboard_model->allJoinPosts('',$limit,$start,$order,$dir,$select_query,$groupby);    
				// echo $this->db->last_query();
				}
				else { 
				$search = $this->input->post('search')['value']; 
				$posts =  $this->dashboard_model->JoinPostsSearch('',$limit,$start,$search,$order,$dir,$columns,$select_query,$groupby);
			

   			$totalFiltered = $this->dashboard_model->JoinPostsSearchCount('',$search,$columns,$select_query,$groupby);
			 	} 	
				
				$data = array();
				if(!empty($posts))
				{
					$i=1;
					foreach ($posts as $post)
					{
						if($file_upload=='yes')
						{ 
							$nestedData['sl_no'] = "<input type='checkbox' class='file-up' name='invoice_file_up[]' value='".$post->invoice_id."' />";
						}else{
							$nestedData['sl_no'] = $i;
						}
						$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['invoice_date'] = date('d-m-Y',strtotime($post->invoice_date));			
						$nestedData['invoice_number'] = $post->invoice_number;						
						$nestedData['invoice_transactionid'] = $post->invoice_transactionid;
						$nestedData['invoice_beneficiary_name'] = $post->invoice_beneficiary_name;
						$nestedData['invoice_amount'] = $post->invoice_amount;
						$nestedData['invoice_discount'] = $post->invoice_discount;	
						$nestedData['invoice_status'] = $post->invoice_status;	
						$nestedData['invoice_topaid'] = $post->invoice_topaid;		
						if($file_upload=='yes')
						{ 
							
						}else{
							$nestedData['invoice_deduction_days'] = $post->invoice_deduction_days;	
							
							$nestedData['reject_reason'] = $post->reject_reason;							
							$nestedData['documents'] = ($post->rand_key==""?"N/A":"<i class='fa fa-check text-success'></i>") ;
							$nestedData['actions'] =	" <a href=".CUSTOMERBASEURL."customer/documents/".$post->invoice_id."><i class='fa fa-upload'></i> Upload</a>";
						}
						$data[] = $nestedData;
						$i++;
					} 
				}
			
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 

				
		}
		public function invoice_by_vendor($vendor)
        { 
			$this->IsloggedIn(); #is logged in ..? 
			
			if($vendor==''){
				redirect(CUSTOMERBASEURL.'customer');
			}
			$where_Array=array();
			 if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
				$where_Array['invoice_date >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if(count($_POST)>0&& $_POST['filter_to']!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
				$where_Array['invoice_date <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];
			$invoice_data=$this->customer_model->get_all_invoice_by_vendor_list($vendor,$where_Array);  
			//	echo $this->db->last_query();
			$data['invoice_data']=$invoice_data; 
			$data['invoice_type']=base64_decode($vendor); 
			$data['vendor']=$vendor;
			$data['view_file']='customer/invoice_by_vendor';
			$data['vp_active']='active';
            $this->load->view('customer/common/template',$data);            
        } 
		
		public function getInvoiceByVendorJson(){
			 $columns = array( 
				0 =>'invoice_id',
				1 =>'invoice_date',
				2 =>'invoice_number',
				3 =>'invoice_transactionid',
				4 =>'invoice_beneficiary_name',
				5 =>'invoice_beneficiary_number',	
				6 =>'invoice_amount',	
				7 =>'invoice_net',
				8 =>'invoice_topaid',	
				9 =>'invoice_deduction_days',	
				10 =>'invoice_status',					
				); 
				
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
			// get vendor
			$vendor ="";
			if($this->input->get('vendor') !=''){
				$vendor = $this->input->get('vendor');
			}
			$where_Array=array();
			 if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
				$where_Array['invoice_date >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if(count($_POST)>0&& $_POST['filter_to']!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
				$where_Array['invoice_date <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			 $select_query=$this->customer_model->get_all_invoice_by_vendor_list($vendor,$where_Array); 
			$group_by =" ";
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{ 
				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);         
			}
			else {
				$search = $this->input->post('search')['value']; 
				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);
				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}
			$data = array();
				$i=1;
					foreach ($posts as $post)
					{
									
						$nestedData['invoice_id'] = $post->invoice_id;
				 		$nestedData['invoice_date'] =date('d-m-Y',strtotime($post->invoice_date));						
						$nestedData['invoice_number'] =$post->invoice_number;
						$nestedData['invoice_transactionid'] =$post->invoice_transactionid;
						$nestedData['invoice_beneficiary_name'] =$post->invoice_beneficiary_name;
						$nestedData['invoice_beneficiary_number'] =$post->invoice_beneficiary_number;
						$nestedData['invoice_amount'] =$post->invoice_amount;
						$nestedData['invoice_net'] =$post->invoice_net;
						$nestedData['invoice_discount'] =$post->invoice_discount;
						$nestedData['invoice_topaid'] =$post->invoice_topaid;
						$nestedData['invoice_deduction_days'] =$post->invoice_deduction_days;
						$nestedData['invoice_status'] =$post->invoice_status;
						$nestedData['actions'] =" <a href=".CUSTOMERBASEURL."customer/documents/".$post->invoice_id."><i class='fa fa-upload'></i> Upload</a>";
						
						
						
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
			
		} 
		public function documents($invoice_id)
        {  
			$type="";
			$this->IsloggedIn(); #is logged in ..? 
			 $result = $this->session->userdata('customer_login');
			 $data['user_name']=$result['user_name'];
			 $data['cust_code']=$result['cust_user_code'];
            $data['siteSettings'] = $this->data['siteSettings'];
			$invoice_data=$this->customer_model->get_all_invoice($type,$invoice_id);  
			$all_invoice_document=$this->customer_model->get_all_invoice_document($invoice_id);  
 			$data['invoice_data']=$invoice_data[0]; 
 			$data['all_invoice_document']=$all_invoice_document; 
			$data['invoice_type']=$type; 
			$customer_path=str_replace('{CUST_CODE}',$data['cust_code'],UPLOADS_CUST_DOC);
			$customer_path=str_replace('./',CUSTOMERBASEURL,$customer_path);
			$data['customer_path']=$customer_path;
			$data['max_file_size']=$this->config->item('max_file_upload_size_label'); 
			$data['view_file']='customer/upload_documents';
            $this->load->view('customer/common/template',$data);
            
        } 
		public function remove_document($rand_key,$doc_id) #remove uploaded document
        { 
			 
			$this->IsloggedIn(); #is logged in ..? 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];
 			$all_invoice_document=$this->customer_model->remove_invoice_document($rand_key,$doc_id);   
			$this->session->set_userdata('ac_success_message', ERROR_C209);
            redirect($_SERVER['HTTP_REFERER']);
        } 	
		/*************uploadInvoicesForm: Displays upload form and file listing******************/
		public function uploadInvoicesForm(){
			$this->IsloggedIn(); 
			$result = $this->session->userdata('customer_login');
				$cust_id=$result['cust_id'];
				$where="cust_id =".$cust_id;
				$customer_details = $this->customer_model->get_DatabyCommon('customer_details',$where,'cust_user_code');
				$customer_code = $customer_details->cust_user_code;
			   
			  $code = '{CUSTOMER_CODE}';				        
			// $path = str_replace($code,$customer_code,ERROR_C412);
			$path = 'uploads/'.$customer_code.'/invoice/';
			
			$this->load->library('csvreader');
			$this->load->helper('directory'); 
			$map = directory_map($path);
			
			
			$delete_arr = array();	
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
			$cust_id=$result['cust_id'];
			$where="cust_id =".$cust_id;
			$customer_details = $this->customer_model->get_DatabyCommon('customer_details',$where,'cust_user_code');
			$customer_code = $customer_details->cust_user_code;

			$data['siteSettings'] = $this->data['siteSettings'];
			$data['max_file_size']=$this->config->item('max_file_upload_size_label'); 
			$data['view_file']='customer/upload-invoices';
			$data['upload_active']='active';
			$where="customer_id =".$cust_id;
			$invoice_data_csv=$this->vendor_model->get_DatabyCommonFull('invoice_csv_uploads',$where,'*');   #get_all_invoice_by_vendor \
			
 			/* 	foreach ($invoice_data_csv as $row){
					if(in_array($row->filename,$map)){
						$row->status=1;
					}else{
						$row->status=0;
					}
				} */
##COMMENTED BY SIMI. WE CAN GET THE STATUS FROM TABLE.
			$data['invoice_data_csv']=$invoice_data_csv;  
			$this->load->view('customer/common/template',$data);
		}
		/********************deleteInvoiceCSV:Delete CSV file if not processed***************************/
		public function deleteInvoiceCSV($delete_id){
			$this->IsloggedIn(); 
			$path = CUS_INVOICE_READFROM;
			$custoInvoices_posted=$this->vendor_model->get_uploaded_invoice(array($delete_id)); 
		 
			$readPath = $path.$custoInvoices_posted[0]['cust_user_code']."/invoice/".$custoInvoices_posted[0]['filename'];
			$where="id =".$delete_id; 
			$delete_file =  $readPath;
			 
			if(unlink($delete_file)){
				$invoice_data_csv=$this->vendor_model->deleteCommon('invoice_csv_uploads',$where);
				
			}
			$this->session->set_userdata('ac_success_message', INFO_C401);
			redirect(ADMINBASEURL.'customer/uploadInvoicesForm','refresh');
			
		}
		public function addCustomerCodeInExcel($customer_code){
			$path = INVOICE_TEMPLATE; 
			$this->load->helper('directory');
			$this->load->library('csvreader');
			$map = directory_map($path);
			$readPath = $path.$map[0];            
			$file = fopen($readPath,"w");			
            fputcsv($file, $customer_code);
			fclose($file);
			}


        /********************Upload Invoices :validate excel file and do upload************************************/
		public function upload_invoices(){
				$this->IsloggedIn(); 
				$flag =1;
				$i =0;
				$column_array =array();
				
                $this->load->helper('directory'); 
			
				$valid_file =1;
				$result = $this->session->userdata('customer_login');
				$cust_id=$result['cust_id'];
				$where="cust_id =".$cust_id;
				$customer_details = $this->customer_model->get_DatabyCommon('customer_details',$where,'cust_user_code');
				
				$customer_code = $customer_details->cust_user_code;
				
			    $path ='uploads/';
				$map = directory_map($path);
				
                $error_messages =array();
				 $myarrayColumns = array('customer_code','vendor_code','beneficiary_number','beneficiary_ifsc_code',
                'beneficiary_name','invoice_number','invoice_date[dd-mm-yyyy]','invoice_amount','net_or_gross','deduction_days'); # 
				$file_types =array('application/vnd.ms-excel', 'csv','application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel','application/octet-stream'); 
				
					if($_FILES['file_invoice']['name'] == ""){
						$error_messages['file_exists'] =ERROR_C406;
						$valid_file =0;
						
					}
					
				    
				     if(!in_array($_FILES['file_invoice']['type'],$file_types)){ 
						$error_messages['file_format'] =ERROR_C407;
						$valid_file =0;
						
					}
					
					if($valid_file ==1){
					$fileContent = file_get_contents($_FILES['file_invoice']['tmp_name']);					
					$lines= explode("\n", $fileContent);	
					$net_or_gross = array("GROSS","NET");
					
			
			
			
					
					foreach($lines as $line){
					$columns = explode(",", $line);
					
					
				    if($i==0){
					  foreach($columns as $key=>$val){
						
					   $column_name =  trim(str_replace(' ', '_', strtolower($val)));
					    array_push($column_array, $column_name);
					 
					            
								if(in_array($column_name,$myarrayColumns)!=1 ){
								
									$flag =0;
									
									$error_messages['column_name'] =ERROR_C408;
									
								}
						  }
					 
			  
					}
					
					
					 if(($i != 0 )&&( $i<count($lines)-1) ){
						$valid_Customer = $this->validateCustomerCode($line);
						$line_number =$i+1;
						if(!$valid_Customer){
							$flag =0;
							$code = '{LINE_NUMBER}';				        
							$error_messages['customer_code'] = str_replace($code,$line_number,ERROR_C412);
							
						}
						
					
					if(trim(strtoupper($columns[0])) != strtoupper($customer_code)){			
							
							$flag =0;
							$code = '{LINE_NUMBER}';				        
							$error_messages['customer_code'] = str_replace($code,$line_number,ERROR_C418);

						}
					    if(trim(strtoupper($columns[1])) != ''){							        
							
							$vendor_verify=$this->customer_model->verify_vendor_list($columns[1]);
							if($vendor_verify<1)
							{
								$flag =0;
								$code = '{LINE_NUMBER}';
								$error_messages['customer_code'] = str_replace($code,$line_number,ERROR_C421);
							}

						}						
						 if(count($columns) !=10 && empty($error_messages['column_name'])){
							$flag =0;
							$code = '{LINE_NUMBER}';							
							$error_messages['column_count'] =str_replace($code,$line_number,ERROR_C413);
							
						}
					     if(!($this->checkCellValueEmpty($columns)) &&  empty($error_messages['column_name'])){
							
							$flag =0;
							$code = '{LINE_NUMBER}';							
							$error_messages['cell_value'] = str_replace($code,$line_number,ERROR_C414);
						}
						  if((in_array(strtoupper($columns[8]),$net_or_gross) ) != 1){
							 $flag =0;
							 $code = '{LINE_NUMBER}';							
							$error_messages['gross_net'] = str_replace($code,$line_number,ERROR_C415);
							
						 }
						
						 
						 
						
					}
					
					
					$i++;
					}
					
					$check_invoice_number = $this->checkInvoiceNumber($lines);
					if($check_invoice_number ==0 ){
						$flag =0;						
						$error_messages['invoice_number'] =ERROR_C417;
					}
					$result_diff=array_diff($myarrayColumns,$column_array);
				   
					if(!empty($result_diff)){
						
						$flag =0;
						
							$error_messages['column_name'] =ERROR_C409;
					}
					}
					
						if( $flag==0 || $valid_file ==0)
						{
								

								$i =1;   
								foreach($error_messages AS $key=>$data)
								{

								$columns=array_keys($data);
								$error_throw.='<ul>';					

								$error_throw.='<li>'.$data.'</li>';

								$error_throw.='</ul>';
								$i++;
								}

								$this->session->set_userdata('ac_error_message', $error_throw);
								redirect(ADMINBASEURL.'customer/uploadInvoicesForm','refresh');
						}
						else{
							$baseurls='uploads/'.$customer_code.'/invoice/';
							  $customer_code = $customer_code."\\";
							 foreach($map as $key=>$val){								 
								   if($key!=$customer_code){										
									mkdir($baseurls, 0777, true);
								}
								
							 }
							  
								
								
								$return_value=$this->do_uploades($baseurls,'file_invoice','csv');
								if($return_value){
								$this->session->set_userdata('ac_success_message', INFO_C404);
								}else{
								$this->session->set_userdata('ac_error_message', ERROR_C410);	
								}
								redirect(ADMINBASEURL.'customer/uploadInvoicesForm','refresh');
							
						}

				
				 
		}
		
		public function checkInvoiceNumber($lines){
			$flag=1;
			$invoice_number_arr =array();
			
					
					
			foreach($lines as $line){
				if($i !=0 && ( $i<count($lines)-1)){
					$columns = explode(",", $line);
			          
			 array_push($invoice_number_arr,$columns[5].'+'.$columns[1]);
				}
				$i++;
			}
			
			if(count(array_unique($invoice_number_arr)) != count($invoice_number_arr))
			{
			
				$flag=0;
			}
			
			return $flag;
		}
		public function checkCellValueEmpty($columns){
			$flag=1;
		foreach($columns as $key=>$val){
				if($val =="")$flag=0;
		}		
			return $flag;
		}
		public function validateCustomerCode($line){
			$flag=1;
			
					$columns = explode(",", $line);
				   
					$customer_id = $columns[0];
					 $customer_count = $this->customer_model->get_column_count('customer_details',array('cust_user_code'=>$customer_id));
						if($customer_count!=1 && !empty($customer_id)){
							$flag=0;
						}
						
					
			
			return $flag;
		}
		
	
		  public function exportCSV(){ 
		  
		  $this->IsloggedIn(); 	
		   $result = $this->session->userdata('customer_login');
		   $data['user_name']=$result['user_name'];
		   $cust_id=$result['cust_id'];
		   $where="cust_id =".$cust_id." and cust_user_code != 'Admin'";
		   $this->load->dbutil(); 
		   $this->load->helper('download');
		   $where_count=" where customer_id =".$cust_id;
		   $res=$this->db->query("select max(id) as id from invoice_csv_uploads $where_count");		
			
			if(count($res)>0){
				$id_array = $res->result_array();
			$id = $id_array[0]['id'];
			$where = "id =".$id;
			$file_result = $this->customer_model->get_DatabyCommon('invoice_csv_uploads',$where,'filename');
			$str = substr(strrchr($file_result->filename, '_'), 1);
			$append_code = (int)$str +1;
			//$new_name = $customer_code.'-INV-'.date('Y-m-d').'-'. $append_code.'.csv'; 
			$filename ='invoice_list_'.date('Ymd').'_'.$append_code.'.csv'; 
				
			}else{
			// $new_name = $customer_code.'-INV-'.date('Y-m-d').'-01'.'.csv'; 
			$filename = 'invoice_list_'.date('Ymd').'csv'; 
			}
		     
		   $query = $this->db->query("SELECT cust_user_code AS customer_code,'' AS vendor_code,
   '' as beneficiary_number, '' as beneficiary_ifsc_code,'' as beneficiary_name,'' as invoice_number,
   '' as 'invoice_date[dd-mm-yyyy]','' as invoice_amount,'' as net_or_gross ,'' as deduction_days
   		   FROM customer_details where cust_id =$cust_id and cust_user_code != 'Admin'"); 
		   
		   force_download($filename, $this->dbutil->csv_from_result($query)); 
		   exit;
		  }
				
		
		
		
		public function upload_multi_documents()
        { 
			 
			$this->IsloggedIn(); #is logged in ..?   
            $data['siteSettings'] = $this->data['siteSettings']; 
			if(count($_POST['invoice_file_up'])>0){
				
			if(count($_FILES['documents']['name'])>0){	
				
				$ret_im_name= $this->upload_files('inv',$_FILES['documents']); 			
					
				 
				foreach($ret_im_name['success'] as $uploaded_images){
					foreach($_POST['invoice_file_up'] as $inv_details)
					{
						$data_to_insert=array(
							'invoice_id'=>$inv_details,
							'uploaded_date'=>date('Y-m-d H:i:s'),
							'document_name'=>$uploaded_images,
							'rand_key'=>time().rand(0,100000),
							'ip_address'=>$this->input->ip_address(),
							'status'=>'1'  
						);
						$this->customer_model->update_invoice_document($data_to_insert);
					}
				}
				 if(count($ret_im_name['failed'])>0){
				  $this->session->set_userdata('error',ERROR_C411); 
				 }else{ 
					$this->session->set_userdata('ac_success_message', INFO_C404);
				 }
				}else{
					 $this->session->set_userdata('error',ERROR_C411);
				}
				 redirect(CUSTOMERBASEURL."customer/invoices?m=yes");
				 			 
			}else{ 
				$this->session->set_userdata('error',ERROR_C420);
				redirect(CUSTOMERBASEURL."customer/invoices?m=yes");				
			} 
            
	}
	
		public function upload_documents()
        { 
			 
			$this->IsloggedIn(); #is logged in ..?   
            $data['siteSettings'] = $this->data['siteSettings']; 
			 
			if(count($_FILES['documents']['name'])>0){
				
				$invoice_number=$this->input->post('invoice_number');
				$invoice_id=$this->input->post('invoice_id');
				$ret_im_name= $this->upload_files($invoice_id,$_FILES['documents']); 
				 
				foreach($ret_im_name['success'] as $uploaded_images){
					$data_to_insert=array(
						'invoice_id'=>$invoice_id,
						'uploaded_date'=>date('Y-m-d H:i:s'),
						'document_name'=>$uploaded_images,
						'rand_key'=>time().rand(0,100000),
						'ip_address'=>$this->input->ip_address(),
						'status'=>'1'  
					);
					$this->customer_model->update_invoice_document($data_to_insert);	
				} 
				 if(count($ret_im_name['failed'])>0){
				  $this->session->set_userdata('error',ERROR_C411); 
				 }else{ 
					$this->session->set_userdata('ac_success_message', INFO_C404);
				 }
				 redirect(CUSTOMERBASEURL."customer/documents/".$invoice_id);
				 			 
			}else{ 
				
			} 
            
	}
	
   function upload_files($title, $files)
    {		$this->IsloggedIn(); 	
			$result = $this->session->userdata('customer_login'); 
			$cust_code=$result['cust_user_code']; 
			$customer_path=str_replace('{CUST_CODE}',$cust_code,UPLOADS_CUST_DOC);
			if(!is_dir($customer_path)){
				 mkdir($customer_path,0777,true);  
			} 
			$config['upload_path'] = $customer_path;
			$config['allowed_types'] = 'pdf|jpg|png|doc|docx|csv|xls|xlsx';
			$config['max_size']	= $this->config->item('max_file_upload_size');  
			$config['remove_spaces']	= TRUE;  

        $this->load->library('upload', $config);

        $images = array();

        foreach ($files['name'] as $key => $image) {
			$_FILES['documents[]']['name']= $files['name'][$key];
            $_FILES['documents[]']['type']= $files['type'][$key];
            $_FILES['documents[]']['tmp_name']= $files['tmp_name'][$key];
            $_FILES['documents[]']['error']= $files['error'][$key];
            $_FILES['documents[]']['size']= $files['size'][$key];

			$fileName = $title .'_'. time(); 
            
            $config['file_name'] = $fileName;

            $this->upload->initialize($config);

            if ($this->upload->do_upload('documents[]')) {
                $res_data=$this->upload->data(); 
				$images['success'][] = $res_data['file_name'];
				$this->encrypt_my_files($customer_path,$res_data['file_name']);		#encrypt files		
            } else {
				
				$error = array('error' => $this->upload->display_errors()); 
                 $images['failed'][] = $this->upload->display_errors(); 
            }
        } 
        return $images;
    }
	
	
	public function do_uploades($baseurls,$filerec,$Formats){      
	 
			$this->IsloggedIn(); 	
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
			$cust_id=$result['cust_id'];
			$where="cust_id =".$cust_id;
			$customer_details = $this->customer_model->get_DatabyCommon('customer_details',$where,'cust_user_code');
			$customer_code = $customer_details->cust_user_code;	
			$where_count=" where customer_id =".$cust_id;
			$res=$this->db->query("select max(id) as id from invoice_csv_uploads $where_count");		
			
			if(count($res)>0){
				$id_array = $res->result_array();
			$id = $id_array[0]['id'];
			$where = "id =".$id;
			$file_result = $this->customer_model->get_DatabyCommon('invoice_csv_uploads',$where,'filename');
			$str = substr(strrchr($file_result->filename, '_'), 1);
			$append_code = (int)$str +1;
			//$new_name = $customer_code.'-INV-'.date('Y-m-d').'-'. $append_code.'.csv'; 
			$new_name = 'invoice_list_'.date('Ymd').'_'.$append_code.'.csv'; 
				
			}else{
			// $new_name = $customer_code.'-INV-'.date('Y-m-d').'-01'.'.csv'; 
			$new_name = 'invoice_list_'.date('Ymd').'.csv';  
			}
			$config =  array(
                  'upload_path'     => dirname($_SERVER["SCRIPT_FILENAME"])."/".$baseurls,
                  'upload_url'      => ADMINBASEURL.$baseurls,
				
                  'allowed_types'   => $Formats,
                  'overwrite'       => TRUE,
                  'max_size'        => "2000",
				  
                 );				
			$config['file_name'] = $new_name;			
			$this->load->library('upload');
			$this->upload->initialize($config);
			if($this->upload->do_upload($filerec))
			{
				$this->encrypt_my_files($config['upload_path'],$new_name);
				$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
				$file_name = $upload_data['file_name'];
				
			 	$data_to_insert=array(
										'customer_id'=>$cust_id,
										'filename'=>$new_name,
										'date'=>date('Y-m-d H:i:s'),										
										'status'=>1,
										
									);
									
						
									$ret_id=$this->customer_model->insert_Common('invoice_csv_uploads',$data_to_insert);
				
			
			}
			else
			{
				//$error = 
				$file_name ='';
			}
			
			return $file_name;
	}
	
	public function vendor_payments($type="")
	{ 
			$this->IsloggedIn(); #is logged in ..? 
			 $result = $this->session->userdata('customer_login');
			 $data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];
			$where_Array=array();
			$filter_from_date_R=$_POST['filter_from'];
			$filter_to_date_R=$_POST['filter_to'];
			
			if($this->input->get('filter_from')!=""){
				$filter_from_date_R=$this->input->get('filter_from');
			}
			if($this->input->get('filter_to')!=""){
				$filter_to_date_R=$this->input->get('filter_to');
				$where_Array['invoice_status']='Paid';
			}
		
			 if($filter_from_date_R!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($filter_from_date_R));
				$where_Array['payment_datetime >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if($filter_to_date_R!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($filter_to_date_R));
				$where_Array['payment_datetime <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			
			
			$invoice_data=$this->customer_model->get_all_invoice_by_vendor($where_Array);  
	//echo "<pre>";print_r($invoice_data);exit();		
		    	
			$data['invoice_data']=$invoice_data; 
			$data['invoice_type']='Vendor'; 
			$data['view_file']='customer/vendor-payments';
			$data['vp_active']='active';
            $this->load->view('customer/common/template',$data);
            
        }
		
		public function getVendorPaymentsJson(){
			$this->IsloggedIn(); #is logged in ..? 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
			$data['siteSettings'] = $this->data['siteSettings'];
			$where_Array=array();
			$filter_from_date_R=$_POST['filter_from'];
			$filter_to_date_R=$_POST['filter_to'];
			
			if($this->input->get('filter_from')!=""){
				$filter_from_date_R=$this->input->get('filter_from');
			}
			if($this->input->get('filter_to')!=""){
				$filter_to_date_R=$this->input->get('filter_to');
				$where_Array['invoice_status']='Paid';
			}
			if($filter_from_date_R!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($filter_from_date_R));
				$where_Array['payment_datetime >=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if($filter_to_date_R!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($filter_to_date_R));
				$where_Array['payment_datetime <=']=$to_date;
				$data['filter_to']=$to_date;
			 }
			  $columns = array( 
				0 =>'invoice_id', 				
				1 =>'invoice_beneficiary_name',		
				2 =>'invoice_beneficiary_number',
				3 =>'invoice_amount',
				4 =>'invoice_topaid',	
				5 =>'invoice_date',	
				6 =>'payment_datetime',		
				7 =>'invoice_status',							
				); 				
				
				
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
		    $select_query = $this->customer_model->get_all_invoice_by_vendor_query($where_Array); 	
			$group_by ="";
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{   

				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
               
			}
			else {
				$search = $this->input->post('search')['value']; 

				 $posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}		
			 $data = array();
				$i=1;
					foreach ($posts as $post)
					{
							
						$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['invoice_beneficiary_name'] =$post->invoice_beneficiary_name;
						$nestedData['total_invoice'] =$post->total_invoice;
						$nestedData['payment_datetime'] =date('d-m-Y',strtotime($post->payment_datetime));
						 
						$nestedData['totl_amount'] =number_format($post->totl_amount,2);
						$nestedData['invoice_discount'] =number_format($post->invoice_discount,2);
						$nestedData['invoice_topaid'] =number_format($post->invoice_topaid,2);
						$nestedData['gross_settled'] =number_format(($post->invoice_topaid+$post->invoice_discount),2);
						$nestedData['balance_due'] =number_format($post->totl_net_amount-($post->invoice_topaid+$post->invoice_discount),2);
						$nestedData['actions'] ="<a  href=".CUSTOMERBASEURL."customer/invoice_by_vendor/".base64_encode($post->invoice_beneficiary_name)."><i class='fa fa-eye'></i> Details</a> ";
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data);  
			
		}
		private function cust_send_email($data_rec){
			
			vfemail($data_rec['to_email'],$data_rec['subject'],$data_rec['body']);
			return true;
			/*
			$this->load->library('email'); 
			$this->email->from($data_rec['from_email'], $data_rec['from_name']);
			$this->email->to($data_rec['to_email']); 
			$this->email->subject($data_rec['subject']);
			$this->email->message($data_rec['body']); 
			if($this->email->send()){
				return true;
			}else{
				return true; #FLASE on PRODUCTION ENVIRONMENT
			}*/
		}
	 function myprofile($is_otp=''){ 
			$this->IsloggedIn(); 
			
			$result = $this->session->userdata('customer_login'); 
			$data['user_name']=$result['user_name'];
			$data['cust_id']=$result['cust_id'];
            $data['siteSettings'] = $this->data['siteSettings'];
			$table_t='invoice_details';
			$options_t='sum(invoice_amount) as total_approved';
			$where_t="invoice_status ='Paid'";
			$total_approved_amount=$this->customer_model->get_counts($table_t,$options_t,$where_t); 
			 $amount_spent=$total_approved_amount['total_approved'];
			 $data['amount_spent']=$amount_spent;
			$where_array=array(
					'cust_id'=>$result['cust_id']
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			#GENERAL FORM ACTION
			 if(count($_POST)>0&& isset($_POST['phone_number'])){ 
					$this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
					$this->form_validation->set_rules('name', 'Name', 'required');
					$this->form_validation->set_rules('phone_number', 'Phone number', 'required');
 					$this->form_validation->set_rules('address_1', 'Address 1', 'required');
					$this->form_validation->set_rules('city', 'City', 'required');
					$this->form_validation->set_rules('state', 'State', 'required');
					$this->form_validation->set_rules('company', 'Company name', 'required');
					$this->form_validation->set_rules('cust_account_no', 'Account Number', 'required');
					$this->form_validation->set_rules('cust_ifsc_code', 'IFSC Code', 'required');
				if ($this->form_validation->run()=='TRUE') {
					$update_data=array(
							'cust_name'=>$this->input->post('name'),
							'cust_phone'=>$this->input->post('phone_number'),
							'cust_address1'=>$this->input->post('address_1'),
							'cust_address2'=>$this->input->post('address_2'),
							'cust_city'=>$this->input->post('city'),
							'cust_state'=>$this->input->post('state'),							
							'cust_ifsc_code'=>$this->input->post('cust_ifsc_code'),
							'cust_account_no'=>$this->input->post('cust_account_no'),
					);
					$where_arr=array('cust_id'=>$result['cust_id']);
					$updated=$this->customer_model->update_table('customer_details',$update_data,$where_arr);
					if($updated){
						#update user_details table for applicable fields
						 $customer_updated=array(
							'user_name'=>$this->input->post('name'),
							'user_phone'=>$this->input->post('phone_number')
						 );
						$where_arr=array('cust_id'=>$result['cust_id']);
						$updated=$this->customer_model->update_table('user_details',$customer_updated,$where_arr);
						$result['user_name']=$this->input->post('name');
						$this->session->set_userdata('customer_login',$result);
						$this->session->set_userdata('ac_success_message',INFO_C207); 
								redirect(ADMINBASEURL.'customer/myprofile/');
						//redirect(CUSTOMERBASEURL.'customer/myprofile','refresh');
					}
				}else{
						$data['basic_active']='active';
				}
			 }else  if(count($_POST)>0&& isset($_POST['email'])){   #ACCOUNT FORM ACTION
		 
					$this->form_validation->set_error_delimiters('<div class="form_error">','</div>'); 
 					$this->form_validation->set_rules('email', 'Email Address', 'required|valid_email|callback_check_email');
					$this->form_validation->set_rules('password', 'Password', 'required');
					#$this->form_validation->set_rules('cpassword', 'Confirm Password', 'min_length[6]|matches[password]');
 					if($this->form_validation->run()=='TRUE') {
						$res=	$this->customer_model->check_login($this->input->post('email'),$this->input->post('password'));
						if($res->num_rows()!=0){ 
							#Sending OTP for updated Email To Proceed
							if($resul_customer['cust_email']!=$this->input->post('email') || $this->input->post('password')!=''){
								#IF Email changed set details in to the session variable and waiting for th OTP
								$param_to_otp=array('cust_id'=>$result['cust_id']);
								$otp_details=$this->customer_model->forgot_password_request($param_to_otp,1); #insert OTP in Table
								$OTP=$otp_details[1]; #OTP
								$salt=$otp_details[0]; #salt
								$user_data['user_email']=$resul_customer['cust_email'];
								$user_data['user_name']=$result['user_name'];
								$is_sent=$this->send_otp($user_data,$OTP,$salt);
								if($is_sent){
									$account_updated_array=array(
 									'password'=>$this->input->post('password'),
									'salt'=>$salt,
									);
									$this->session->set_userdata('account_updated_info',$account_updated_array);
									$this->session->set_userdata('ac_info_message','Password Reset link is sent to your registered Email Address. Please check your inbox');
									//redirect(CUSTOMERBASEURL.'customer/myprofile/enter-otp');
								}else{
									 
								}
							}
						}else{
							 
							$this->session->set_userdata('ac_info_message','Entered Password is incorrect. Please try again');
						}
						
						
					 
						$data['ac_active']='active';
						
					}else{
							
						$data['ac_active']='active';
					}
			 }else if(count($_POST)>0&& isset($_POST['otp'])){ 
				
						$this->form_validation->set_error_delimiters('<div class="form_error">','</div>'); 
						$this->form_validation->set_rules('otp', 'OTP', 'required');
						 
						if($this->form_validation->run()=='TRUE') {
						$account_updated_info=$this->session->userdata('account_updated_info');
						$user_otp=$this->input->post('otp');	
						$salt=$account_updated_info['salt']; 
							// print_r($account_updated_info);die;
					$logged_data=$this->customer_model->check_otp($user_otp,$salt);
				//	echo $this->db->last_query();
					if( $logged_data->num_rows()!=0){ 
						$logged_data_set=$logged_data->row_array();
						$cur_date=date('Y-m-d H:i:s');
						 $otp_sent_date=$logged_data_set['created_date'];  
						//echo $plus_expiry_hr=date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s')$logged_data_set['expiry_hrs']."hr"));   
						    $plus_expiry_hr=date('Y-m-d H:i:s',strtotime($otp_sent_date."+".$logged_data_set['expiry_hrs']." hour"));
					
						if(strtotime($cur_date) < strtotime($plus_expiry_hr)){
							 
								$table_name="cust_forgot_password";
								$data_update=array(
									'status'=>'Completed',
									'completed_date'=>$cur_date
								); 
								$where_cond=array('otp'=>$user_otp,'salt_key'=>$salt); 
								$this->customer_model->update_table($table_name,$data_update,$where_cond); 
								$this->session->set_userdata('ac_info_message',''); 
								
								#UPDATE ACCOUT DETAILS in user_details table
								
								$where_cond_n=array('cust_id'=>$data['cust_id']); 
								
								$data_update_n=array(); 
								if($account_updated_info['email']!=''){
									$data_update_n['user_login_name']=$account_updated_info['email'];
									$data_update_n['user_email']=$account_updated_info['email'];
								}
								if($account_updated_info['password']!=''){
 									$data_update_n['user_login_password']=md5($account_updated_info['password']);
								}
								///print_r($data_update_n);die;
								if(!empty($data_update_n)){
									$this->customer_model->update_table('user_details',$data_update_n,$where_cond_n);  
								}
								$data_update_n_2=array();#customer_details
								if(!empty($data_update_n_2)){
									$data_update_n_2=array('cust_email'=>$account_updated_info['email']);
									$this->customer_model->update_table('customer_details',$data_update_n_2,$where_cond_n);  
								}
								$this->session->set_userdata('ac_success_message',INFO_C205); 
								redirect(ADMINBASEURL.'customer/myprofile/');
						}else{
						 
							#cant process";
							$this->session->set_userdata('error_cust',ERROR_C206);
						} 
 						  
					}else{
						$this->session->set_userdata('error_cust',ERROR_C207);
					} 
							
							
							
							
							
							
							
						}
					
				}else {
				 $data['basic_active']='active';
			 }
			if($is_otp!=''){
				$data['ac_active']='active';
				$data['otp_mode']='true';
				$data['basic_active']='';
			}
			
			
			$data['resul_customer']=$resul_customer;
			$data['view_file']='customer/myprofile';
			$data['in_active']='active'; 
            $this->load->view('customer/common/template',$data);
	 
		}
		 
		public function check_email($email)
        {   
			#Check Duplicate Email Address 
            $this->IsloggedIn();  
			$result = $this->session->userdata('customer_login'); 
			$data['user_name']=$result['user_name'];
			$data['cust_id']=$result['cust_id'];
            $cust_id = $data['cust_id'];
            $email  = $this->input->post('email');
            if($cust_id!='')
            {
                $where = array('cust_email'=>$email, 'cust_id !='=>$cust_id);
            }
            else {
                $where = array('cust_email'=>$email);
            }
            $count = $this->customer_model->get_DatabyCommon('customer_details',$where,'count(*) as existcount');
            if($count->existcount==0)
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('check_email', INFO_C207);
                return false; 
            }
        }
		public function funds()
        { 
			$this->IsloggedIn(); #is logged in ..? 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];
			 #Getting total amount spent 

			$table_t='invoice_details';
			$options_t='sum(invoice_amount) as total_approved';
			$where_t="invoice_status ='Paid'";  
			$total_approved_amount=$this->customer_model->get_counts($table_t,$options_t,$where_t);
			 $amount_spent=$total_approved_amount['total_approved'];
			 $data['amount_spent']=$amount_spent;
			 #Getting customer Details
			 $where_array=array(
					'cust_id'=>$result['cust_id']
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			
			$where_Array=array();
			 if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
				$where_Array['from_date']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if(count($_POST)>0&& $_POST['filter_to']!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
				$where_Array['to_date']=$to_date;
				$data['filter_to']=$to_date;
			 } 
 			$invoice_data_master=$this->customer_model->get_all_invoice_by_date_for_debit($where_Array);   #get_all_invoice_by_vendor \
		 
			$data['invoice_data']=$invoice_data_master; 
			$data['resul_customer']=$resul_customer; 
			$data['invoice_type']=$type; 
			$data['view_file']='customer/fund-details'; 
			$data['fun_active']='active';
			$data['basic_active']='active';
            $this->load->view('customer/common/template',$data); 
        }
		
		
		public function getFundsJSon(){
			$columns = array( 
				0 =>'id',
				1 =>'date_conver',
				2 =>'t_type',
				3 =>'invoive_processed',					
				4 =>'amount1',
				); 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
			
			$where_array=array(
					'cust_id'=>$result['cust_id']
				);
			$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
			$where_Array=array();
			if(count($_POST)>0&&  $_POST['filter_from']!=''){ 
			$from_date=date('Y-m-d 00:00:00',strtotime($_POST['filter_from']));
			$where_Array['from_date']=$from_date;
			$data['filter_from']=$from_date;
			}
			if(count($_POST)>0&& $_POST['filter_to']!=''){ 
			$to_date=date('Y-m-d 23:59:59',strtotime($_POST['filter_to']));
			$where_Array['to_date']=$to_date;
			$data['filter_to']=$to_date;
			} 
			
			$limit = $this->input->post('length');
			$start = $this->input->post('start');
			$order = $columns[$this->input->post('order')[0]['column']];		
			$dir = $this->input->post('order')[0]['dir'];
			$select_query = $this->customer_model->get_all_invoice_by_date_for_debit($where_Array);   #get_all_invoice_by_vendor \
		    $group_by ="";			
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			 $totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{   

				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);
            
			}
			else {
				$search = $this->input->post('search')['value']; 

				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}

				$data = array();
				$i=1;
				$over_all_limit=$resul_customer['cust_loan_limit'];
				$r_closing=$over_all_limit;
					foreach ($posts as $post)
					{
							$amount_settled=$post->amount1;
							if($post->t_type=='Debit'){
							$r_closing=$r_closing-$amount_settled;
							}else{
							$r_closing=$r_closing+$amount_settled;
							}							
						$nestedData['id'] = $post->id;
						$nestedData['date'] =date('d-m-Y',strtotime($post->date_conver));
						$nestedData['invoive_processed'] =$post->invoive_processed;
						$nestedData['debited']="";
							$nestedData['credited']="";
						 if($post->t_type =='Debit'){
							$nestedData['debited']=number_format($post->amount1,2) ;
						} 
						if ($post->t_type =='Credit'){
										$nestedData['credited'] = number_format($post->amount1,2);}									
						$nestedData['closing_balance'] = "<i class='fa fa-rupee'></i>". number_format($r_closing,2);
						$nestedData['actions'] ="<a  href=".CUSTOMERBASEURL."customer/".($post->t_type=='Debit'?'vendor_payments':'replenishments').'/?filter_from='.date('d-m-Y',strtotime($post->date_conver))."&filter_to=".date('d-m-Y',strtotime($post->date_conver))."><i class='fa fa-eye'></i> View</a>";
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
			
		}
       
	   public function replenishments()
        { 
			$this->IsloggedIn(); #is logged in ..? 
			
			
			 
			if($this->input->get('filter_from')!=""){
				$filter_from_date_R=$this->input->get('filter_from');
			}
			if($this->input->get('filter_to')!=""){
				$filter_to_date_R=$this->input->get('filter_to');
				//$where_Array['invoice_status']='Paid';
			}
			 if($filter_from_date_R!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($filter_from_date_R));
				$where_Array['date_created>=']=$from_date;
				$data['filter_from']=$from_date;
			 }
			 if($filter_to_date_R!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($filter_to_date_R));
				$where_Array['date_created<=']=$to_date;
				$data['filter_to']=$to_date;
			 }  
			
			$data['view_file']='customer/replenishments'; 
			$data['repmt_active']='active';
			$data['basic_active']='active';
			$data['inv_active']='active';
            $this->load->view('customer/common/template',$data); 
        }
		
		public function getReplenishmentJson(){
			 $columns = array( 
				0=>'id',
				1 =>'date_created',
				2 =>'transaction_number',
				3 =>'amount',
				4 =>'drawn_bank',

				); 
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];	
			$result = $this->session->userdata('customer_login');
			 #Getting customer Details
			 $where_array=array(
					'cust_id'=>$result['cust_id']
				);
				
				$where_Array=array();
				if($this->input->get('filter_from')!=""){
				$filter_from_date_R=$this->input->get('filter_from');
			}
			if($this->input->get('filter_to')!=""){
				$filter_to_date_R=$this->input->get('filter_to');
				//$where_Array['invoice_status']='Paid';
			}
			if($this->input->post('filter_from')){
				$filter_from= $this->input->post('filter_from');
				$filter_from_date_R=$filter_from;
			}
		
			
			if($this->input->post('filter_to')){
				$filter_to= $this->input->post('filter_to');
				$filter_to_date_R=$filter_to;
			}
	
			 if($filter_from_date_R!=''){ 
				$from_date=date('Y-m-d 00:00:00',strtotime($filter_from_date_R));
				$where_Array['date_created>=']=$from_date;
			
			 }
			 if($filter_to_date_R!=''){ 
				$to_date=date('Y-m-d 23:59:59',strtotime($filter_to_date_R));
				$where_Array['date_created<=']=$to_date;
				
			 } 
			 $where_Array['cust_id']=$result['cust_id'];
			 $select_query = $this->customer_model->get_table_query('cust_replenishment',$where_Array);   #get_all_invoice_by_vendor \
		
			$totalData = $this->dashboard_model->allJoinPostsCount($active_cust_id,$select_query,$group_by);
			$totalFiltered = $totalData; 
			if(empty($this->input->post('search')['value']))
			{ 
				$posts = $this->dashboard_model->allJoinPosts($active_cust_id,$limit,$start,$order,$dir,$select_query,$group_by);             
			}
			else {
				$search = $this->input->post('search')['value']; 

				$posts =  $this->dashboard_model->JoinPostsSearch($active_cust_id,$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);

				$totalFiltered = $this->dashboard_model->JoinPostsSearchCount($active_cust_id,$search,$columns,$select_query,$group_by);
			}
			$data = array();
				$i=1;
					foreach ($posts as $post)
					{		
               $over_all_limit=$resul_customer['cust_loan_limit'];
									$r_closing=$over_all_limit;					
						$nestedData['id'] = $post->id;
						$nestedData['date_created'] =date('d-m-Y',strtotime($post->date_created));
						$nestedData['transaction_number'] =$post->transaction_number;
						$nestedData['amount'] = "<i class='fa fa-rupee'></i> ".number_format($post->amount,2);
						$nestedData['drawn_bank'] = $post->drawn_bank;
						$nestedData['action'] ="<span>N/A</span>";
						
									$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 		
		
		}
		
		
public function add_replenishments()
        { 
			$this->IsloggedIn(); #is logged in ..? 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];  
			 
			if(count($_POST)>0&& isset($_POST['amount'])){   #ACCOUNT FORM ACTION
								$this->form_validation->set_error_delimiters('<div class="form_error">','</div>'); 
								$this->form_validation->set_rules('amount', ' Amount deposited', 'required|numeric');
								$this->form_validation->set_rules('ref_number', 'Transaction reference', 'required');
								$this->form_validation->set_rules('cheque_date', 'Cheque date', 'required');
								$this->form_validation->set_rules('bank_name', 'Cheque drawn on bank', 'required');
								$this->form_validation->set_rules('remark', 'Transaction remarks', 'required');
								if($this->form_validation->run()=='TRUE') {
									$data_to_insert=array(
										'cust_id'=>$result['cust_id'],
										'amount'=>$this->input->post('amount'),
										'drawn_bank'=>$this->input->post('bank_name'),
										'transaction_number'=>$this->input->post('ref_number'),
										'transition_remarks'=>$this->input->post('remark'),
										'status'=>0,
										'created_by'=>'customer',
										'date_created'=>date("Y-m-d H:i:s",strtotime($this->input->post('cheque_date'))),
									);
									$ret_id=$this->customer_model->insert_Common('cust_replenishment',$data_to_insert);
									if($ret_id){
										$this->session->set_userdata('ac_success_message', INFO_C206);
										redirect(CUSTOMERBASEURL."customer/replenishments/");
									}
								}
			}					
			$data['view_file']='customer/add_replenishments'; 
			$data['repmt_active']='active';
			$data['basic_active']='active';
            $this->load->view('customer/common/template',$data); 
        }
		
		
	public function replenishments_due($mode="") {
			
			$this->IsloggedIn(); #is logged in ..? 
			$result = $this->session->userdata('customer_login');
			$data['user_name']=$result['user_name'];
            $data['siteSettings'] = $this->data['siteSettings'];  
					
			 			
			$data['invoice_data']=$invoice_data; 
			$data['resul_customer']=$resul_customer; 
			$data['view_file']='customer/replenishments_due'; 
 			if($mode!=""){
				return $this->load->view('customer/replenishments_due',$data,true);
			}else{
				$data['basic_active']='active';
				$this->load->view('customer/common/template',$data); 
			}
		
	} 
	
	public function getReplenishmentDueJson(){
		$result = $this->session->userdata('customer_login');
		$where_array=array(
					'cust_id'=>$result['cust_id']
				);
				$customer_basic_details=$this->customer_model->get_table('customer_details',$where_array);
			$resul_customer=$customer_basic_details->row_array();
		$mark_as_paid=$this->input->post('mark_as_paid');
		if(!empty($mark_as_paid)){
			//print_r($_POST);die;
			$where_update=array('invoice_cust_id'=>$result['cust_id']);
			$invoice_id=$this->input->post('mark_as_paid');					 
			$data_update=array('paid_by_customer'=>"Yes",'paid_by_customer_date'=>date('Y-m-d H:i:s'),'customer_remark'=>$this->input->post('customer_remark'));
			$this->customer_model->update_table('invoice_details',$data_update,$where_update,$this->input->post('mark_as_paid'));
		}
		$columns = array( 
			    0 =>'invoice_id',
				1 =>'vendor_code',
				2 =>'invoice_amount',
				3 =>'invoice_net',					
				4 =>'invoice_deduction_days',	
				5 =>'payment_datetime',	
				6 =>'invoice_topaid',	
				7 =>'paid_by_customer',	
				8 =>'invoice_id',	
				9 =>'invoice_id',	
				10 =>'invoice_id',	
				11 =>'invoice_id',	
				12 =>'invoice_id',	
				13 =>'customer_remark',					
				); 
				$limit = $this->input->post('length');
				$start = $this->input->post('start');
				$order = $columns[$this->input->post('order')[0]['column']];		
				$dir = $this->input->post('order')[0]['dir'];	
				$select_query=$this->customer_model->get_replenishments_due_query();
				$group_by =" ";
				$totalData = $this->dashboard_model->allJoinPostsCount('',$select_query,$group_by);
				$totalFiltered = $totalData; 
				if(empty($this->input->post('search')['value']))
				{ 
					$posts = $this->dashboard_model->allJoinPosts('',$limit,$start,$order,$dir,$select_query,$group_by);             
				}
				else {
					$search = $this->input->post('search')['value']; 
					$posts =  $this->dashboard_model->JoinPostsSearch('',$limit,$start,$search,$order,$dir,$columns,$select_query,$group_by);
					$totalFiltered = $this->dashboard_model->JoinPostsSearchCount('',$search,$columns,$select_query,$group_by);
				}
			
			    $data = array();
				$i=1;
					foreach ($posts as $post)
					{
						$gross_amount_rate=0;
									#FORMULA FOR GROSS = PERCENT*INV_AMOUNT*NUMBER_OF_DAYS/365;
									   $gross_amount_rate=$resul_customer['interest_rate']*$post->invoice_amount*($post->invoice_deduction_days/365);
									   $gross_amount_rate=$gross_amount_rate/100;				
						$nestedData['invoice_id'] = $post->invoice_id;
						$nestedData['vendor_code'] = $post->vendor_code;
						$nestedData['invoice_amount'] = number_format($post->invoice_amount,2);
						$nestedData['invoice_net'] = (strtolower($post->invoice_net)=='net'?'Net':'Gross');
						$nestedData['interest_rate'] = $resul_customer['interest_rate'];
						$nestedData['invoice_deduction_days'] = $post->invoice_deduction_days;
						$nestedData['payment_datetime'] = date('d-m-Y',strtotime($post->payment_datetime));
						$nestedData['invoice_topaid'] = number_format($post->invoice_topaid,2);
						$nestedData['gross_amount'] = number_format($gross_amount_rate,2);
						$nestedData['due_date'] = date('d-m-Y',strtotime($post->payment_datetime.'+'.$post->invoice_deduction_days.' days'));
						$nestedData['due_amount'] =(strtolower($post->invoice_net)=='net'?number_format($post->invoice_amount,2): number_format($gross_amount_rate+$post->invoice_amount,2)); 
						$nestedData['status'] =($post->paid_by_customer=="No"?"Due":"Paid"); 
						$nestedData['remark'] =($post->customer_remark==""?"N/A":$post->customer_remark);
					   if($post->paid_by_customer=="No"){ 
					  	$nestedData['actions'] =  "<input type='checkbox' name='mark_as_paid[]' value='".$post->invoice_id."' />";
					   
					   }else{
						   $nestedData['actions'] = "";
					   }
						$data[] = $nestedData;
						$i++;
					}
					
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
				);

				echo json_encode($json_data); 	
	}
	public function encrypt_my_files($path,$file_name) {
		$this->IsloggedIn(); #is logged in ..? 
		$this->load->library('encryption');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr);
		
		$files_content = file_get_contents($path.'/'.$file_name);
		$encrypted_file_content = $this->encryption->encrypt($files_content);
		if(file_put_contents($path.'/'.$file_name,$encrypted_file_content)){
			return true;
		}
	}
	public function download_myfiles($rand_key,$doc_id) { 
		
		$this->IsloggedIn(); #is logged in ..? 
		$result = $this->session->userdata('customer_login');   
		$cust_user_code=$result['cust_user_code'];
		$this->load->library('encryption');
		$this->load->helper('download');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr);
		
		#getting the uploaded file
		$where_array=array(
					'rand_key'=>$rand_key,
					'id'=>$doc_id,
				);
		$uploaded_data=$this->customer_model->get_table('invoice_documents',$where_array);
		$uploaded_data_set=$uploaded_data->row_array(); 
		$customer_path=str_replace('{CUST_CODE}',$cust_user_code,UPLOADS_CUST_DOC);
		 $file_name=$uploaded_data_set['document_name'];
		 //$file_name=$customer_path."/".$uploaded_data_set['document_name'];
		$files_content = file_get_contents($customer_path.'/'.$file_name);
		$decrypted_file_content = $this->encryption->decrypt($files_content);  
		 force_download($file_name,$decrypted_file_content); 
			
	}
public function download_invoice($encrypted_id) { 
		$id=base64_decode($encrypted_id);
		$this->IsloggedIn(); #is logged in ..? 
		$result = $this->session->userdata('customer_login');   
		$cust_user_code=$result['cust_user_code'];
		$this->load->library('encryption');
		$this->load->helper('download');
		// Must be exact 32 chars (256 bit)
		$password_encrypted = substr(hash('sha256', ENC_KEY, true), 0, 32); 
		$config_arr= array( 'cipher' => 'aes-256', 'mode' => 'cbc', 'key' => $password_encrypted);
		$this->encryption->initialize($config_arr);
		
		#getting the uploaded file
		$where_array=array(
					'customer_id'=>$result['cust_id'],
					'id'=>$id,
				);
		$uploaded_data=$this->customer_model->get_table('invoice_csv_uploads',$where_array);
		$uploaded_data_set=$uploaded_data->row_array(); 
		if($uploaded_data_set['status']==1){
			$customer_path=CUS_INVOICE_READFROM.$cust_user_code."/invoice/"; 
		}else{
			$customer_path=CUS_INVOICE_READFROM.$cust_user_code."/invoice_done/"; 
		}
		 $file_name=$uploaded_data_set['filename'];
		 //$file_name=$customer_path."/".$uploaded_data_set['document_name'];
		$files_content = file_get_contents($customer_path.'/'.$file_name);
		$decrypted_file_content = $this->encryption->decrypt($files_content);  
		 force_download($file_name,$decrypted_file_content); 
			
	}
        
}
