<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Templates extends CI_Controller {

	public function __construct()
        {
                parent::__construct();
                $this->data['siteSettings'] = $this->vendor_model->get_DatabyCommon('site_settings',array('id'=>1),'*');
				  $this->load->model('Dashboard_model');
        }        
        public function IsloggedIn()
        {
            $result = $this->session->userdata('member');
            $member_id = $result['member_id'];
            if($member_id!='' && $member_id!=false)
            {
                $returnID = $member_id;
            }
            else
            {
                redirect(ADMINBASEURL.'bankadmin/index','refresh');
            }
            return $returnID; 
        }	        
        
        
        public function mailform()
        {
            $this->IsloggedIn();
            $id = $this->input->get('id');            
            $data['mailtemplates'] = $this->vendor_model->get_DatabyCommon('mail_templates',array('id'=>$id),'*');
            if($id==''){
                $data['title'] = 'Add new mail template';
            }
            else {
                $data['title'] = 'Edit '.$data['mailtemplates']->title;;
            }
           
            $data['mail_edit_id'] = $id;
            $data['page']         = 'admin/pages/mailform';
            $data['siteSettings'] = $this->data['siteSettings'];
            $this->load->view('admin/template',$data);
        }
        
        function mailVerification()
        {
           
            $member_id = $this->IsloggedIn();
            $data['siteSettings'] = $this->data['siteSettings'];          
            $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
            $this->form_validation->set_rules('subject', 'subject', 'required');
            $this->form_validation->set_rules('message', 'message', 'required');
            $this->form_validation->set_rules('title', 'title', 'required');
            
            $mail_edit_id = $this->input->post('mail_edit_id');
            if ($this->form_validation->run()=='TRUE') {
                $mailtemplates['subject']   = $this->input->post('subject');
                $mailtemplates['message']  = $this->input->post('message');
                $mailtemplates['title']   = $this->input->post('title');
                if($mail_edit_id=='')
                {
                    $this->vendor_model->InsertCommon('mail_templates',$mailtemplates);
                    $text = "Added";                     
                    $this->vendor_model->logdetails('New '.$mailtemplates->title.' template added','mail_templates');
                }
                else
                {
                    $previous = $this->vendor_model->get_DatabyCommon('mail_templates',$where,'*'); 
                    $changedItems = $this->vendor_model->validateUpdatedElements($previous,$mailtemplates);
                    if($changedItems!='')
                    {
                        $this->vendor_model->logdetails($previous->title.' '.$changedItems.' details updated ','mail_templates');
                    }
                    $where = array('id'=>$mail_edit_id);
                    $this->vendor_model->UpdateDatabyCommon('mail_templates',$where,$mailtemplates);
                    $text = "Updated";
                }
					$code = '{STATUS_TEXT}';				        
	
                $this->session->set_flashdata('Success',  str_replace($code,$text,INFO_A702));
              
                redirect(ADMINBASEURL.'templates/mailtemplates','refresh');
            }
            else {
                
                if($mail_edit_id!='' && is_numeric($mail_edit_id))
                {
                    $data['title'] = 'Edit';
                }
                else {
                    $data['title'] = 'Add';
                }

                $mailtemplates->title   = $this->input->post('subject');
                $mailtemplates->title  = $this->input->post('message');
                $mailtemplates->title  = $this->input->post('title');
                
                
                $data['mailtemplates'] = $mailtemplates;    
                $data['mail_edit_id'] = $mail_edit_id;
                $data['page'] = 'admin/pages/mailform';
                $this->load->view('admin/template',$data);
            }
        }   
        
        public function mailtemplates()
        {
            $this->IsloggedIn();
            $data['page'] = 'admin/pages/emailtemplates';
            $data['mailtemplates'] = $this->vendor_model->get_DatabyCommonFull('mail_templates','','*');
            $data['siteSettings'] = $this->data['siteSettings'];
           
            $this->load->view('admin/template',$data);
        }
		/*Retuns json output for mail template*/
        public function getMailTemplateJson(){
		   $active_cust_id=$this->session->userdata('active_cust_id');
		   $columns = array( 
				0 =>'id', 
				1 =>'title',
				2=> 'subject',
				3=> 'status',
										
				); 
				 $result = $this->session->userdata('member');
                $member_id = $result['member_id'];
				$result_search = $this->dashboard_model->commonAjax('mail_templates',$columns);
			
				$data = array();
				if(!empty($result_search['posts']))
				{
					$i=1;
					foreach ($result_search['posts'] as $post)
					{
						
						$nestedData['id'] = $post->id;
						
						$nestedData['title'] = $post->title;               
						$nestedData['subject'] = $post->subject;               
						$nestedData['status'] = $post->status;       
                        $edit_path= ADMINBASEURL.'templates/mailform?id='.$post->id;
						$view_path= ADMINBASEURL.'templates/mailformat?id='.$post->id;
						  
						$edit_link = "	<a href=".$edit_path." class='tableicons'>
                          <i class='fa fa-pencil' title='Edit'></i></a>&nbsp;&nbsp;";  
						  $view_link = "<a href=".$view_path." class='tableicons'>
                          <i class='fa fa-eye' title='View'></i></a>&nbsp;&nbsp;";
						  
						$delete_link = " <i class='fa fa-trash clickmaildelete' title='Delete' data-id=".$post->id."></i>
                          &nbsp;&nbsp;";               
						$nestedData['template_actions'] =$edit_link.$view_link.$delete_link;   

                       

						$data[] = $nestedData;
						$i++;
					}
				}
                 
				$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($result_search['totalData']),  
				"recordsFiltered" => intval($result_search['totalFiltered']), 
				"data"            => $data   
				);

				echo json_encode($json_data); 
				
		}
        public function mailformat()
        {
            $this->IsloggedIn();
            
            $id = $this->input->get('id');
            $data['mailtemplates'] = $this->vendor_model->get_DatabyCommon('mail_templates',array('id'=>$id),'*');
            $data['siteSettings'] = $this->data['siteSettings'];
            $data['page'] = 'admin/pages/mailformat';
            
            $this->load->view('admin/template',$data);
        }
        
        public function MailTemplatedelete()
        {
            $id = $this->input->post('del_id');
            $this->vendor_model->deleteCommon('mail_templates',array('id'=>$id));
            $this->vendor_model->logdetails('#'.$id.' template deleted','mail_templates');
            $this->session->set_flashdata('Success', INFO_A701);
            echo "Success";
        }
        
        
       
}