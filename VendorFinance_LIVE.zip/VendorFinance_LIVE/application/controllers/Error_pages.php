<?php

class Error_pages extends CI_Controller
{
    public function __construct()
    {
        /*Site Settings loaded in construct for non-repeat model code in every function*/
        parent::__construct();
        $this->load->library('excel');
        $this->data['siteSettings'] = $this->vendor_model->get_DatabyCommon('site_settings',array('id'=>1),'*');;
    }    
    public function page404()
    {
        $data['page'] = 'errors/html/error_404';
        $data['siteSettings'] = $this->data['siteSettings'];
        $this->load->view('admin/template',$data);
    }
}