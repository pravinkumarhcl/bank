<?php 
 function vfemail($toemail,$emailsubject,$mesasage,$emailcc="") {
    $CI =& get_instance();
    $CI->load->library(array('email'));
	$config = array (
	  'mailtype' => 'html',
	  'charset'  => 'utf-8',
	  'priority' => '1'
	   ); 
	$config['protocol'] = "smtp";
	$config['smtp_host'] = SMTP_HOST;
	$config['smtp_port'] = SMTP_PORT;
	$config['smtp_user'] = SMTP_USER;
	$config['smtp_pass'] = SMTP_PASS;
	$config['newline'] = "\r\n";
	$CI->email->initialize($config);
    $CI->email->from(FROM_EMAIL_ID, FROM_EMAILR_NAME);			
	if(EMAIL_ENVIRONMENT=='development')
	{
		$mesasage .="<br/>Note: This mail is actually addressed to ".$toemail.". Test mails are addressed to ".TEMP_TO_EMAIL.". This will be changed to actual mail recipient and this NOTE also will be removed when moved to production.";
		$CI->email->to(TEMP_TO_EMAIL);		
	}else{		
		$CI->email->to($toemail);
	}		
	if(!empty($emailcc)){
		$CI->email->cc($emailcc);
	}
	if(EMAIL_BCC!='')
	{
		$CI->email->bcc(EMAIL_BCC);
	}
    $CI->email->subject($emailsubject);
    $CI->email->message($mesasage);
    $CI->email->send();    
}  
?>