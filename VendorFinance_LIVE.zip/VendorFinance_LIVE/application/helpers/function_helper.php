<?php  
 function check_module_for_menu($user_type,$module_name) {
	 if($user_type=='bankadmin'){
		 return 1;
	 }
    $CI =& get_instance();
    $CI->load->database(); 
	$CI->db->where('user_type',$user_type);
	$CI->db->where('allowed_modules',$module_name);
	$result=$CI->db->get('user_privileges');
	 $num_rows = $result->num_rows();
	 return $num_rows;
}  
function check_module_for_readonly($user_type,$module_name) {
	 if($user_type=='bankadmin'){
		 return 1;
	 }
    $CI =& get_instance();
    $CI->load->database(); 
	$CI->db->where('user_type',$user_type);
	$CI->db->where('allowed_modules',$module_name);
	$CI->db->where('is_read_only',1);
	$result=$CI->db->get('user_privileges');
	 $num_rows = $result->num_rows();
	 return $num_rows;
}  
?>