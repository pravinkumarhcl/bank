<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['max_file_upload_size']="2048";
$config['max_file_upload_size_label']="2MB";
$config['forgot_request_expiry_in_hours']="1";