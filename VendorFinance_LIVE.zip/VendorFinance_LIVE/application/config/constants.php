<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') OR define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  OR define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') OR define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   OR define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  OR define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           OR define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     OR define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       OR define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE')  OR define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   OR define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              OR define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            OR define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       OR define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits	
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        OR define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          OR define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         OR define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   OR define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  OR define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') OR define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     OR define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       OR define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      OR define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      OR define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

/*User Defined Constants */

define('ADMINBASEURL', 'http://localhost/VendorFinance_LIVE/');
define('CUSTOMERBASEURL', 'http://localhost/VendorFinance_LIVE/');
define('MEDIAURL', 'http://localhost/VendorFinance_LIVE/media/');


define('INVOICE_READFROM', './excel/invoice/');
define('CUS_INVOICE_READFROM', './uploads/');
define('INVOICE_MOVETO', './excel/updatedfiles/');
define('INVOICE_UNLINK', './excel/invoice/');
define('UPLOADS_CUST', './uploads/{CUST_CODE}');
define('UPLOADS_CUST_INVOICE', './uploads/{CUST_CODE}/invoice');

define('UPLOADS_CUST_DOC', './uploads/{CUST_CODE}/docs');
define('UPLOADS_CUST_INV_DONE', './uploads/{CUST_CODE}/invoice_done');
define('UPLOADS_CUST_INV_ERROR', './uploads/{CUST_CODE}/invoice_error');
define('SUBSIDIARY_LIMIT', 40);
 
if(EMAIL_ENVIRONMENT=='production'){ 
	#DEFINED IN INDEX.PHP
	define('SMTP_HOST', 'smtp.gmail.com');
	define('SMTP_PORT', 465);
	define('SMTP_USER', 'iobvendorfinance@gmail.com');
	define('SMTP_PASS', 'icmindia1.');
	define('FROM_EMAIL_ID', 'iobvendorfinance@gmail.com');
	define('FROM_EMAILR_NAME', 'IOB VF');
	define('EMAIL_BCC', 'pravinkumar@icmindia.com');
	define('TEMP_TO_EMAIL', 'mpravinphp@gmail.com');
	define('SITE_NAME', 'IOB VF');
	define('ERROR_NOTIFICATION_EMAIL','sreeja@icmindia.com');
}else if(EMAIL_ENVIRONMENT=='testing'){
	#DEFINED IN INDEX.PHP
	define('SMTP_HOST', 'smtp.gmail.com');
	define('SMTP_PORT', 465);
	define('SMTP_USER', 'iobvendorfinance@gmail.com');
	define('SMTP_PASS', 'icmindia1.');
	define('FROM_EMAIL_ID', 'iobvendorfinance@gmail.com');
	define('FROM_EMAILR_NAME', 'IOB VF');
	define('EMAIL_BCC', 'pravinkumar@icmindia.com');
	define('TEMP_TO_EMAIL', 'mpravinphp@gmail.com');
	define('SITE_NAME', 'IOB VF');
	define('ERROR_NOTIFICATION_EMAIL','sreeja@icmindia.com');	
}else {
	#DEFINED IN INDEX.PHP
	define('SMTP_HOST', 'smtp.gmail.com');
	define('SMTP_PORT', 465);
	define('SMTP_USER', 'iobvendorfinance@gmail.com');
	define('SMTP_PASS', 'icmindia1.');
	define('FROM_EMAIL_ID', 'iobvendorfinance@gmail.com');
	define('FROM_EMAILR_NAME', 'IOB VF');
	define('EMAIL_BCC', 'pravinkumar@icmindia.com');
	define('TEMP_TO_EMAIL', 'mpravinphp@gmail.com');
	define('SITE_NAME', 'IOB VF');
	define('ERROR_NOTIFICATION_EMAIL','sreeja@icmindia.com');	
}
/* ERROR CODES */
	/*
	Error_code:1xx -> Dashboard
	Error_code:2xx -> Customer
	Error_code:3xx -> Vendors
	Error_code:4xx -> Invoice
	Error_code:5xx -> masterRates
	Error_code:6xx -> Replenishment	
	Error_code:7xx -> MailTemplate	
	Error_code:8xx -> Reports
	Error_code:9xx -> Other	

	Anxx - Admin portal
	Cnxx - Customer portal
	
	Eg: A1xx -> Admin Dashboard
	
	*/

/*  Error_code:1xx -> Dashboard */


/*  Error_code:2xx -> Customer */
define('ERROR_C202', 'Validation Failed');
define('ERROR_C203', 'Invalid email or password');
define('ERROR_C204', 'Email Address is not registered with us.');
define('ERROR_C205', 'Problem With Resetting password. Please try again.');
define('ERROR_C206', 'OTP is expired, Please try again');
define('ERROR_C207', 'OTP is invalid');
define('ERROR_C208', 'Password is not matching. Please try again.');
define('ERROR_C209', 'Document deleted successfully.');


define('INFO_C201', 'OTP is Sent to your Email');
define('INFO_C202', 'Password Changed Successfully..');
define('INFO_C203', 'OTP is resent to Registered Email Address');
define('INFO_C204', 'OTP is Sent to your Email Address');
define('INFO_C205', 'Account Details Updated Successfully.');
define('INFO_C206', 'Fund Added Successfully..');
define('INFO_C207', 'This Email Address is already exists');
define('INFO_C208', 'Customer details disabled successfully');
define('INFO_C209', 'Customer details updated successfully');
define('INFO_C210', 'Customer details added successfully');
define('INFO_C211', 'Customer {USER_NAME} disabled successfully');
define('INFO_C212', 'Customer {USER_NAME} enabled successfully');
/*  Error_code:1xx -> BankAdmin */
define('ERROR_A101', 'Invalid email or password');
define('ERROR_A102', 'Interest rate should be less than 100');
define('ERROR_A103', 'This code is already used by another customer please select another one');
define('ERROR_A104', 'This code is not exists');
define('ERROR_A105', 'This Email Address is already used by another customer please select another one');
define('ERROR_A106', 'To Date cannot be lesser than From date.');
define('INFO_A101', 'Site settings updated successfully');
define('INFO_A102', 'User {USER_NAME} updated successfully');
define('INFO_A103', 'User details added successfully');
define('INFO_A104', 'User {USER_NAME} deleted successfully');
define('INFO_A105', 'User {USER_NAME} disabled successfully');
define('INFO_A106', 'User {USER_NAME} enabled successfully');


/*  Error_code:3xx -> Vendors */
define('INFO_A301', 'Vendor details deleted successfully');
define('INFO_A302', 'Vendor details imported successfully');
define('INFO_A303',  'Vendor details {STATUS_TEXT} successfully');
define('INFO_A304',  'Invoice updated for vendors');
define('ERROR_A301', 'This code is already used by another vendor please select another one');
define('ERROR_A302', '*Please choose an Excel file(.xls or .xlxs) as Input');
/*  Error_code:4xx -> Invoice */
define('ERROR_A401', 'Is Empty');
define('ERROR_A402', 'Not valid');
define('ERROR_A403', 'Invoice number duplicate found in csv. invoice number: {INVOICE_CODE}, vendor Code: {VENDOR_CODE}');
define('ERROR_A404', 'No customer found. customer code: {CUSTOMER_CODE}');
define('ERROR_A405', 'Same invoice found. invoice code: {CUSTOMER_CODE}, vendor Code: {VENDOR_CODE}');
define('ERROR_C406', '*Please choose a file as Input');
define('ERROR_C407', 'File Format not correct.');
define('ERROR_C408', 'Column Name missing.');
define('ERROR_C409', 'Column Names not correct.');
define('ERROR_C410', 'Upload Failed.');
define('ERROR_C411', 'No Valid Files Selected to Upload.');
define('ERROR_C412', 'Line Number {LINE_NUMBER} : Customer Not exist.');
define('ERROR_C413', 'Line Number {LINE_NUMBER} : Column count not matching.');
define('ERROR_C414', 'Line Number {LINE_NUMBER} : Cell value should not be empty.');
define('ERROR_C415', 'Line Number {LINE_NUMBER} : Column value should be either NET or GROSS.');
define('ERROR_C416', 'No invoice selected');
define('ERROR_C417', 'Invoice Number and Vendor code should be unique.');
define('ERROR_C418', 'Invalid Customer Code');
define('ERROR_C419', 'File Already Processed');
define('ERROR_C420', 'No Invoice elected to Upload.');
define('ERROR_C421', 'Line Number {LINE_NUMBER} : Vendor code not exist.');
define('INFO_C401', 'Invoice details deleted successfully');
define('INFO_C402', 'Invoice status updated for invoice');
define('INFO_C403', 'Approved Interest rate processed successfully');

define('INFO_C404', 'File uploaded successfully.');
define('INFO_C405', 'Transaction initiated successfully');
/* Error_code:5xx -> masterRates */
define('INFO_C501', 'Approved invoices payment processed successfully');
define('INFO_C502', 'Interest rate is added successfully');
define('INFO_C503', 'Customer Interest Rate Approved');
/* Error_code:6xx -> Replenishment	*/
define('INFO_A601', 'Replenishment details deleted successfully');
define('INFO_A602', 'Customer payment added successfully');

define('ERROR_A601', 'Something went wrong, User not matched');
/* Error_code:7xx -> MailTemplate	*/

define('INFO_A701', 'Mail Template deleted successfully');
define('INFO_A702', 'Mail Template added successfully');
define('ENC_KEY', 'IOBVFENCS001');
/* Error_code:8xx -> Reports	*/


/* Error_code:9xx -> Other	*/




