 <!--main content start-->
    <section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-upload"></i>  Upload Invoice Documents</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/invoices/"; ?>"><i class="fa fa-list"></i>Invoice Details</a></li>
							<li><i class="fa fa-upload"></i>Invoice Documents</li>
						</ol>
					</div>
				</div>
        <!-- page start-->
       <div class="box-body">
		<?php if($this->session->userdata('ac_success_message')!=''){ ?>
							<div class="alert alert-success alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('ac_success_message'); $this->session->set_userdata('ac_success_message',''); 
								?></small>
							</div>
							 <?php
							}?>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4  text-right">
					<label>Invoice Number:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php echo $invoice_data['invoice_number']; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Date:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php  echo date('d-m-Y h:i:s a',strtotime($invoice_data['invoice_date'])); ?></p>
				</div>
			</div>	
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Vendor Name:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php  echo $invoice_data['invoice_beneficiary_name']; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Beneficiary Ac/No:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php  echo $invoice_data['invoice_beneficiary_number']; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Amount:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php echo  $invoice_data['invoice_amount'] ; ?></p>
				</div>
			</div>
			<!--<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Net Amount:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php echo  $invoice_data['invoice_net'] ; ?></p>
				</div>
			</div>-->
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Deduction Days:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php echo  $invoice_data['invoice_deduction_days'] ; ?></p>
				</div>
			</div>		
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Status:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<p><?php echo  $invoice_data['invoice_status'] ; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Invoice Document:</label>
				</div>
				<div class="col-lg-8 col-sm-6 text-left">
					<?php
						$attr=array(
							'method'=>'post',
							'enctype'=>'multipart/form-data',
							'class'=>'form form-horizontal'
						);
						echo form_open(CUSTOMERBASEURL."customer/upload_documents/",$attr); ?>
						<div class="reset-field">
						<input onchange="show_clear_opt();" id="invoice_doc" type="file" name="documents[]" multiple="multiple" style="display:inline-block;"   /> 
						<span onclick="clear_me();" style="cursor:pointer;display:none" class="btn-warning btn-sm close-me"><i class="fa fa-times"></i> Clear</span>
						</div>
					<p class="text-muted"><small>*.JPG,PNG,PDF,DOC,DOCX,XLS,XLSX,CSV( Max File Size: <?php echo $max_file_size; ?>)</small></p>
					<p class="text-danger"><small><?php echo $this->session->userdata('error');  $this->session->set_userdata('error',''); ?></small></p>
					<input type="hidden" name="invoice_id" value="<?php echo $invoice_data['invoice_id']; ?>" /> 
					<input type="hidden" name="invoice_number" value="<?php echo $invoice_data['invoice_number']; ?>" /> 
					<input type="submit" value="Upload" class="btn btn-primary" />
					<?php echo form_close(); ?>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 text-right">
					&nbsp;
				</div>
			</div>
			<div class="row">
				<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
					<label>Uploaded Documents:</label>
				</div>
				<div class="col-lg-8 col-sm-8 text-left">
					<ol style="padding:0">
					 <?php 
						foreach($all_invoice_document as $invoice_doc){ 
							?>
							<li style="margin-bottom:10px;">
								<i class="fa fa-file"></i> <?php echo $invoice_doc['document_name']; ?>
								<a class="btn btn-warning btn-small" style="margin-right:10px;" href="<?php echo  CUSTOMERBASEURL."customer/download_myfiles/".$invoice_doc['rand_key'].'/'.$invoice_doc['id']; ?>" />    <i class="fa fa-download"></i> Download</a>
								<a onclick="return confirm('Are you sure to delete this document')" class="btn btn-warning"  href="<?php echo CUSTOMERBASEURL.'customer/remove_document/'.$invoice_doc['rand_key'].'/'.$invoice_doc['id']; ?>" />    <i class="fa fa-trash-o"></i> Delete</a>
							</li> 
							<?php 
							
						}
					
					?>
					</ol>					
				</div>
			</div>
               
	   </div>
        <!-- page end-->
	   </div>
      </section>
    </section>
    <!--main content end-->
	<script>
	function show_clear_opt(){
		if(!$('.close-me').is(":visible")){
			$('.close-me').css('display','inline-block');
		}
	}
	function clear_me(){
		var rep_var='<input onchange="show_clear_opt();" id="invoice_doc" type="file" name="documents[]" multiple="multiple" style="display:inline-block;"   /> <span onclick="clear_me();" style="cursor:pointer;display:none" class="btn-warning btn-sm close-me"><i class="fa fa-times"></i> Clear</span>';
		$('.reset-field').html('');
		$('.reset-field').html(rep_var);
	}
	</script>