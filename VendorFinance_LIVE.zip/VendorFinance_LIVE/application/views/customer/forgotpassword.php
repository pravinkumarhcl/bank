<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
  <title>Customer Forgot Password</title> 
<?php $this->load->view('customer/common/com-header.php'); ?>

 
</head>

<body class="login-img3-body">

  <div class="container">

    <form class="login-form" action="" method="post">
      <div class="login-wrap"> 
    <?php if($this->session->userdata('error_cust')!=""){?>
    <div class="alert alert-danger">
        <p><b>Error!</b> <?php echo $this->session->userdata('error_cust');$this->session->set_userdata('error_cust',''); ?></p>
    </div>
    <?php } ?>
        <p class="login-img"><i class="icon_lock_alt"></i></p>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" name="user_email" placeholder="Registered Email Address" >  
        </div>
		 <?php echo form_error("user_email"); ?> 
        <label class="checkbox"> 
                <span class="pull-left"> Enter your Registered Email Address</span>
		</label>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Send OTP</button>
		<a href="<?php echo ADMINBASEURL.'customer/login'; ?>" style="color:#fff !important" class="btn btn-info btn-lg btn-block" >Cancel</a>

         
      </div>
    </form>
    
  </div>


</body>

</html>
