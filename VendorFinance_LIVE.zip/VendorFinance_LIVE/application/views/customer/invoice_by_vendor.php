 <!--main content start-->
 

    <section id="main-content">
      <section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-list"></i>  "<b><?php echo $invoice_type; ?></b>" Invoices</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/vendor_payments/"; ?>"><i class="fa fa-money"></i>Vendor Payments</a></li>
							<li><i class="fa fa-file-text-o"></i><?php echo $invoice_type; ?> Invoices</li>
						</ol>
					</div>
				</div>
				<!-- page start-->
				<div class="box-body">
					<form class="form-inline" method="POST" action=""><!-- form-search -->
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value=""  name="filter_from" id="from_date" placeholder="From Date">
							</div>
						</div>	
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value="" name="filter_to" id="to_date" placeholder="To Date">
							</div>
						</div>	
						<div class="form-group">
							&nbsp;&nbsp;&nbsp;<button type="button" id="search" class="btn btn-primary">Submit</button>
							&nbsp;&nbsp;&nbsp;<a href=""   class="btn btn-primary">Reset</a>
						</div>	
					</form>
					
					<hr />
					<div class="table-responsive">
						<table class="table table-bordered" id="posts">
							<thead>
								<tr>
									<th class="text-center">Sl.No</th>
									<th class="text-center">Invoice Date</th>
									<th class="text-center">Invoice Number</th>
									<th class="text-center">Transaction Id</th>
									<th class="text-center">Vendor Name</th>
									<th class="text-center">Beneficiary Ac/No</th>
									<!--<th class="text-center">Beneficiary IFSC</th>-->
									<th class="text-center">Invoice Amount</th>
									<th class="text-center">Net / Gross</th>
									<th class="text-center">Discount Amount</th> 
									<th class="text-center">Paid/Due Amount</th>
									<th class="text-center">Deduction Days</th>
									<th class="text-center">Invoice Status</th>
									<th class="text-center">Action </th>
								</tr>
							</thead>
							
						</table>
					</div>
				</div>
				<!-- page end-->
			</div>
		</section>
    </section>
    <!--main content end-->
	
	 
  <script>
 
    $(document).ready(function () {
       datatable_appointments =  $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo CUSTOMERBASEURL; ?>customer/getInvoiceByVendorJson?vendor=<?php echo $vendor;?>",
		     "dataType": "json",
		     "type": "POST",
		    data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				},
				},
	    "columns": [
		         
						{ "data": "invoice_id", className: "center" },
						{ "data": "invoice_date", className: "center" },
						{ "data": "invoice_number", className: "left" },
						{ "data": "invoice_transactionid", className: "left" },
						{ "data": "invoice_beneficiary_name", className: "left" },
						{ "data": "invoice_beneficiary_number", className: "left" },
						{ "data": "invoice_amount", className: "right" },
						{ "data": "invoice_net", className: "center" },
						{ "data": "invoice_discount", className: "right" },
						{ "data": "invoice_topaid", className: "right" },
						{ "data": "invoice_deduction_days", className: "center" },
						{ "data": "invoice_status", className: "center" },
						{ "data": "actions", className: "center" },
		         
		       ]	 

	    });
		
	  $('#search').click(function(){		
		datatable_appointments.ajax.reload();		
	
		});
    });
	
</script> 