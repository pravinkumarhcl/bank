<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
  <title>Customer Login</title> 
<?php $this->load->view('customer/common/com-header.php'); ?>

 
</head>

<body class="login-img3-body">

  <div class="container">

    <form class="login-form" action="" method="post">
      <div class="login-wrap"> 
    <?php if($error_cust!=""){?>
    <div class="alert alert-danger">
        <p><b>Error!</b> <?php echo $error_cust; ?></p>
    </div>
    <?php } ?>
	<?php  if($this->session->userdata('success_cust')!=""){?>
    <div class="alert alert-success">
        <p><b>Success!</b> <?php echo $this->session->userdata('success_cust');$this->session->set_userdata('success_cust',''); ?></p>
    </div>
    <?php } ?>
        <p class="login-img"><i class="icon_lock_alt"></i></p>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" value='<?php echo (isset($_COOKIE["r_email_customer"])?$_COOKIE["r_email_customer"]:''); ?>'  name="user_email" placeholder="User name" >  
        </div>
		 <?php echo form_error("user_email"); ?>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" class="form-control" value='<?php echo (isset($_COOKIE["r_ep_customer"])?base64_decode($_COOKIE["r_ep_customer"]):''); ?>' name="password"  placeholder="Password"> 
        </div>
		  <?php echo form_error("password"); ?>
        <label class="checkbox">
                <input type="checkbox" name="rem_me" value="remember-me"> Remember me
                <span class="pull-right"> <a href="<?php echo CUSTOMERBASEURL.'customer/forgotpassword/' ?>"> Forgot Password?</a></span>
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
         
      </div>
    </form>
    
  </div>


</body>

</html>
