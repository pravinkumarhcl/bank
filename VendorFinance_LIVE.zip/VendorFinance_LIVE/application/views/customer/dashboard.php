<!-- container section start -->
<style>
.info-box i{
	width:50px!important;
}

</style>
<!------ Include the above in your HEAD tag ---------->
<style>

</style>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="dash_bg"><!---->
            <!--overview start-->
            <div class="row box_header">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-tachometer"></i> Dashboard</h3>
                    <ol class="breadcrumb">
                        <li><a href="" ><i class="fa fa-home"></i>Home</li></a>
                        <li><i class="fa fa-tachometer"></i>Dashboard</li>
                    </ol>
                </div>
            </div>
			
			<div class="dash-links">          
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="inforide">
						<a href="<?php echo CUSTOMERBASEURL.'customer/invoices/' ?>">
							<div class="">
								<div class="row">
									<div class="col-md-3 col-sm-4 col-xs-4 rideone blue-bg">
										<!--<i class="fa fa-file" style="font-size:50px;"></i>`-->
										<i class="fa fa-files-o" style="font-size:50px;"></i>
											<div class="count">
												<?php echo $total_invoices; ?>
											</div>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-8 fontsty row">
										<div class="title text-center">All Invoices</div>
										<hr class="u_line" />
										<i class="fa fa-rupee" style="font-size:40px;"></i>
											<div class="count">	
												<?php echo number_format($all_amount,2);?>
											</div>
									</div>
								</div>
							</div>	
						</a>
					</div>
				</div>
                    <!--/.info-box-->
                <!--/.col-->

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="inforide">
						<a href="<?php echo CUSTOMERBASEURL.'customer/invoices/Pending/' ?>">
							<div class="">
								<div class="row">
									<div class="col-md-3 col-sm-4 col-xs-4 rideone skyblue_bg">
										<i class="fa fa-file-text-o" style="font-size:50px;"></i>
											<div class="count">
												<?php echo $pending_invoices; ?>
											</div>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-8  fontsty row">
										<div class="title text-center">Pending Invoices</div>
										<hr class="u_line" />
										<i class="fa fa-rupee" style="font-size:40px;"></i>
											<div class="count">	
												<?php echo ($pending_amount)?number_format($pending_amount,2):'0.00';?>
											</div>
									</div>
								</div>
									
							</div>
						</a>
					</div>
                    <!--/.info-box-->
                </div>
                <!--/.col-->

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 ">
					<div class="inforide">
						<a href="<?php echo CUSTOMERBASEURL.'customer/invoices/Paid/' ?>">
							<div class="">
								<div class="row">
									<div class="col-md-3 col-sm-4 col-xs-4 rideone violet_bg">
										<i class="fa fa-file-text-o" style="font-size:50px;"></i>
											<div class="count">
												<?php echo $paid_invoices; ?>
											</div>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-8  fontsty row">
										<div class="title text-center">Paid Invoices</div>
										<hr class="u_line" />
										<i class="fa fa-rupee" style="font-size:40px;"></i>
											<div class="count">	
												<?php echo ($invoice_paid)?number_format($invoice_paid,2):'0.00' ;?>
											</div>
									</div>
								</div>
							</div>
						</a>
					</div>
                    <!--/.info-box-->
                </div>
                <!--/.col-->
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="inforide">
						<a href="<?php echo CUSTOMERBASEURL.'customer/replenishments_due/' ?>">
							<div class="">
								<div class="row">
									<div class="col-md-3 col-sm-4 col-xs-4 rideone litegreen_bg">
										<i class="fa fa-money" style="font-size:50px;"></i>
											<div class="count">
												<?php echo $Replenishments_due; ?>
											</div>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-8 fontsty row">									
										<div class="title text-center">Payable DUEs</div>
										<hr class="u_line" />
										<i class="fa fa-rupee" style="font-size:40px;"></i>
										<div class="count">	
											<?php echo ($Replenishments_amount)?number_format($Replenishments_amount,2):'0.00';?>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
                    <!--/.info-box-->
                </div>
                <!--/.col-->
				
				<?php $CustomerData=$this->session->userdata("CustomerData"); 
	 
	 
					$loan_balance  = filter_var($CustomerData['cust_current_loan_balance'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$replenished  = filter_var($CustomerData['cust_replenishment'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_balance =  $loan_balance+$replenished;

					$monthly_paid_loan  = filter_var($CustomerData['monthlyPainIvoice'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$cust_monthly_loan_limit  = filter_var($CustomerData['cust_monthly_loan_limit'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_month_balance =  $cust_monthly_loan_limit-$monthly_paid_loan;

					$weekly_paid_loan  = filter_var($CustomerData['weeklyPainIvoice'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$cust_weekly_loan_limit  = filter_var($CustomerData['cust_weekly_loan_limit'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_weekly_balance =  $cust_weekly_loan_limit-$weekly_paid_loan;
	 
				?>
				
					<div class="col-md-12 ">
						<div class="col-md-8 col-xs-12 ">
							<?php if($CustomerData['cust_type']=="parent"){ ?>
								<div class="row table-responsive">
									<table class="table table-bordered table-hover "> 
										<tbody>
											<tr>
												<td class="text-center bg_lite3" colspan="5"><b>Loan Limit Info</b></td>
											</tr>
											<tr>
												<td class="text-center bg_lite3"></td>
												<td class="text-center bg_lite3">WEEKLY</td>
												<td class="text-center bg_lite3">MONTHLY</td>
												<td class="text-center bg_lite3"><?php echo $CustomerData['cust_mclr']; ?> MCLR</td> 
											</tr> 
											<tr>
												<td class="text-center bg_lite3">LIMIT</td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_weekly_loan_limit']; ?></b></td>
												<td class=" bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_monthly_loan_limit']; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_limit']; ?></b></td> 
											</tr> 
											<tr>
												<td class="text-center bg_lite3">USED	</td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo ($CustomerData['weeklyPainIvoice']==""?'0.00':number_format($CustomerData['weeklyPainIvoice'],2)); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo ($CustomerData['monthlyPainIvoice']==''?'0.00':number_format($CustomerData['monthlyPainIvoice'],2)); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_used']; ?></b></td> 
											</tr> 
											<!-- <tr>
												<td class="text-center bg_lite3">USED SUB</td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_weeklyPainIvoice,2) ; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_monthlyPainIvoice,2) ; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_cust_loan_used,2) ; ?></b></td> 
											</tr> -->
											<tr>
												<td class="text-center bg_lite3">BALANCE</td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_weekly_balance-$sub_weeklyPainIvoice,2); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_month_balance-$sub_monthlyPainIvoice,2); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_balance-$sub_cust_loan_used,2); ?></b></td> 
											</tr> 
										</tbody>
									</table>
								</div>
								<?php }else{
									//print_r($CustomerData);
								?>
								<div class=" row table-responsive ">
									<table class="table table-bordered table-hover "> 
										<tbody>
											<tr>
												<td class="text-center bg_lite3" colspan="5"><b>Loan Limit Info</b></td>
											</tr>
											<tr>
												<td class="text-center bg_lite3"></td>
												<td class="text-center bg_lite3">WEEKLY</td>
												<td class="text-center bg_lite3">MONTHLY</td>
												<td class="text-center bg_lite3"><?php echo $CustomerData['cust_mclr']; ?> MCLR</td> 
											</tr> 
											<tr>
												<td class="text-center bg_lite3">LIMIT</td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_weekly_loan_limit']; ?></b></td>
												<td class=" bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_monthly_loan_limit']; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_limit']; ?></b></td> 
											</tr>
											<tr>
												<td class="text-center bg_lite3">USED SELF</td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo ($CustomerData['weeklyPainIvoice']==''?'0.00':number_format($CustomerData['weeklyPainIvoice'],2)); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  ($CustomerData['monthlyPainIvoice']==''?'0.00':number_format($CustomerData['monthlyPainIvoice'],2)); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_used']; ?></b></td> 
											</tr> 
											
											<tr>
												<td class="text-center bg_lite3">USED OTHERs</td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_weeklyPainIvoice,2) ; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_monthlyPainIvoice,2) ; ?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_cust_loan_used,2) ; ?></b></td> 
											</tr>
											
											<tr>
												<td class="text-center bg_lite3">USED BY MAIN</td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
												
													#LOGIC - from parent company limit if loan used amount crossed above 60% will show the crossed taken amount
													 
													$parent_treshold=str_replace(',','',$parent_loan_usage['cust_weekly_loan_limit'])- str_replace(',','',$CustomerData['cust_weekly_loan_limit']);
												  $weeklyPainIvoice_p=$parent_loan_usage['weeklyPainIvoice'];
												  if($weeklyPainIvoice_p>$parent_treshold){
														$weeklyPainIvoice_p_r=$weeklyPainIvoice_p-$parent_treshold;
													  echo  number_format($weeklyPainIvoice_p_r,2);
												  }else{
													  echo $weeklyPainIvoice_p_r="0.00";
												  }
												?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
													$parent_treshold_m=str_replace(',','',$parent_loan_usage['cust_monthly_loan_limit'])- str_replace(',','',$CustomerData['cust_monthly_loan_limit']);
												  $monthlyPainIvoice=$parent_loan_usage['monthlyPainIvoice'];
												  if($monthlyPainIvoice>$parent_treshold_m){
														$monthlyPainIvoice_r=$monthlyPainIvoice-$parent_treshold_m;
													  echo  number_format($monthlyPainIvoice_r,2);
												  }else{
													  echo $monthlyPainIvoice_r="0.00";
												  }

												?></b></td>
												<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
												$parent_treshold_t=str_replace(',','',$parent_loan_usage['cust_loan_limit'])- str_replace(',','',$CustomerData['cust_loan_limit']);
												  $cust_loan_used_t=$parent_loan_usage['cust_loan_used'];
												  if($cust_loan_used_t>$parent_treshold_t){
														$cust_loan_used_t_r=$cust_loan_used_t-$parent_treshold_t;
													  echo number_format($cust_loan_used_t_r,2);
												  }else{
													  echo $cust_loan_used_t_r="0.00";
												  }

												?></b></td> 
											</tr>
											
											<tr>										
												<td class="text-center bg_lite3">BALANCE</td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
												 
												echo number_format(($total_weekly_balance-$sub_weeklyPainIvoice)-$weeklyPainIvoice_p_r,2); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
												echo  number_format(($total_month_balance-$sub_monthlyPainIvoice)-$monthlyPainIvoice_r,2); ?></b></td>
												<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
												echo  number_format(($total_balance-$sub_cust_loan_used)-$cust_loan_used_t_r,2); ?></b></td> 
											</tr> 
										</tbody>
									</table>
								</div>
								<?php
							} ?> 
						</div>
						
						<div class="col-md-4 col-xs-12">
							<div class=" row table-responsive">
								<table class="table table-bordered table-hover "> 
									<tbody>
										<tr>
											<td class="text-center bg_lite4" colspan="3"><b>Payable Due</b></td>
										</tr>
										<tr>
											<td class="text-center bg_lite4">Date</td>
											<td class="text-center bg_lite4">Amount</td>
											<td class="text-center bg_lite4">Rem Days</td>
										</tr>
										
										<?php foreach($receivableData as $dueData) { ?>
										<tr>
											<td class="text-center bg_lite4"><?php echo $dueData['date']; ?></td>
											<td class="text-right bg_lite4"><b><i class="fa fa-inr"></i> <?php echo number_format($dueData['amount'],2); ?></b></td>
											<td class="text-center bg_lite4"><b><?php echo $dueData['RemDays']; ?></td>
										</tr>										
										<?php } 										
										if(count($receivableData)==1)
										{
										?>										
										
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<?php } 
										if(count($receivableData)<=0)
										{
										?>										
										
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">No records found</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<!-- <tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr> -->
										<?php } 
										if(count($receivableData)>0)
										{
										?>
										
										<?php if($CustomerData['cust_type']!="parent"){ ?>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<?php } ?>
										<tr>
											<td class="text-center bg_lite4" colspan="3" style="padding:6px"><b><a href="<?=ADMINBASEURL;?>customer/replenishments_due" class="btn btn-xs btn-primary ">Show More</a></b></td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				
				</div>
			<div class="clearfix"></div>
		</div>
		<div class="dashboard_cover_rep_due row">
			<?php echo $data_rep_due; ?>
		</div>
    </section>

</section>