	<!--main content start-->
	<section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-money"></i> Fund Flow</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-bars"></i>Accounts</a></li>
							<li><i class="fa fa-money"></i>Fund Flow</li>
						</ol>
					</div>
				</div>
				 <div id="alert_message">
				
			</div>	
				<!-- page start-->
				<div class="box-body"> 
					<div class="tab-pane <?php echo ($ac_active!=''?$ac_active:''); ?>" id="tab_2"> 
						<form class="form-inline" method="POST" action=""><!-- form-search-->
							<div class="form-group">
								<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
								<div class="col-sm-8">
									<input type="text" required class="form-control" value="<?php echo ($filter_from!=''?date('d-m-Y',strtotime($filter_from)):''); ?>"  name="filter_from" id="from_date" placeholder="From Date">
								</div>
							</div>	
							<div class="form-group">
								<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
								<div class="col-sm-8">
									<input type="text" required class="form-control" value="<?php echo ($filter_to!=''?date('d-m-Y',strtotime($filter_to)):''); ?>" name="filter_to" id="to_date" placeholder="To Date">
								</div>
							</div>	
							<div class="form-group">
								&nbsp;&nbsp;&nbsp;<button type="button" id="search" class="btn btn-primary">Submit</button>
								&nbsp;&nbsp;&nbsp;<a href=""   class="btn btn-primary">Reset</a>
							</div>	
						</form>
						
						<hr />
				
						<div class="row cust-form-group">
							<div class="col-lg-12 text-right">
								<label class="avail-loan-amount">Opening Balance</label>
								<p class="avail-loan-amount"><span class="label label-success"><i class="fa fa-rupee"></i> <?php echo number_format($resul_customer['cust_loan_limit'],2); ?></span></p>
							</div> 
						</div>
						<div class="table-responsive">
						 <table class="table table-bordered" id="posts">
							<thead>
								<tr>
									<th class="text-center">Sl.No</th>
									<th class="text-center">Date</th>
									<th class="text-center">Invoice(s) Processed</th>
									<th class="text-center ">Debited</th>
									<th class="text-center ">Credited</th>
									<th class="text-center">Closing Balance</th>
									<th class="text-center">Action</th> 
								</tr>
							</thead>
							
						</table>	
						</div>
					</div>
				</div>
				<!-- page end-->
			</div>
		</section>
    </section>
    <!--main content end-->
	<script>
	function show_table_custom(){
		 $('.dataTables_scrollHeadInner').css('width','100%');
		 $('.dataTables_scrollHeadInner table').css('width','100%');
	}
	</script>
	
	 
  <script>
 
    $(document).ready(function () {
         datatable_appointments =  $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo CUSTOMERBASEURL; ?>customer/getFundsJSon",
		     "dataType": "json",
		     "type": "POST",
		   
		    data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				},
				},
	    "columns": [
		         
					{ "data": "id", className: "center" },
					{ "data": "date", className: "center" },
					{ "data": "invoive_processed", className: "center" },
					{ "data": "debited", className: "right" },
					{ "data": "credited", className: "right" },
					{ "data": "closing_balance", className: "right" },
					{ "data": "actions", className: "center" },
		       ]	 

	    });
		  $('#search').click(function(){
		var baseurl = "<?php echo CUSTOMERBASEURL; ?>";				  
		var filter_from = $("#from_date").val();
		var filter_to = $("#to_date").val();
		
    $.ajax({
				method:'POST',
				data:{'filter_from':filter_from,'filter_to':filter_to},
				url: baseurl+'customer/validateDates',
				success:function(data){						
					var json = $.parseJSON(data);		
					
					if(json['message']=='0')
					{
					
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
						$("#alert_message").html(data_show);
					}
					else{
					$("#alert_message").html("");

					}					
					datatable_appointments.ajax.reload();				

					
				}
			});	
	
		});
	 
    });
	
</script> 