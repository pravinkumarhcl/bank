	<!--main content start-->
	<section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-money"></i> Payable DUE</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><i class="fa fa-bars"></i>Accounts</li>
							<li><i class="fa fa-money"></i>Payable DUE</li>
						</ol>
					</div>
				</div>
				<!-- page start-->
				<div class="box-body"> 
					<div class="tab-pane <?php echo ($ac_active!=''?$ac_active:''); ?>" id="tab_2"> 
						<form class="form-inline hidden" method="POST" action=""><!-- form-search-->
							<div class="form-group">
								<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
								<div class="col-sm-8">
									<input type="text" required class="form-control" value="<?php echo ($filter_from!=''?date('d-m-Y',strtotime($filter_from)):''); ?>"  name="filter_from" id="from_date" placeholder="From Date">
								</div>
							</div>	
							<div class="form-group">
								<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
								<div class="col-sm-8">
									<input type="text" required class="form-control" value="<?php echo ($filter_to!=''?date('d-m-Y',strtotime($filter_to)):''); ?>" name="filter_to" id="to_date" placeholder="To Date">
								</div>
							</div>	
							<div class="form-group">
								&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary">Submit</button>
								&nbsp;&nbsp;&nbsp;<a href=""   class="btn btn-primary">Reset</a>
							</div>	
						</form> 
						<form onsubmit="return check_box_selected();" class="form-inline" method="POST" action=""><!-- form-search-->
				 	<div class="row cust-form-group">
							<div class="col-lg-12 text-right">
								<button type="button" id="submit_remark" class="btn btn-primary">Mark as Paid</label>
								 
							</div> 
						</div>
						
						<div class="table-responsive">
						 <table class="table table-bordered" id="posts">
							<thead>
								<tr>
									<th class="text-center">Sl.No</th>
									<th class="text-center">Vendor Code</th>
									<th class="text-center">Invoice Amount</th>
									<th class="text-center">Type</th>
									<th class="text-center">Rate</th>
									<th class="text-center">Days</th>
									<th class="text-center">Payment Date</th>
									<th class="text-center">Paid Amount</th> 
									<th class="text-center">Interest</th> 
									<th class="text-center">Due Date</th> 
									<th class="text-center">Due Amount</th> 
									<th class="text-center">Status</th> 
									<th class="text-center">Remarks</th> 
									<th class="text-center">Action</th> 
								</tr>
							</thead>
							
						</table>	
						</div>
						<input type="hidden" name="customer_remark" id="customer_remark" />
						</form>
					</div>
				</div>
				<!-- page end-->
			</div>
		</section>
    </section>
    <!--main content end-->
	<script> 
	function check_box_selected(){
		var is_selected=false;
		 $('input[name="mark_as_paid[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				 is_selected=true;
			 } 
			
		 })
		 if(!is_selected){
			 alert('Please select atleast one checkbox');
		 }else{
			 var prompted=prompt('Please Enter the Remarks.');
			 if(!prompted){
				 return false;
			 }
			 $('#customer_remark').val(prompted);
			 datatable_appointments.ajax.reload();	
		 }
		  return is_selected;
	}
	</script>
	
	<script>
 
    $(document).ready(function () {
         datatable_appointments =  $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo CUSTOMERBASEURL; ?>customer/getReplenishmentDueJson",
		     "dataType": "json",
		     "type": "POST",
		      data: function ( d ) {
					d.mark_as_paid = $('input[name="mark_as_paid[]"]').val();
					d.customer_remark = $("#customer_remark").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				},
				},
				
	    "columns": [
		         
					{ "data": "invoice_id", className: "center" },
					{ "data": "vendor_code", className: "center"},
					{ "data": "invoice_amount", className: "right" },
					{ "data": "invoice_net", className: "center" },
					{ "data": "interest_rate", className: "center" },
					{ "data": "invoice_deduction_days", className: "center" },
					{ "data": "payment_datetime", className: "center" },
					{ "data": "invoice_topaid", className: "right" },
					{ "data": "gross_amount", className: "right" },
					{ "data": "due_date", className: "center" },
					{ "data": "due_amount", className: "right" },
					{ "data": "status", className: "center" },
					{ "data": "remark", className: "left" },
				    { "data": "actions", className: "center" },
					
		       ]	 

	    });
		  $('#search').click(function(){		
		datatable_appointments.ajax.reload();		
	
		});
		$('#submit_remark').click(function(){
				var is_selected=false;
				$('input[name="mark_as_paid[]"]').each(function(t){ 
				if($(this).prop('checked')){
				is_selected=true;
				} 

				})
				if(!is_selected){
				alert('Please select atleast one checkbox');
				}else{
				var prompted=prompt('Please Enter the Remarks.');
				if(!prompted){
				return false;
				}
				 $('#customer_remark').val(prompted);
				datatable_appointments.ajax.reload();	
				}

			
		});
	 
    });
	
</script> 