 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-list"></i>  <?php echo $invoice_type; ?> Payments</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/vendor_payments/"; ?>"><i class="fa fa-money"></i>Transactions</a></li>
							<li><i class="fa fa-square-o"></i><?php echo $invoice_type; ?> Payments</li>
						</ol>
					</div>
				</div>
				
				 <div id="alert_message">
				
			</div>	
				<!-- page start-->
				<div class="box-body">
					<form class="form-inline" method="POST" action=""><!-- form-search-->
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value="<?php echo ($filter_from!=''?date('d-m-Y',strtotime($filter_from)):''); ?>"  name="filter_from" id="from_date" placeholder="From Date">
							</div>
						</div>	
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value="<?php echo ($filter_to!=''?date('d-m-Y',strtotime($filter_to)):''); ?>" name="filter_to" id="to_date" placeholder="To Date">
							</div>
						</div>	
						<div class="form-group">
							&nbsp;&nbsp;&nbsp;<button type="button" id="search" class="btn btn-primary">Submit</button>
							&nbsp;&nbsp;&nbsp;<a href=""   class="btn btn-primary">Reset</a>
						</div>	
					</form>
					<hr />
					<div class="table-responsive">
						<table class="table table-bordered" id="posts">
							<thead>
								<tr>
									<th class="text-center">Sl.No</th> 
									<th class="text-center">Vendor Name</th> 
									<th class="text-center">No.Of Invoices</th> 
									<th class="text-center">Total Invoice Amount</th>
									<th class="text-center">Net Discount</th>  
									<th class="text-center">Net Paid</th>  
									<th class="text-center">Payment date</th>
								<!--	<th class="text-center hidden">Gross Settled</th>  
									<th class="text-center hidden">Balance Due</th>  -->
									<th class="text-center">Action </th>
								</tr>
							</thead>
							
						</table>
					</div>
				</div>
				<!-- page end-->
			</div>
		</section>
	</section>
    <!--main content end-->
	
	 <script>
 
    $(document).ready(function () {
      datatable_appointments =  $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo CUSTOMERBASEURL; ?>customer/getVendorPaymentsJson",
		     "dataType": "json",
		     "type": "POST",
			 
		      data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();		
					d.type = $("#type").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				},
		                   },
	    "columns": [
		         
					{ "data": "invoice_id", className: "center" },
					{ "data": "invoice_beneficiary_name", className: "left" },
					{ "data": "total_invoice", className: "center" },
					{ "data": "totl_amount", className: "right" },
					{ "data": "invoice_discount", className: "right" },
					{ "data": "invoice_topaid", className: "right" },
					{ "data": "payment_datetime", className: "center" },
					{ "data": "actions", className: "center" },
					
		       ]	 

	    });
		
	 $('#search').click(function(){		
	var baseurl = "<?php echo CUSTOMERBASEURL; ?>";	
		var filter_from = $("#from_date").val();
		var filter_to = $("#to_date").val();
		
$.ajax({
	
				method:'POST',
				data:{'filter_from':filter_from,'filter_to':filter_to},
				url: baseurl+'customer/validateDates',
				success:function(data){						
					var json = $.parseJSON(data);		
				
					if(json['message']=='0')
					{
					
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
						$("#alert_message").html(data_show);
					}
					else{
					$("#alert_message").html("");

					}					
					datatable_appointments.ajax.reload();				

					
				}
			});	
	
		});
		
    });
	
</script> 
