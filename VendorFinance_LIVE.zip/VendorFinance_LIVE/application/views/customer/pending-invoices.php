 <style>
 .file-up{
	 margin:10px;
 }
 </style>
 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">		
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-list"></i>  <?php echo ($invoice_type==""?"All":$invoice_type); ?> Invoices</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i>Home</a></li>
							<li><i class="fa fa-list"></i>Invoice Details</li>
							<li><i class="fa fa-file-text-o"></i><?php echo $invoice_type; ?> Invoices</li>
						</ol>
					</div>
				</div>
				            
             <div id="alert_message">
				
			</div>	
				<!-- page start-->
				<div class="box-body">
				<?php if($this->session->userdata('ac_success_message')!=''){ ?>
							<div class="alert alert-success alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('ac_success_message'); $this->session->set_userdata('ac_success_message',''); 
								?></small>
							</div>
							 <?php
							}?>
							<?php if($this->session->userdata('error')!=''){ ?>
							<div class="alert alert-warning alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('error'); $this->session->set_userdata('error',''); 
								?></small>
							</div>
							 <?php
							}?>
					<form class="form-inline" method="POST" action=""> <!-- form-search -->
						<?php if($file_upload=='yes'){ ?>
						<a href="<?php echo CUSTOMERBASEURL."customer/invoices"; ?>" class="btn btn-success">Back</a>
						<?php }else{ ?> 
						<a href="<?php echo CUSTOMERBASEURL."customer/invoices?m=yes"; ?>" class="btn btn-success">Multi-File Upload</a>
						<?php } ?>
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value="<?php echo ($filter_from!=''?date('d-m-Y',strtotime($filter_from)):''); ?>"  name="filter_from" id="from_date" placeholder="From Date">
							</div>
						</div>	
						<div class="form-group">
							<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
							<div class="col-sm-8">
								<input type="text" required class="form-control" value="<?php echo ($filter_to!=''?date('d-m-Y',strtotime($filter_to)):''); ?>" name="filter_to" id="to_date" placeholder="To Date">
							</div>
						</div>	
						<div class="form-group">
							&nbsp;&nbsp;&nbsp;<button type="button"  id="search" class="btn btn-primary">Submit</button>
							&nbsp;&nbsp;&nbsp;<a href=""   class="btn btn-primary">Reset</a>
						</div>	
						
						<div class="form-group pull-right">
						<!--<select id="type" onchange="load_invoices(this);" class="form-control select-status"> -->
							 <select id="type"  class="form-control select-status">
							 <option value="">All Invoices</option>
							 <option value="Pending">Pending Invoices</option>
							 <option value="Verified">Verified Invoices</option>
							 <option value="Approved">Approved Invoices</option>
							 <option value="Rejected">Rejected Invoices</option>
							 <option value="Paid">Paid Invoices</option>
							 <option value="Documents">Pending Documents</option>
							 </select>
						</div>
						
					</form>
					<hr />
					<div class="table-responsive">
					<?php if($file_upload=='yes'){ ?>
					<form action="<?php echo CUSTOMERBASEURL."customer/upload_multi_documents/"; ?>" method="post" enctype="multipart/form-data" class="form form-horizontal" accept-charset="utf-8">
					<?php } ?>
						<table class="table table-bordered" id="posts">
							<thead>
								<tr>
									<?php if($file_upload=='yes'){ ?>
									<th class="text-center">Select Upload</th>
									<?php }else{ ?> 
									<th class="text-center">S.No</th>
									<?php } ?>
									<th class="text-center">Invoice Date</th>
									<th class="text-center">Invoice Number</th>
									<th class="text-center">Transaction Id</th>
									<th class="text-center">Vendor Name</th>								
									<th class="text-center">Invoice Amount</th>									
									<th class="text-center">Discount Amount</th> 
									<th class="text-center">Amount to be paid</th>
									<?php if($file_upload!='yes'){ ?>
									<th class="text-center">Deduction Days</th>
									<?php } ?>
									
									<th class="text-center">Status</th>
									<?php if($file_upload!='yes'){ ?>
									<th class="text-center">Reason</th>
									<th class="text-center">Documents</th>
									<th class="text-center">Action </th>
									<?php } ?>
								</tr>
							</thead>
						
						</table>
						<?php if($file_upload=='yes'){ ?>
							<div class="row">
							<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
								<label>Invoice Document:</label>
							</div>
							<div class="col-lg-8 col-sm-6 text-left">
								
									<div class="reset-field">
									<input onchange="show_clear_opt();" id="invoice_doc" type="file" name="documents[]" multiple="multiple" style="display:inline-block;"   /> 
									<span onclick="clear_me();" style="cursor:pointer;display:none" class="btn-warning btn-sm close-me"><i class="fa fa-times"></i> Clear</span>
									</div>
								<p class="text-muted"><small>*.JPG,PNG,PDF,DOC,DOCX,XLS,XLSX,CSV( Max File Size: <?php echo $max_file_size; ?>)</small></p>
								<p class="text-danger"><small><?php echo $this->session->userdata('error');  $this->session->set_userdata('error',''); ?></small></p>							
								<input type="submit" value="Upload" class="btn btn-primary" />
								<?php echo form_close(); ?>
							</div>
							</div>
						<?php } ?>
						</form>
					</div>
				</div>
				<!-- page end-->
			</div>
		</section>
	</section>
    <!--main content end-->
		  
	
	 <script>
    $(document).ready(function () {
      datatable_appointments =  $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo CUSTOMERBASEURL; ?>customer/getInvoiceJson",
		     "dataType": "json",
		     "type": "POST",
			 
		      data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();		
					d.file_upload = '<?php echo $file_upload; ?>';		
					d.type = $("#type").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				},
		                   },
	    "columns": [
		         
					{ "data": "sl_no", className: "center" },
					{ "data": "invoice_date", className: "center" },
					{ "data": "invoice_number", className: "left" },
					{ "data": "invoice_transactionid", className: "left" },
					{ "data": "invoice_beneficiary_name", className: "left" },
					{ "data": "invoice_amount", className: "right" },
					{ "data": "invoice_discount", className: "right" },
					{ "data": "invoice_topaid", className: "right" },
					<?php if($file_upload!='yes'){ ?>
					{ "data": "invoice_deduction_days", className: "center" },
					<?php } ?>
					{ "data": "invoice_status", className: "center" },
					<?php if($file_upload!='yes'){ ?>
					{ "data": "reject_reason", className: "center" },
					{ "data": "documents", className: "center" },
					{ "data": "actions", className: "center" },
					<?php } ?>
		       ]	 

	    });
		
	 $('#search').click(function(){	

	var filter_from = $("#from_date").val();
	var filter_to = $("#to_date").val();
	var baseurl = "<?php echo CUSTOMERBASEURL; ?>";
$.ajax({

				method:'POST',
				data:{'filter_from':filter_from,'filter_to':filter_to},
				url: baseurl+'customer/validateDates',
				success:function(data){	
				
					var json = $.parseJSON(data);		
					
					if(json['message']=='0')
					{
					
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
						$("#alert_message").html(data_show);
					}
					else{
					$("#alert_message").html("");

					}					
					datatable_appointments.ajax.reload();				

					
				}
			});		
	
		});
		 $('#type').click(function(){		
		datatable_appointments.ajax.reload();		
	
		});
    });
	function show_clear_opt(){
		if(!$('.close-me').is(":visible")){
			$('.close-me').css('display','inline-block');
		}
	}
	function clear_me(){
		var rep_var='<input onchange="show_clear_opt();" id="invoice_doc" type="file" name="documents[]" multiple="multiple" style="display:inline-block;"   /> <span onclick="clear_me();" style="cursor:pointer;display:none" class="btn-warning btn-sm close-me"><i class="fa fa-times"></i> Clear</span>';
		$('.reset-field').html('');
		$('.reset-field').html(rep_var);
	}
</script> 