<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Forgot Password</title>
    <?php $this->load->view('customer/common/com-header.php'); ?>

</head>

<body class="login-img3-body">

    <div class="container">

        <form class="login-form" action="" method="post">
            <div class="login-wrap">
                <?php if($this->session->userdata('error_cust')!=""){?>
				<div class="alert alert-danger">
					<p><b>Error!</b>
						<?php echo $this->session->userdata('error_cust');$this->session->set_userdata('error_cust',''); ?>
					</p>
				</div>
				<?php } ?>
				<?php  if($this->session->userdata('success_cust')!=""){?>
				<div class="alert alert-success">
					<p><b>Success!</b>
						<?php echo $this->session->userdata('success_cust');$this->session->set_userdata('success_cust',''); ?>
					</p>
				</div>
				<?php } ?>
				<p class="login-img"><i class="icon_lock_alt"></i></p>
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-key"></i></span>
					<input type="text" class="form-control" name="user_otp" placeholder="Enter Received OTP">
				</div>
				<?php echo form_error("user_otp"); ?>
				<label class="checkbox">
					<span class="pull-left">Didn't Receive? <a href="<?php echo CUSTOMERBASEURL.'customer/resend_otp/'.$salt; ?>">Resend OTP</a></span>
				</label>
				<button class="btn btn-primary btn-lg btn-block" type="submit">Verify</button>
				<a href="<?php echo CUSTOMERBASEURL.'customer/login'; ?>" style="color:#fff !important" class="btn btn-info btn-lg btn-block">Cancel</a>

            </div>
        </form>

    </div>

</body>

</html>