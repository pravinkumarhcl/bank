 <!--main content start-->
    <section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="fa fa-user"></i> My Profile</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"></i><i class="fa fa-home"></i>Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"></i><i class="fa fa-bars"></i> Accounts</a></li>
							<li><i class="fa fa-user"></i>My Profile</li>
						</ol>
					</div>
				</div>
				<!-- page start-->
				<div class="box-body"> 
					<ul class="nav nav-tabs">
						<li class="<?php echo ($basic_active!=''?$basic_active:''); ?>"><a href="#tab_1" data-toggle="tab" aria-expanded="true">General Details</a></li>
						<li class="<?php echo ($ac_active!=''?$ac_active:''); ?>"><a href="#tab_2" data-toggle="tab" aria-expanded="false">Change Password</a></li>
						<li class=""><a href="#tab_3" data-toggle="tab" aria-expanded="false">Loan Details</a></li>	
					</ul>
					
					
					
					<div class="tab-content customer-profile-view">
						<div class="tab-pane <?php echo ($basic_active!=''?$basic_active:''); ?>" id="tab_1">
							<?php if($this->session->userdata('ac_success_message')!=''){ ?>
							<div class="alert alert-success alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('ac_success_message'); $this->session->set_userdata('ac_success_message',''); 
								?></small>
							</div>
							 <?php
							}
								$form_attr=array(
								'name'=>'customer_basic_form', 
								'class'=>'customer_basic_form', 
							);	
							echo form_open(CUSTOMERBASEURL.'customer/myprofile',$form_attr); ?>
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Code: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								<?php 
									$param_arr=array(
										'class'=>'form-control',
										'id'=>'cust_code',
										'placeholder'=>'Customer Code',
										'readonly'=>'readonly',
										);
										$name_val=(isset($_POST['cust_user_code'])?set_value('cust_user_code'):$resul_customer['cust_user_code']);
									echo form_input('cust_code',$name_val,$param_arr);
									echo  form_error("cust_code");
									?> 

								</div>
							</div>
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Name: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								<?php 
									$param_arr=array(
										'class'=>'form-control',
										'id'=>'name',
										'placeholder'=>'Name',
										);
										$name_val=(isset($_POST['name'])?set_value('name'):$resul_customer['cust_name']);
									echo form_input('name',$name_val,$param_arr);
									echo  form_error("name");
									?> 

								</div>
							</div>
							
							
							<div class="row cust-form-group hidden">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Company Name: </label>
									</div>
									<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'company',
											'placeholder'=>'Company Name',
										);	
										$company_val=(isset($_POST['company'])?set_value('company'):$resul_customer['cust_company_name']);
										echo form_input('company',$company_val,$param_arr); 
										echo  form_error("company");
									?> 
								</div>
							</div>	
			
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Address 1: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'address_1',
											'placeholder'=>'Address 1',
										);
										
										$address_1_val=(isset($_POST['address_1'])?set_value('address_1'):$resul_customer['cust_address1']);
										echo form_input('address_1',$address_1_val,$param_arr);
										echo  form_error("address_1");
									?> 
								</div>
							</div>
			
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Address 2: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'address_2',
											'placeholder'=>'Address 2',
											);
										$address_1_val=(isset($_POST['address_2'])?set_value('address_2'):$resul_customer['cust_address2']);
										echo form_input('address_2',$address_1_val,$param_arr);
										echo  form_error("address_2");
									?>
								</div>
							</div>
			
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>City: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'city',
											'placeholder'=>'City',
											);
										$city_val=(isset($_POST['city'])?set_value('city'):$resul_customer['cust_city']); 								
										echo form_input('city',$city_val,$param_arr);
										echo  form_error("city");
									?>
								</div>
							</div>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>State: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'state',
											'placeholder'=>'State',
											);
											$state_val=(isset($_POST['state'])?set_value('state'):$resul_customer['cust_state']); 			
										echo form_input('state',$state_val,$param_arr); 
										echo  form_error("state");
									?>
								</div>
							</div>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Phone Number: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'phone_number',
											'placeholder'=>'Phone Number',
											);
										$phone_number_val=(isset($_POST['phone_number'])?set_value('phone_number'):$resul_customer['cust_phone']); 	 
										echo form_input('phone_number',$phone_number_val,$param_arr); 
										echo  form_error("phone_number");
									?>
								</div>
							</div>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Account Number: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'cust_account_no',
											'placeholder'=>'Account Number',
											);
										$phone_number_val=(isset($_POST['cust_account_no'])?set_value('cust_account_no'):$resul_customer['cust_account_no']); 	 
										echo form_input('cust_account_no',$phone_number_val,$param_arr); 
										echo  form_error("cust_account_no");
									?>
								</div>
							</div>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>IFSC Code: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'cust_ifsc_code',
											'placeholder'=>'IFSC Code',
											);
										$phone_number_val=(isset($_POST['cust_ifsc_code'])?set_value('cust_ifsc_code'):$resul_customer['cust_ifsc_code']); 	 
										echo form_input('cust_ifsc_code',$phone_number_val,$param_arr); 
										echo  form_error("cust_ifsc_code");
									?>
								</div>
							</div>
							
							<div class="row cust-form-group">
								<div class="col-lg-11 text-center">
									<button type="submit"   class="btn btn-success"><i class="fa fa-save"></i> Update</button>
									<a href="<?php echo CUSTOMERBASEURL.'customer/index/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>

								</div>
							</div>
							
							<?php echo form_close(); ?>
						</div>
						
						
						<div class="tab-pane <?php echo ($ac_active!=''?$ac_active:''); ?>" id="tab_2">
							<?php if($this->session->userdata('ac_info_message')!='' && $otp_mode==''){ ?>
							<div class="alert alert-info alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('ac_info_message') ;	  $this->session->set_userdata('ac_info_message','');
								?></small>
							</div>
				
							<?php
								}
							$form_attr=array(
							'name'=>'customer_account_form', 
							'class'=>'customer_account_form', 
							
							);
							if($otp_mode!=''){
								$form_attr['class']='customer_account_form hidden';
							}
							echo form_open(CUSTOMERBASEURL.'customer/myprofile',$form_attr); ?>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Email Address: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'email',
											'placeholder'=>'Email Address',
											'readonly'=>'readonly',
											);
											$name_val=(isset($_POST['email'])?set_value('email'):$resul_customer['cust_email']);
										echo form_input('email',$name_val,$param_arr);
										echo  form_error("email");
									?>
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Current Password: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								  <?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'password',
											'placeholder'=>'Password',
											);
											
											$company_val=(isset($_POST['password'])?'':'');

										echo form_password('password',$company_val,$param_arr); 
										echo  form_error("password");
									?>
								</div>
							</div>	
				 
				
							<!--div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Confirm Password: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								  <?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'cpassword',
											'placeholder'=>'Confirm Password',
											);
											
											$company_val=(isset($_POST['cpassword'])?'':'');

										echo form_password('cpassword',$company_val,$param_arr); 
										echo  form_error("cpassword");
									?> 

								</div>
							</div-->	
				 
				
							<div class="row cust-form-group">
								<div class="col-lg-11 text-center">
								<button type="submit"   class="btn btn-success"><i class="fa fa-send"></i> Send Reset Link</button>
									<a href="<?php echo CUSTOMERBASEURL.'customer/index/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>
									
								</div>
							</div>
							<?php echo form_close(); ?>
				
							<?php
							$form_attr=array(
										'name'=>'customer_account_form', 
										'class'=>'customer_account_form', 
										
										);
							if($otp_mode==''){
								$form_attr['class']='customer_otp_form hidden';
							}

							echo form_open(CUSTOMERBASEURL.'customer/myprofile',$form_attr); ?>
							<div class="row cust-form-group">
								<?php if($this->session->userdata('error_cust')!=""){?>
								<div class="alert alert-danger col-lg-8 col-lg-offset-2">
									<p><b>Error!</b> <?php echo $this->session->userdata('error_cust');$this->session->set_userdata('error_cust',''); ?></p>
								</div>
								<?php } ?>
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>OTP: </label>
								</div>
								<div class="col-lg-6 col-sm-6 text-left">
								  <?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'otp',
											'placeholder'=>'OTP',
											); 
										$company_val='';

										echo form_input('otp',$company_val,$param_arr); 
										echo  form_error("otp");
										?> 
										<small class="text-muted">Enter The OTP sent to your Updated / Registerd  Emai Address.</small>
								</div>
							</div>	
							
							<div class="row cust-form-group">
								<div class="col-lg-12 text-center">
									<button type="submit"   class="btn btn-success"><i class="fa fa-key"></i> Verify OTP</button>
									<a href="<?php echo CUSTOMERBASEURL.'customer/myprofile/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>
								</div>
							</div>				
							<?php echo form_close(); ?>
						</div>
					
				
				
				<div class="tab-pane <?php echo ($loan_active!=''?$loan_active:''); ?>" id="tab_3"> 
					<div class="row cust-form-group hidden">
						<div class="col-lg-12 text-right"><span class="avail-loan-amount">Available Loan Amount: <span class="label label-info"><i class="fa fa-rupee"></i> <?php echo number_format($resul_customer['cust_loan_limit'] - $amount_spent,2); ?></span></span></div>
					</div>
					
					<div class="row cust-form-group">
						<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
							<label>Total Loan Amount: </label>
						</div>
						<div class="col-lg-6 col-sm-6 text-left"><span class="loan-amount"><i class="fa fa-rupee"></i> <?php echo number_format($resul_customer['cust_loan_limit'],2); ?></span></div>
					</div>
					
					<div class="row cust-form-group">
						<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
							<label>Monthly Loan Limit: </label>
						</div>
						<div class="col-lg-6 col-sm-6 text-left"><span class="loan-amount"><i class="fa fa-rupee"></i> <?php echo number_format($resul_customer['cust_monthly_loan_limit'],2); ?> </span></div>
					</div>	
					
					<div class="row cust-form-group">
						<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
							<label>Weekly Loan Limit: </label>
						</div>
						<div class="col-lg-6 col-sm-6 text-left"><span class="loan-amount"><i class="fa fa-rupee"></i> <?php echo number_format($resul_customer['cust_weekly_loan_limit'],2); ?> </span></div>
					</div>				
				</div>
			</div>
			<!-- page end-->
		</section>
    </section>
    <!--main content end-->