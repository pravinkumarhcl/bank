 <!--main content start-->
    <section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="icon_document_alt"></i> Add Replenishments</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i> Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/replenishments/"; ?>"><i class="icon_document_alt"></i> Replenishments</a></li>
							<li><i class="fa fa-square-o"></i>Add </li>
						</ol>
					</div>
				</div>
				<!-- page start-->
				<div class="box-body">
					<div class="tab-content customer-profile-view">
						<div class="tab-pane <?php echo ($basic_active!=''?$basic_active:''); ?>" id="tab_1">
							<?php if($this->session->userdata('ac_success_message')!=''){ ?>
								<div class="alert alert-success alert-dismissible">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
									<small><?php echo $this->session->userdata('ac_success_message'); $this->session->set_userdata('ac_success_message',''); 
									?></small>
								</div>				
							 <?php
							}
							$form_attr=array(
								'name'=>'customer_basic_form', 
								'class'=>'customer_basic_form', 
							);
							echo form_open('',$form_attr); ?>
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Amount deposited: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'amount',
											'placeholder'=>'Amount',
										);
										$name_val=(isset($_POST['amount'])?set_value('amount'):'');
										echo form_input('amount',$name_val,$param_arr);
										echo  form_error("amount");
									?>
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Transaction reference: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'ref_number',
											'placeholder'=>'Reference Number',
										);
										$company_val=(isset($_POST['ref_number'])?set_value('ref_number'):'');
										echo form_input('ref_number',$company_val,$param_arr); 
										echo  form_error("ref_number");
									?> 
								</div>
							</div>	
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Cheque date: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'datepicker_new',
											'placeholder'=>'Cheque Date',
										);
										$address_1_val=(isset($_POST['cheque_date'])?set_value('cheque_date'):'');
										echo form_input('cheque_date',$address_1_val,$param_arr);
										echo  form_error("cheque_date");
									?>
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Cheque drawn on bank: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'bank_name',
											'placeholder'=>'Bank Name',
										);
										$address_1_val=(isset($_POST['bank_name'])?set_value('bank_name'):'');
										echo form_input('bank_name',$address_1_val,$param_arr);
										echo  form_error("bank_name");
									?> 
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Transaction remarks: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'remark',
											'placeholder'=>'Remarks',
										);
										$city_val=(isset($_POST['remark'])?set_value('remark'):''); 								
										echo form_input('remark',$city_val,$param_arr);
										echo  form_error("remark");
									?>
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-12 text-center">
									<button type="submit"   class="btn btn-success"><i class="fa fa-save"></i> Add</button>
									<a href="<?php echo CUSTOMERBASEURL.'customer/index/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>
								</div>
							</div>
							<?php echo form_close(); ?>
						</div>
					</div>
					<!-- page end-->
				</div>
			</div>
		</section>
	</section>
    <!--main content end-->