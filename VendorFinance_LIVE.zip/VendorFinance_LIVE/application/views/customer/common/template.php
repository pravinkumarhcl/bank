<!DOCTYPE html>
<html lang="en">
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
  <title>Vendor Finance-Customer Dashboard</title>
<?php $this->load->view('customer/common/com-header.php'); ?>
</head>
<body>
  <section id="container" class="">  
  
<?php
if($view_file!='customer/login'&& $view_file!='customer/forgotpassword'&& $view_file!='customer/recive_otp'&& $view_file!='customer/reset_password'){
 $this->load->view('customer/common/header.php'); ?>
<?php $this->load->view('customer/common/side-bar.php'); }?>
  <?php $this->load->view($view_file); ?>
  
    <!--main content end-->
  </section>
  <!-- javascripts -->
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.js"></script>
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery-ui-1.10.4.min.js"></script>
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.scrollTo.min.js"></script>
  <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.nicescroll.js" type="text/javascript"></script>
 
   
     <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/dataTables.min.js"></script>
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.customSelect.min.js"></script>
    <!--custome script for all page-->
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/scripts.js"></script> 
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.autosize.min.js"></script> 
 
    <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/jquery.slimscroll.min.js"></script>
     <script src="<?php echo CUSTOMERBASEURL; ?>assets/customer/js/bootstrap-datetimepicker.js"></script>
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>

  	<script>
	function load_invoices(t){
		window.open('<?php echo CUSTOMERBASEURL."customer/invoices/"; ?>'+$(t).val(),'_self');
	}
	$(document).ready(function(){
			$('.select-status').val('<?php echo $invoice_type; ?>');

	});
	</script>

</body>

</html>
