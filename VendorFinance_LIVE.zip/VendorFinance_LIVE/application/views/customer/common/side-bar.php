
<!---Newly added script on 26-02-2019 by Designer Starts -->
<!-- <script>
$(document).ready(function(){
  $(".sub-menu").click(function(){
    $(".sub").toggle("slow");
  });
});
</script> -->
<!-- Ends-->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="<?php echo ($in_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
		    <li class="<?php echo ($inv_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/"; ?>">
                          <i class="icon_document_alt"></i>
                          <span>Invoice Details</span>
                      </a>
          </li>
          <!--li class="sub-menu <?php echo ($inv_active!=''?'active':''); ?>">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Invoice Details</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                 </a>
            <ul class="sub">
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/"; ?>">All Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Pending"; ?>">Pending Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Verified"; ?>">Verified Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Approved"; ?>">Approved Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Rejected"; ?>">Rejected Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Paid"; ?>">Paid Invoices</a></li>
              <li><a class="" href="<?php echo CUSTOMERBASEURL."customer/invoices/Documents"; ?>">Pending Documents</a></li>
            </ul>
          </li-->
		  <li class="sub-menu <?php echo ($vp_active!=''?'active':''); ?>">
            <a href="javascript:;" class="">
                          <i class="fa fa-money"></i>
                          <span>Transactions</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                 </a>
            <ul class="sub">
              <li><a class=" 	" href="<?php echo CUSTOMERBASEURL."customer/vendor_payments/"; ?>">Vendor Payments</a></li>
               
            </ul>
          </li> 
		  
		  <li class="<?php echo ($repmt_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/replenishments/"; ?>">
                          <i class="icon_document_alt"></i>
                          <span>Replenishments</span>
                      </a>
          </li>
 <li class="<?php echo ($fun_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/funds/"; ?>">
                          <i class="fa fa-money"></i>
                          <span>Fund Flow</span>
                      </a>
          </li>
		  <li class="<?php echo ($upload_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/uploadInvoicesForm/"; ?>">
                          <i class="icon_document_alt"></i>
                          <span>Upload Invoice List</span>
						  
		  </a>
          </li> 
		  <li class="<?php echo ($rep_due_active!=''?'active':''); ?>">
            <a class="" href="<?php echo CUSTOMERBASEURL."customer/replenishments_due/"; ?>">
                          <i class="icon_document_alt"></i>
                          <span>Payable Due</span>
						  
		  </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->