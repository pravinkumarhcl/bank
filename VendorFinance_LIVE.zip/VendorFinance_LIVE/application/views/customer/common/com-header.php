


  <!-- Bootstrap CSS -->
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/elegant-icons-style.css" rel="stylesheet" />
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/owl.carousel.css" type="text/css">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- Custom styles -->
  <link rel="stylesheet" href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/fullcalendar.css">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/widgets.css" rel="stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/style.css" rel="stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/style-responsive.css" rel="stylesheet" />
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/xcharts.min.css" rel=" stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/dataTables.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/bootstrap-glyphicon.css" rel="stylesheet">
  <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
  <script src="<?=ADMINBASEURL;?>assets/js/jquery.min.js"></script>
  <link href="https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
  <script src="https://getbootstrap.com/docs/3.3/assets/js/ie-emulation-modes-warning.js"></script>

 <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
       <link href="<?php echo CUSTOMERBASEURL; ?>assets/customer/css/ie8.css" rel="stylesheet" />
    <![endif]-->