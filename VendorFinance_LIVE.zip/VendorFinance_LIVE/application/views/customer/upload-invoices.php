 <!--main content start-->
    <section id="main-content">
		<section class="wrapper">
			<div class="dash_bg">
				<div class="row box_header">
					<div class="col-lg-12">
						<h3 class="page-header"><i class="icon_document_alt"></i> Upload Invoices</h3>
						<ol class="breadcrumb">
							<li><a href="<?php echo CUSTOMERBASEURL."customer/index/"; ?>"><i class="fa fa-home"></i> Home</a></li>
							<li><a href="<?php echo CUSTOMERBASEURL."customer/uploadInvoicesForm/"; ?>"><i class="icon_document_alt"></i> Invoices</a></li>
							<li><i class="fa fa-square-o"></i>Upload Invoices </li>
						</ol>
					</div>
				</div>
				<!-- page start-->
				<div class="box-body">
					<div class="tab-content customer-profile-view">
						
						<?php if($this->session->userdata('ac_success_message')!=''){ ?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<small><?php echo $this->session->userdata('ac_success_message'); $this->session->set_userdata('ac_success_message',''); 
							?></small>
						</div>				
						<?php
						}
						else if($this->session->userdata('ac_error_message')!=''){ ?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<small><?php echo $this->session->userdata('ac_error_message'); $this->session->set_userdata('ac_error_message',''); 
							?></small>
						</div>				
						<?php
						}
						?>

                        
<div class="text-right"><a  href="<?php echo CUSTOMERBASEURL."customer/exportCSV"; ?>"><button class="btn btn-primary"><i class="glyphicon glyphicon-download"></i> Download Template</button></a></div>
						<!-- form start -->
						<form role="form" enctype="multipart/form-data" method="POST" action="<?=CUSTOMERBASEURL;?>customer/upload_invoices">

						<div class="box-body">
						
							<div class="row">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
								<label>Upload File:</label>
								</div>
								<div class="col-lg-8 col-sm-6 text-left">
								<div class="form-group-inner">
								<input  name="file_invoice"  type="file" id="file-invoices"><?= form_error("file_invoice")?>
								<p class="text-muted"><small>FileType : CSV( Max File Size: <?php echo $max_file_size; ?>)</small></p>
								</div>
								</div>
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
								<button type="submit" class="btn btn-primary" id="clicksubm">Submit</button>
								</div>

							</div>
						</div>						
						</form>
						</div>
          
							<hr />
					<table id="example2" class="table table-bordered table-hover table-striped" style="width:100%">
						<thead>
							<tr>
								<th class="text-center">S.No</th>
								<th class="text-center">Filename</th>
								<th class="text-center">Date of Uploaded</th>
								<th class="text-center">Date of Processed</th>
								<th class="text-center">Status</th> 
								<th class="text-center">Action</th>
								
							</tr>
						</thead>
						<tbody>
                  
							<?php
								foreach($invoice_data_csv as $row)
							{
								?>
								<tr>
									<td class="text-center"><?php echo $i=$i+1; ?></td>
									<td><?php echo  $row->filename; ?></td>
									<td><?php echo date('d-m-Y H:i:s',strtotime($row->date)); ?></td>
									<td><?php echo ($row->status==1?'N/A':date('d-m-Y H:i:s',strtotime($row->processed_date))) ; ?></td>
									<td><?php echo ($row->status==1?'<span class="label label-sm label-info">Pending</span>':'<span class="label label-sm label-success">Processed</span>'); ?></td>
									
								
									<td class="text-center"><?php  if($row->status ==1){?><a class="btn btn-danger btn-xs" onclick="return confirm('Are you sure you want to delete the Invoice File?');" href="<?php echo CUSTOMERBASEURL."customer/deleteInvoiceCSV/".$row->id; ?>"> Delete</a>
												
									<?php } else{?>
									
									<?php } ?>
										<a class="btn btn-primary btn-xs btn-flat" style="margin: 0;" href="<?php echo CUSTOMERBASEURL.'customer/download_invoice/'.base64_encode($row->id); ?>">Download</a>
									</td>
								</tr>
								<?php 
							 
							} 
							if(count($invoice_data_csv)==0){
								?>
								<tr>
								<td colspan="13" class="text-center text-danger">No Files Uploaded ...!</td>
								</tr>
								<?php
							}
							?>
					
						</tbody>
					</table>
			
					</div>
					<!-- page end-->
				</div>
			</div>
		</section>
	</section>
    <!--main content end-->
