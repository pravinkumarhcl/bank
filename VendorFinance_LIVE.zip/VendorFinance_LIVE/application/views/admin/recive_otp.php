<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteSettings->meta_title; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <meta name="description" content="<?=$siteSettings->meta_description; ?>">
  <meta name="keywords" content="<?=$siteSettings->meta_keywords; ?>">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/bootstrap-admin.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/icons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/square/blue.css">
  
  <!--User defined CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/style.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
      <a href="#"><b>Admin Login</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Forgot Password </p>
     <?php if($this->session->userdata('error_cust')!=""){?>
    <div class="alert alert-danger">
        <p><b>Error!</b> <?php echo $this->session->userdata('error_cust');$this->session->set_userdata('error_cust',''); ?></p>
    </div>
    <?php } ?>
	<?php  if($this->session->userdata('success_cust')!=""){?>
				<div class="alert alert-success">
					<p><b>Success!</b>
						<?php echo $this->session->userdata('success_cust');$this->session->set_userdata('success_cust',''); ?>
					</p>
				</div>
				<?php } ?>
    <form method="POST" action="">
      <div class="form-group has-feedback">
        <input type="text" name="user_otp" class="form-control" placeholder="Enter Received OTP">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span><?= form_error("email")?>
		 <?php echo form_error("user_otp"); ?> 
      </div>
      <div class="form-group has-feedback">
          	<span class="pull-left">Didn't Receive? <a href="<?php echo ADMINBASEURL.'bankadmin/resend_otp/'.$salt; ?>">Resend OTP</a></span>
       </div>
	   
      <div class="row">
     
        <!-- /.col -->
        <div class="col-xs-12" style="text-align: center;padding-top: 20px;"> 
		<button type="submit" class="btn btn-primary btn-block btn-flat forgot-elements">Verify</button>
          <a href="<?php echo ADMINBASEURL.'bankadmin/index'; ?>" class="btn btn-primary btn-block btn-flat forgot-elements">Cancel</a>
		   
        </div>
        <!-- /.col -->
      </div>
    </form>
 <br>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?=ADMINBASEURL;?>assets/js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=ADMINBASEURL;?>assets/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?=ADMINBASEURL;?>assets/js/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>
