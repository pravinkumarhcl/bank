<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Customer Report
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=ADMINBASEURL;?>bankadmin"><i class="fa fa-dashboard"></i> Home</a></li>
         <li>Customer Report</li>        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">          
            <!-- /.box-header -->
            <div class="box-body">			
				<form class="form-inline" method="POST" action=""><!-- form-search -->
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo $filter_from; ?>"  name="filter_from" id="from_date" placeholder="From Date">
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo $filter_to; ?>" name="filter_to" id="to_date" placeholder="To Date">
						</div>
					</div>	
					<div class="form-group">
						&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary">Submit</button>
						&nbsp;&nbsp;&nbsp;<button type="submit" name='reset' class="btn btn-primary">Reset</button>
					</div>
				</form>
				<hr />
				<!-- Report Download Excel
				<form class="form-inline" id="downloads" method ="POST" action="<?=ADMINBASEURL;?>bankadmin/cust_reportexc">
				<hr>
					<div class="form-group" style="float:right;">
						<button type="hidden" name='cust_download' class="btn btn-primary"><i class="fa fa-download">&nbsp;</i>
							<span> Download</span>
						</button>
					</div>
				</form>	-->
				<!--Report Download ends-->
				<div class="table-responsive">
              <table id="excel_report" class="table table-bordered table-hover table-striped" style="width:100%" style="width:100%">
                <thead>
                  <tr>
                    <th>S.NO</th>
                    <th>Customer Code</th>
                    <th>Customer Name</th>
                    
                    <th>Loan Amt</th>
                    <th>Paid Amt</th>
                    <th>Balance Amt</th>                                      
                    <th>Amt To Be Paid</th>                                      
                  </tr>
                  </thead>
                  <tbody>        
					<?php
					$i=1;
					foreach($invoiceReport AS $data) { ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><a href="<?=ADMINBASEURL;?>bankadmin/vendorBasedReport/<?php echo $data['cust_id']; ?>"><?php echo $data['cust_no']; ?></a></td>
						<td><?php echo $data['cust_name']; ?></td>
						
						<td class="text-right"><?php echo $data['cust_loan_limit']; ?></td>
						<td class="text-right"><?php echo $data['paid_amount']; ?></td>
						<td class="text-right"><?php echo $data['balance_amount']; ?></td>												
						<td class="text-right"><?php echo $data['pending_amount']; ?></td>												
					</tr>
					<?php $i++; } ?>
                  </tbody>
               </table>
               </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>