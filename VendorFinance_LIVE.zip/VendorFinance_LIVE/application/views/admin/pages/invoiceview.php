<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Invoice #<?=$invoicedetails->invoice_number; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Invoice Details</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title">Invoice #<?=$invoicedetails->invoice_number; ?></h3>
            </div>-->
             
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
			<div id="alert_message">
				
			</div>	
            <!-- /.box-header -->
            <div class="box-body">
               <!--<div class="pull-right">
                   <a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceList?id=<?=$invoicedetails->invoice_vendor_id;?>">
                       <button type="button" class="btn btn-primary btn-sm btn-flat">View List</button>
                   </a>
                   
              </div>-->
              <table class="table table-bordered table-hover" style="width:100%">
                <tr><td colspan="2"><b>General Info</b></td></tr>
                <tr><td>Invoice Number</td><td><?=$invoicedetails->invoice_number; ?></td></tr>
                <tr><td colspan="2"><b>Account Info</b></td></tr>
                <tr><td>Beneficiary Name</td><td><?=$invoicedetails->invoice_beneficiary_name; ?></td></tr>
                <tr><td>Beneficiary Account Number</td><td><?=$invoicedetails->invoice_beneficiary_number; ?></td></tr>
                <tr><td>Beneficiary IFSC Code</td><td><?=$invoicedetails->invoice_ifsc_code; ?></td></tr>
                <tr><td colspan="2"><b>Invoice Amount Details</b></td></tr>
                <tr><td>Invoice Date</td><td><?=date('Y-m-d',strtotime($invoicedetails->invoice_date)); ?></td></tr>
                <tr><td>Invoice Amount</td><td><?=$invoicedetails->invoice_amount; ?></td></tr>
                <tr><td>Interest Rate</td><td><?=$interestRate; ?></td></tr>
                <tr><td>Invoice Deduction Days</td><td><?=$invoicedetails->invoice_deduction_days; ?></td></tr>
                <tr><td>Invoice Net Amount</td><td>
                    <?php 
                     $value = $interestRate*($invoicedetails->invoice_amount*$invoicedetails->invoice_deduction_days)/365;
                     $valuefin = $value/100;
                     $res = $invoicedetails->invoice_amount-$valuefin;
                     echo number_format($res,2);
                    ?></td></tr>
                <tr><td colspan="2"><b>Invoice Status</b></td></tr>
                <tr><td>Invoice Status</td>
                    <td>
                        <?php 
						if($invoicedetails->invoice_status!='Paid' && $limitcheck == 0)
                        { 
						echo $invoicedetails->invoice_status;
						}
                        $actualStatus = $invoicedetails->invoice_status;
                        if($actualStatus!='Paid')
                        { 
					if($limitcheck == 0){?>
                        <form action="<?=ADMINBASEURL;?>/bankadmin/Invoicestatusupdate" id="view_invoice" method="POST">
                            <input type="hidden" name="invoice_id[]" value="<?php  echo $this->encryption->encrypt($invoicedetails->invoice_id); ?>" />
							 <input type="hidden" name="invoice_id_1" id="invoice_id" value="<?php  echo $this->encryption->encrypt($invoicedetails->invoice_id); ?>" />
                            <input type="hidden" name="customer_id" id="customer_id"  value="<?php  echo $invoicedetails->invoice_cust_id; ?>" />
							<input type="hidden" name="status" id="status_inv" value="<?php echo $this->encryption->encrypt($actualStatus); ?>" /> 
							
							<div class="pull-right btn-flat" style="margin-left:1%;text-align: right;">
							<?php 
							if($actualStatus=='Pending'){ ?>
								<button onclick="submitform('Verified','<?php echo $this->encryption->encrypt('Verified');?>')" type="button" name="invoice_status" value="Verified" class="btn btn-success">Verify</button>			
							<?php }
							if($actualStatus=='Verified'){ ?>
								<button onclick="submitform('Approved','<?php echo $this->encryption->encrypt('Approved');?>')" type="button" name="invoice_status" value="Approved" class="btn btn-success">Approve</button>
							<?php }					
							if($actualStatus=='Pending' || $actualStatus=='Verified' || $actualStatus=='Pending'){ ?>
								<button type="button"  onclick="showPopup()" name="invoice_status" value="Rejected" class="btn btn-danger">Reject</button>
							<?php }
							if($actualStatus=='Rejected'){ ?>
								<button onclick="submitform('Pending','<?php echo $this->encryption->encrypt('Pending');?>')" type="button" name="invoice_status" value="Pending" class="btn btn-warning">Move To Pending</button>
							<?php } ?>

							</div>
							 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Please enter the reason </h4>
        </div>
        <div class="modal-body">
          <textarea style="min-width: 100%" id="reject_reason" name="reject_reason" id="reject_reason" required></textarea>
		 
        </div>
        <div class="modal-footer">
		<button type="button" onclick="submitform('Rejected','<?php echo $this->encryption->encrypt('Rejected');?>')" id="submit_reason" class="btn btn-default" >Submit</button>
          <button type="submit"  class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
   <input type="hidden" name="invoice_status"  id="invoice_status"/>
	
                        </form>
						
						
                        <?php
                        }
                        else
                        {
                             echo $actualStatus; 
                        }
                        }
                        else
                        {
                           echo "Paid"; 
                        }?>
                    </td></tr>
					
					<?php  $actualStatus = $invoicedetails->invoice_status;
					if($actualStatus == 'Rejected'){
					?>
					<tr>
					<td>
					Reason
					</td>
					<td><?php echo $invoicedetails->reject_reason;?></td>
					</tr>
					<tr>
					<?php } ?>
					
						<td>
							Documents Uploaded
						</td>
						<td>
							<?php 
							if(count($documents)!=0){
								
							 	foreach($documents as $document_data){
									
									
									?>
									<li style="margin-bottom:10px;list-style:none">
										<i class="fa fa-file"></i> <?php echo $document_data['document_name']; ?>
										<a class="btn btn-warning btn-small" style="margin-right:10px;" target="_blank" href="<?php echo  ADMINBASEURL."bankadmin/download_myfiles/".$document_data['rand_key'].'/'.$document_data['id']."/".$cust_user_code; ?>" />    <i class="fa fa-download"></i> View / Download</a> 
									</li> 
									<?php
								}
							}
								else{
								echo "<span class='text-danger'>No Documents Attached</span>";
							}
							
							?>
						</td>
					</tr>
                               
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
    <script> 
	function showPopup(){
		
			
			$('#myModal').modal('show');
			$('#invoice_status').val('Rejected');

		
		 
		  
	}
	function submitform(status,redirect_status){
		$("#bg_model").fadeIn();
		var invoice_id = [];
		invoice_id.push($("#invoice_id").val());	
		var customer_id=$("#customer_id").val();
		var redirect_path ;
		var status_inv=$("#status_inv").val();
		if(status == 'Approved'){
			redirect_path = baseurl+"bankadmin/ApprovedInvoice";
		}		
		else{
			redirect_path = baseurl+"bankadmin/vendorInvoiceDues?status="+redirect_status;
		}
		var invoice_status=status;
		var reject_reason='';
		
		if(invoice_status=='Rejected')
		{
			$('#myModal').modal('hide');
			reject_reason=$("#reject_reason").val();
			invoice_status='Rejected';
			
		}			
	
		
		$.ajax({
				method:'POST',
				data:{'invoice_status':invoice_status,'invoice_id':invoice_id,'status':status_inv,'customer_id':customer_id,'reject_reason':reject_reason},
				url: baseurl+'bankadmin/Invoicestatusupdate',
				success:function(data){	
				
					var json = $.parseJSON(data);	
			      
					if(json['message']=='1')						
					{
						
						var data_show='<div class="alert alert-success">   <p><b>Success!</b> '+json['data']+' </p>  </div>';
					}else{
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
					}
					   window.location.href=redirect_path;
					$("#alert_message").html(data_show);
					//datatable_appointments.ajax.reload( null, false )
					$("#bg_model").fadeOut();
				}
			});	
      }
	
	</script>