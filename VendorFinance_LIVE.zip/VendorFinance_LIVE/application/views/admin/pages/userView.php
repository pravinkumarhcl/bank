<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       User Details
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User Details</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
             
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
                <a style="float:right;" href="<?=ADMINBASEURL;?>bankadmin/userManagement" ><button type="button" class="btn btn-primary"> Back To List</button></a>
              <table class="table table-bordered table-hover" style="width:100%">
                  <tr><td colspan="2"><b>General Info</b></td></tr>
                <tr><td>Username</td><td><?=ucfirst($user_details->user_name); ?></td></tr>
                <tr><td>Phone Number</td><td><?=ucfirst($user_details->user_phone); ?></td></tr>
				<tr><td>Email Address</td><td><?=ucfirst($user_details->user_email); ?></td></tr>
                <tr><td colspan="2"><b>Department Info</b></td></tr>                
                <tr><td>Department</td><td><?=ucfirst($user_details->user_department); ?></td></tr>
                <tr><td>Designation</td><td><?=ucfirst($user_details->user_designation); ?></td></tr>
              
                
               
                               
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>