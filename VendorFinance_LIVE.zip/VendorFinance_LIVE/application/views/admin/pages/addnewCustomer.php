<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title; ?> Customer
		 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customers</a></li>
        <li class="active"><?=$title; ?> Customer</li>
      </ol>
	 
    </section>

    <?php
    if($this->session->flashdata('Success')):?>
    <div class="box-body">
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                <p> <?=$this->session->flashdata('Success'); ?></p>
            </div>
     </div>
    <?php endif;?>
    
    <!-- Main content -->
    <section class="content">
	
      <div class="row">          
        <div class="col-md-12">
		<a  class="pull-right btn btn-primary margin_5"  href="<?=ADMINBASEURL;?>bankadmin/customerlist"><i class="fa fa-table"></i></i><span> Customers</span></a>
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
           <?php 
           
           if(form_error('city')!='' || form_error('state')!='' || form_error('phone')!='' || 
              form_error('email')!='' || form_error('ifsc_code')!='' || form_error('account_no')!='' || form_error('user_code')!='' || 
              form_error('company_name')!='' || form_error('address1')!='')
           {
               $tab1 = 'active'; 
               $tab1_li = 'active'; 
               $expanded1 = 'true';
              
           }
           else if(form_error('loan_limit')!='' || form_error('loan_weekly_limit')!='' || form_error('loan_monthly_limit')!='')
           {
               $tab2 = 'active'; 
               $tab2_li = 'active'; 
               $expanded2 = 'true'; 
              
           }
           else if(form_error('mclr')!='' || form_error('strategic_premium_rate')!='' || form_error('risk_premium_rate')!='' || form_error('interest_rate')!='')
           {
               $tab3 = 'active'; 
               $tab3_li = 'active'; 
               $expanded3 = 'true'; 
              
           }
           else {
               $tab1 = 'active'; 
               $tab1_li = 'active'; 
               $expanded1 = 'true';
           }    

		   
           ?>
            <ul class="nav nav-tabs" id="tab-menus-change">
              <li class="<?=$tab1_li;?>"><a href="#tab_1" data-toggle="tab" aria-expanded="<?=$expanded1;?>">General Info</a></li>
              <li class="<?=$tab2_li;?>"><a href="#tab_2" data-toggle="tab" aria-expanded="<?=$expanded2;?>">Loan Limit</a></li>
              <li class="<?=$tab3_li;?>"><a href="#tab_3" data-toggle="tab" aria-expanded="<?=$expanded3;?>">Interest Rate</a></li>    
            </ul>
			
            <form role="form" method="POST" id="CustomerVerification" action="<?=ADMINBASEURL;?>bankadmin/CustomerVerification" onsubmit="return makeSearch()">
            <input type="hidden" name="id" id="cust_id_based" value="<?=$customerdetails->cust_id;?>" />
            <div class="tab-content">
			
              <div class="tab-pane <?=$tab1;?>" id="tab_1">
                
              <div class="box-body">                  
                   
                <div class="form-group">
                  <label>Code</label>
                  <div class="form-group-inner">
                  <input class="form-control" <?php if($customerdetails->cust_id!='') { ?> readonly <?php } ?> name="user_code" value="<?=$customerdetails->cust_user_code;?>" placeholder="Number" type="text"><?= form_error("user_code")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Name</label>
                  <div class="form-group-inner">
                  <input class="form-control" id="numeric" name="name" value="<?=$customerdetails->cust_name;?>" placeholder="Name" type="text"><?= form_error("name")?>
                  </div>
                </div>
               
                <div class="form-group">
                  <label>Address 1</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="address1" value="<?=$customerdetails->cust_address1;?>" placeholder="Address 1" type="text"><?= form_error("address1")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Address 2</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="address2" value="<?=$customerdetails->cust_address2;?>" placeholder="Address 2 (Optional)" type="text"><?= form_error("address2")?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>City</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="city" value="<?=$customerdetails->cust_city;?>" placeholder="City" type="text"><?= form_error("city")?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>State</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="state" value="<?=$customerdetails->cust_state;?>" placeholder="State" type="text"><?= form_error("state")?>
                  </div>
                </div>

                <div class="form-group">
                  <label>Point of Contact Name</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="contact_name" value="<?=$customerdetails->cust_contact_name;?>" placeholder="Point of Contact Name" type="text"><?= form_error("contact_name")?>
                  </div>
                </div>

                <div class="form-group">
                  <label>Mobile Number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="mobile" onkeypress="return isNumber(event)" value="<?=$customerdetails->cust_mobile;?>" placeholder="Mobile number" maxlength="12" type="text"><?= form_error("mobile")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Office Number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="phone" onkeypress="return isNumber(event)" value="<?=$customerdetails->cust_phone;?>" placeholder="Office number" maxlength="12" type="text"><?= form_error("phone")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Email ID</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="email" value="<?=$customerdetails->cust_email;?>" placeholder="Email ID" type="text"><?= form_error("email")?>
                  </div>
                </div>
                  <div class="form-group">
                  <label>Bank Account Number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="account_no" onkeypress="return isNumber(event)" value="<?=$customerdetails->cust_account_no;?>" placeholder="Bank account number" maxlength="16" type="text"><?= form_error("account_no")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>IFSC Code</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="ifsc_code" value="<?=$customerdetails->cust_ifsc_code;?>" placeholder="IFSC Code" type="text"><?= form_error("ifsc_code")?>
                </div>
                </div>
                  
               <!-- <div class="form-group">
                  <label>Parent Company (If this is subsidiary)</label>
                  <div class="form-group-inner">
				 <?php 
					$status_ref='';
					if($customerdetails->cust_type=='sub' OR $customerdetails->cust_type=='parent')
					  {
						  $status_ref=' disabled ';
						  echo "<input type='hidden' name='referral_code' value='".$customerdetails->cust_referral_id."'>";
					  }
				
					 
				  ?>
                  <select  class="form-control" <?=$status_ref; ?> name="referral_code" id="referral_code">
                      <option value="">---Select parent company---</option>
                  <?php
				  
                  foreach($referralCodes as $eachcodes)
                  {
					 echo $eachcodes->cust_id; 
					  ?>
                      <option value="<?=$eachcodes->cust_id;?>" <?php echo ($customerdetails->cust_referral_id==$eachcodes->cust_id)? 'selected="selected"':''; ?>><?=$eachcodes->cust_user_code.' - '.ucfirst($eachcodes->cust_name);?></option>
                  <?php  
                  }?>
                  </select>
                  </div>
                </div>
				 <div class="form-group">
                  <label>Type</label>
                  <div class="form-group-inner">
				  <?php				  
					/*   if($customerdetails->cust_type=='sub' OR $customerdetails->cust_type=='Subsidiary Company')
					  {
						  $type_cust='Subsidiary Company';
					  }else{
						  $type_cust='Parent Company';
					  } */
				  ?>
                  <input class="form-control" name="cust_type" id="company_type" readonly value="<?php echo $type_cust; ?>" placeholder="Company Type" type="text">
                </div>
                </div>-->
              </div>
				<div class="box-footer">
				<div class="pull-right">
					<a href="#tab_2" class="btn btn-primary next-customer" name="add-next-customer" data-toggle="tab" aria-expanded="true">Next</a> <button type="submit" name="add-save-customer" class="btn btn-primary">Save</button>&nbsp; &nbsp;  
				</div> 
                </div>
              <!-- /.box-body -->
              </div>
                
              <!-- /.tab-pane -->
              <div class="tab-pane <?=$tab2;?>" id="tab_2">
                <div class="box-body loan_limit_align">
                    
                <div class="form-group">
                  <label>Loan Limit</label>
                  <div class="form-group-inner">
                  <input class="form-control pull-left" name="loan_limit" id="loan_limit" value="<?=$customerdetails->cust_loan_limit;?>" placeholder="Loan Limit" type="text"><?= form_error("loan_limit")?>	
				  <div class='pull-left subsidiary-limit' id="sub_loan_limit"></div>				  
                </div>
				
                </div>
                 <?php if($customerdetails->cust_id!='' && $customerdetails->cust_type!='sub') { ?>  
                <div class="form-group">
                  <label>Balance Loan Limit</label>
                  <div class="form-group-inner">
                      <input class="form-control" id="balance_loan_limit" value="<?php echo $customerdetails->cust_loan_limit;?>" disabled placeholder="Loan Limit" type="text">
                </div>
                </div>
                 <?php } ?>
                <div class="form-group">
                  <label>Monthly Loan Limit</label>
                  <div class="form-group-inner">
                  <input class="form-control pull-left" id="monthly_loan_limit" name="monthly_loan_limit" value="<?php echo $customerdetails->cust_monthly_loan_limit;?>" placeholder="Monthly Loan Limit" type="text"><?= form_error("monthly_loan_limit")?>
				  <div class='pull-left subsidiary-limit' id="sub_monthly_loan_limit"></div>
                </div>
                </div>
				
                <div class="form-group">
                  <label>Weekly Loan Limit</label>
                  <div class="form-group-inner">
                  <input class="form-control pull-left" id="weekly_loan_limit" name="weekly_loan_limit" value="<?=$customerdetails->cust_weekly_loan_limit;?>" placeholder="Weekly Loan Limit" type="text"><?= form_error("weekly_loan_limit")?>
				  <div class='pull-left subsidiary-limit' id="sub_weekly_loan_limit"></div>
                </div>
                </div>
                <div class="form-group">
                  <label>Group Company Limit(%)</label>
                  <div class="form-group-inner">
                  <input class="form-control pull-left" id="vendor_company_limit" name="vendor_company_limit" value="<?php if($customerdetails->vendor_company_limit>0){ echo $customerdetails->vendor_company_limit; }else{ echo 40; }  ?>" placeholder="Company Limit(%)" maxlength="5" type="text"><?= form_error("vendor_company_limit")?>			  
                </div>
                </div>
                </div>
				<div class="box-footer">
					<div class="pull-right">
						<a href="#tab_3" class="btn btn-primary next-customer" name="loan-next-customer" data-toggle="tab" aria-expanded="true">Next
						</a>&nbsp;&nbsp; 	<button type="submit" name="loan-save-customer" class="btn btn-primary">Save</button>
					</div>
                </div>
              </div>
              <!-- /.tab-pane -->
              
              <!-- /.tab-pane -->
			
              <div class="tab-pane <?=$tab3;?>" id="tab_3">
                <div class="box-body interest_rate_align">
               <?php /*
			   <div class="form-group">
                  <label>  <?php 
					
                      $cust_mclr_res = $cust_mclr;
					  
					  if($customerdetails->cust_id!='' && $cust_mclr_res==12)
					  {
						 $customerdetails->mclr_twelve=$customerdetails->mclr_percent; 
					  }	
					  if($customerdetails->cust_id!='' && $cust_mclr_res==6)
					  {
						 $customerdetails->six_mclr=$customerdetails->mclr_percent; 
					  }					   
					  if($customerdetails->cust_id!='' && $cust_mclr_res==9)
					  {
						 $customerdetails->nine_mclr=$customerdetails->mclr_percent; 
					  }
					  if($customerdetails->cust_id!='' && $cust_mclr_res==3)
					  {
						 $customerdetails->three_mclr=$customerdetails->mclr_percent; 
					  }
					 
				  ?>
				<div class="pull-right">(%)</div>
                  <select id="mclr_based_interest" name="mclr" class="form-control mclr">
                      <option value="3" <?php echo ($customerdetails->cust_mclr==3 ? 'selected="selected"':''); ?> >3 Months MCLR </option>
                      <option value="6" <?php echo ($customerdetails->cust_mclr==6 ? 'selected="selected"':''); ?> >6 Months MCLR </option>
                      <option value="9" <?php echo ($customerdetails->cust_mclr==9 ? 'selected="selected"':''); ?> >9 Months MCLR </option>
                      <option value="12" <?php echo ($customerdetails->cust_mclr==12 ? 'selected="selected"':''); ?> >1 Year MCLR </option>
                  </select></label>
                  <div class="form-group-inner">
                 
				 <input class="form-control interest_rate mclr_intrest" style="<?php echo ($cust_mclr==3 || $cust_mclr=='' ? '':'display:none;'); ?>" readonly="readonly" name="three_mclr" id="3mclr" value="<?php echo ($cust_mclr==3 ? $customerdetails->three_mclr:$ratesMasterActive['0']['3mclr']); ?>" placeholder="Ratio" type="text">
				 
				 <input class="form-control interest_rate mclr_intrest" style="<?php echo ($cust_mclr==6 ? '':'display:none;'); ?>" readonly="readonly" id="6mclr" name="six_mclr" value="<?php echo ($cust_mclr==6 ? $customerdetails->six_mclr:$ratesMasterActive['0']['6mclr']); ?>" placeholder="Ratio" type="text">
				 
				 <input class="form-control interest_rate mclr_intrest" style="<?php echo ($cust_mclr==9 ? '':'display:none;'); ?>" readonly="readonly" id="9mclr" name="nine_mclr" value="<?php echo ($cust_mclr==9 ? $customerdetails->nine_mclr:$ratesMasterActive['0']['9mclr']); ?>" placeholder="Ratio" type="text">
				 <input class="form-control interest_rate mclr_intrest" style="<?php echo ($cust_mclr==12 ? '':'display:none;'); ?>" readonly="readonly" id="12mclr" name="mclr_twelve" value="<?php echo ($cust_mclr==12 ? $customerdetails->mclr_twelve:$ratesMasterActive['0']['12mclr']); ?>" placeholder="Ratio" type="text">
				  				  
				  <?= form_error("3mclr")?>
				  <?= form_error("6mclr")?>
				  <?= form_error("9mclr")?>
				  <?= form_error("12mclr")?>
                </div>
                </div>
				
				*/ ?>
				
                <div class="form-group">
                  <label>Effective Date</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="financing_date" name="financing_date" value="<?php
				  if(isset($customerdetails->financing_date))
				  {
					  echo $customerdetails->financing_date;
				  }
				  ?>" placeholder="Financing Date" type="text"><?= form_error("financing_date")?>
                </div>
                </div>
				
                <div class="form-group">
                  <label>3 Months MCLR</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="three_mclr" name="three_mclr" value="<?php
				  if(isset($customerdetails->three_mclr))
				  {
					  echo $customerdetails->three_mclr;
				  }
				  ?>" placeholder="3 Months MCLR" type="text"><?= form_error("three_mclr")?>
                </div>
                </div>
				
                <div class="form-group">
                  <label>6 Months MCLR</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="six_mclr" name="six_mclr" value="<?php
				  if(isset($customerdetails->six_mclr))
				  {
					  echo $customerdetails->six_mclr;
				  }
				  ?>" placeholder="6 Months MCLR" type="text"><?= form_error("six_mclr")?>
                </div>
                </div>
				
                <div class="form-group">
                  <label>9 Months MCLR</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="nine_mclr" name="nine_mclr" value="<?php
				  if(isset($customerdetails->nine_mclr))
				  {
					  echo $customerdetails->nine_mclr;
				  }
				  ?>" placeholder="9 Months MCLR" type="text"><?= form_error("nine_mclr")?>
                </div>
                </div>			
				
                <div class="form-group">
                  <label>1 Year MCLR</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="mclr_twelve" name="mclr_twelve" value="<?php
				  if(isset($customerdetails->mclr_twelve))
				  {
					  echo $customerdetails->mclr_twelve;
				  }
				  ?>" placeholder="1 Year MCLR" type="text"><?= form_error("mclr_twelve")?>
                </div>
                </div>
				
                <div class="form-group">
                  <label>Strategic Premium Rate(%)</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="strategic_premium_rate" name="strategic_premium_rate" value="<?php
				  if(isset($customerdetails->strategic_premium_rate))
				  {
					  echo $customerdetails->strategic_premium_rate;
				  }
				  ?>" placeholder="Strategic Premium Rate(%)" type="text"><?= form_error("strategic_premium_rate")?>
                </div>
                </div>
				
				
                <div class="form-group">
                  <label>Risk Premium Rate(%)</label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate"  id="risk_premium_rate" name="risk_premium_rate" value="<?php
				  if(isset($customerdetails->risk_premium_rate))
				  {
					  echo $customerdetails->risk_premium_rate;
				  }
				  ?>" placeholder="Risk Premium Rate(%)" type="text"><?= form_error("risk_premium_rate")?>
                </div>
                </div>
              
                <?php
             /*   if(count($displayInterestPending)>0)
                {?>
                  <div class="form-group">
                  <label>New Interest Rate waiting for approval </label>
                  <div class="form-group-inner">
                      <input class="form-control" readonly="readonly" value="<?=$displayInterestPending->cust_interest_rate;?>" type="text">
                  </div>
                  </div><?php
                }*/?>
                  <?php /*  
                 <div class="form-group">
                  <label>Current Interest Rate(%)</label>
                  <div class="form-group-inner">
                      <input class="form-control interest_rate_display" name="interest_rate" id="total_interest_rate" readonly="readonly" value=" <?php
				  if(isset($customerdetails->interest_rate))
				  {
					  echo $customerdetails->interest_rate;
				  }else{
					  echo $ratesMasterActive['0']['3mclr']+$ratesMasterActive['0']['risk_premium']+$ratesMasterActive['0']['strategic_premium'];
				  }
				  ?>" placeholder="Interest Rate" type="text">
                      <span class="interest_rate_error form_error"><?= form_error("interest_rate")?></span>
                </div>
                </div> */ ?>
				
				
                </div>
				<div class="box-footer">
					<button type="submit" class="pull-right btn btn-primary">Save</button>
                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
          
            </form>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
       
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script>
$('#CustomerVerification').on("change", function () {
    var monthly_loan_limit = $('#monthly_loan_limit').val();
    var loan_limit = $('#loan_limit').val();
    var weekly_loan_limit = $('#weekly_loan_limit').val();

    if (parseFloat(monthly_loan_limit) > parseFloat(loan_limit)) {
      alert("Monthly Loan Limit cannot be exceed Loan Limit!");
      $('#monthly_loan_limit').val("");
      return false;
    }

    if (parseFloat(weekly_loan_limit) > parseFloat(loan_limit) || parseFloat(weekly_loan_limit) > parseFloat(monthly_loan_limit)) {
      alert("Weekly Loan Limit cannot be exceed Monthly Limit!");
      $('#weekly_loan_limit').val("");
      return false;
    }
});
</script>