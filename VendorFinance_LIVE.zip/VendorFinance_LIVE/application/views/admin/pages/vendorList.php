<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$customerdetails->cust_name;?> Vendor Company
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>        
        <li class="active">Vendor Company</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="pull-right">
               <a href="<?=ADMINBASEURL;?>bankadmin/vendorform">
                   <button type="button" class="btn btn-primary btn-sm btn-flat">Add Vendor</button>
               </a>
               
               
            </div>
              <table id="example2" class="table table-bordered table-hover" style="width:100%">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Vendor Code</th>
                  <th>Vendor Name</th>
                  <th>Account no</th>
                  <th>IFSC Code</th>                  
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i=1;
                foreach($customerVendorlist as $vendors){?>
                <tr>
                  <td><?=$i; ?></td>
                  <td><?=$vendors->vendor_code; ?></td>
                  <td><?=$vendors->vendor_name; ?></td>
                  <td><?=$vendors->vendor_account_no; ?></td>
                  <td><?=$vendors->vendor_ifsc_code; ?></td>                  
                  <td><a href="<?=ADMINBASEURL;?>bankadmin/vendorform?vid=<?=$vendors->vendor_id; ?>" class="tableicons">
                          <i class="fa fa-pencil"></i></a>&nbsp;&nbsp;
                          <!--<i class="fa fa-trash deletevendor" data-id="<?=$vendors->vendor_id; ?>"></i>
                            &nbsp;&nbsp;
                          <a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceList?id=<?=$vendors->vendor_id; ?>" class="tableicons">
                          <i class="fa fa-list" title="Vendors Invoice list"></i></a>&nbsp;&nbsp;-->
                  </td>
                </tr>
                <?php 
                $i++;
                } ?>
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>