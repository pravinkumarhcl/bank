<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title; ?> Customer
		 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customers</a></li>
        <li class="active"><?=$title; ?> Customer</li>
      </ol>
	 
    </section>  
    
<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
          <!--  <div class="box-header">
              <h3 class="box-title"><?=$vendordetails->vendor_name;?> Invoice List</h3>
				 <section class="content-header">
					<h1>
						<?=$vendordetails->vendor_name;?> Invoice List
						<small></small>
					</h1>
					<ol class="breadcrumb">
						<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="#">Invoice List</a></li>
						<li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
					</ol>
				</section>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
		<table class="table table-bordered" id="posts">
		<thead>
		   <th>invoice_id</th>
		   <th>invoice_beneficiary_name</th>
		   <th>invoice_beneficiary_number</th>
		   <th>invoice_number</th>
		   <th>invoice_amount</th>
		   <th>invoice_topaid</th>
		   <th>invoice_net</th>
		   <th>invoice_status</th>
		</thead>				
		</table>
          </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>  

<script>
    $(document).ready(function () {
        $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getData",
		     "dataType": "json",
		     "type": "POST",
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
	    "columns": [
		          { "data": "invoice_id" },
		          { "data": "invoice_beneficiary_name" },
		          { "data": "invoice_beneficiary_number" },
		          { "data": "invoice_number" },
		          { "data": "invoice_amount" },
		          { "data": "invoice_topaid" },
		          { "data": "invoice_net" },
		          { "data": "invoice_status" },
		       ]	 

	    });
    });
</script> 