<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$vendordetails->vendor_name;?> Invoice List
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">Invoice List</a></li>
        <li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?=$vendordetails->vendor_name;?> Invoice List</h3>
            </div>
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?=ADMINBASEURL;?>/bankadmin/Invoicestatusupdate" method="POST">
                  <input type="hidden" name="vendor_id" value="<?=$vendor_id;?>" />
              
                <table id="example2" class="table table-bordered table-hover" style="width:100%">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Invoice Number</th>
                    <th>Beneficiary Name</th>
                    <th>Beneficiary Number</th>
                    <!--<th>IFSC Code</th>-->
                    <th>Invoice Amount</th>
                    <th>Rate of interest</th>
                    <th>Discount</th>
					<th>Net/Gross</th>
                    <th>Amount to be paid</th>
                    <th>Invoice Date</th>
                    <th>Deduction Days</th>
                    <th>Status</th>
                    <th>Action</th>                    
                  </tr>
                  </thead>
                  <tbody>
                  
                  <?php
                  $arrayClasses = array('Paid'=>'label-success','Approved'=>'label-success','Rejected'=>'label-danger',
                    'Pending'=>'label-warning','Hold'=>'label-info','Verified'=>'label-info');
                  if(count($invoicelist)>0)
                  {
                  $i='1';
                  foreach($invoicelist as $each)
                  {?><tr>
                    <td><?=$i;?></td>
                    <td><a href="<?=ADMINBASEURL;?>bankadmin/Invoiceviewandupdate?id=<?=$each->invoice_id;?>"><?=$each->invoice_number;?></a></td>
                    <td><?=$each->invoice_beneficiary_name;?></td>
                    <td><?=$each->invoice_beneficiary_number; ?></td>
                    <!--<td><?=$each->invoice_ifsc_code; ?></td>-->
                    <td><?=number_format($each->invoice_amount,2);?></td>
                    <td><?=$each->interestRate; ?></td>
                    <td>
                    <?php 
                     if($each->invoice_net=='NET')
						{
						  $value = $each->interestRate*($each->invoice_amount*$each->invoice_deduction_days)/365;
						  $valuefin = $value/100;
						  echo number_format($valuefin,2);
						}else{
						  echo $valuefin ='0.00';
						}
                    ?>
                    </td>
					<td><?=$each->invoice_net; ?></td>
                    <td><?php
                    $sum = $each->invoice_amount-$valuefin;
                    echo number_format($sum,2);?></td>
                    <td><?=date('Y-m-d',strtotime($each->invoice_date)); ?></td>
                    <td><?=$each->invoice_deduction_days; ?></td>
                    
                    <td><span class="label <?=$arrayClasses[$each->invoice_status];?>"><?=$each->invoice_status; ?></span> </td>
                   
                    <td>
                        <?php
                        if($each->invoice_status!='Paid')
                        {?>
                            <i class="fa fa-trash invoicedelete" title="Delete" data-id="<?=$each->invoice_id; ?>"></i>
                              &nbsp;&nbsp;
                        <?php
                        }
                        else if($each->invoice_status=='Paid')
                        {?>
                            <a href="<?=ADMINBASEURL;?>/bankadmin/Invoiceviewandupdate?id=<?=$each->invoice_id;?>">
                              <i class="fa fa-eye" title="View"></i></a><?php
                        }?>
                    </td>
                  
                  </tr>
                  <?php
                  $i++;
                  }
                  }
                  ?>
                  
                  </tbody>
               </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>