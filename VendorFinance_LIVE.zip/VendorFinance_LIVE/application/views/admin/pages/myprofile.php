<div class="content-wrapper">
					   <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title; ?> My Profile
		 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"> Account</a></li>
        <li class="active"><?=$title; ?> My Profile</li>
      </ol>
	 
    </section>
	<div class="box-body"> 
	<div class="box" style="min-height: 500px;"> 
	<ul class="nav nav-tabs">
						<li class="<?php echo ($data_account!=''?$data_account:''); ?>"><a href="#tab_1" data-toggle="tab" aria-expanded="true">General Details</a></li>
						<li class="<?php echo ($data_email!=''?$data_email:''); ?>"><a href="#tab_2" data-toggle="tab" aria-expanded="false">Change Password</a></li>
 	</ul>
					<div class="tab-content customer-profile-view">
						<div class="tab-pane  <?php echo ($data_account!=''?$data_account:''); ?>" id="tab_1"> 
							 <?php
							 
								$form_attr=array(
								'name'=>'customer_basic_form', 
								'class'=>'customer_basic_form', 
							);	
							echo form_open(ADMINBASEURL.'bankadmin/myprofile',$form_attr); ?>
							 
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Name: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								<?php 
									$param_arr=array(
										'class'=>'form-control',
										'id'=>'name',
										'placeholder'=>'Name',
										);
										$name_val=(isset($_POST['name'])?set_value('name'):$user_data['user_name']);
									echo form_input('name',$name_val,$param_arr);
									echo  form_error("name");
									?> 

								</div>
							</div>
							  
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Phone Number: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'phone_number',
											'placeholder'=>'Phone Number',
											);
										$phone_number_val=(isset($_POST['phone_number'])?set_value('phone_number'):$user_data['user_phone']); 	 
										echo form_input('phone_number',$phone_number_val,$param_arr); 
										echo  form_error("phone_number");
									?>
								</div>
							</div>
						  
							
							<div class="row cust-form-group">
								<div class="col-lg-11 text-center">
									<button type="submit"   class="btn btn-success"><i class="fa fa-save"></i> Update</button>
									<a href="<?php echo ADMINBASEURL.'bankadmin/dashboard/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>

								</div>
							</div>
							
							<?php echo form_close(); ?>
						</div>
						
						
						<div class="tab-pane <?php echo ($data_email!=''?$data_email:''); ?>" id="tab_2">
							<?php if($this->session->userdata('ac_info_message')!='' && $otp_mode==''){ ?>
							<div class="alert alert-info alert-dismissible">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<small><?php echo $this->session->userdata('ac_info_message') ;	  $this->session->set_userdata('ac_info_message','');
								?></small>
							</div>
				
							<?php
								}
							$form_attr=array(
							'name'=>'customer_account_form', 
							'class'=>'customer_account_form', 
							
							);
							if($otp_mode!=''){
								$form_attr['class']='customer_account_form hidden';
							}
							echo form_open(ADMINBASEURL.'bankadmin/myprofile',$form_attr); ?>
							
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Email Address: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
									<?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'email',
											'placeholder'=>'Email Address',
											'readonly'=>'readonly',
											);
											$name_val=(isset($_POST['email'])?set_value('email'):$user_data['user_login_name']);
										echo form_input('email',$name_val,$param_arr);
										echo  form_error("email");
									?>
								</div>
							</div>
				
							<div class="row cust-form-group">
								<div class="col-lg-offset-2 col-lg-2 col-sm-4 text-right">
									<label>Current Password: </label>
								</div>
								<div class="col-lg-3 col-sm-6 text-left">
								  <?php 
										$param_arr=array(
											'class'=>'form-control',
											'id'=>'password',
											'placeholder'=>'Password',
											);
											
											$company_val=(isset($_POST['password'])?'':'');

										echo form_password('password',$company_val,$param_arr); 
										echo  form_error("password");
									?>
								</div>
							</div>	 
				
							<div class="row cust-form-group">
								<div class="col-lg-11 text-center">
								<button type="submit"   class="btn btn-success"><i class="fa fa-send"></i> Send Reset Link</button>
									<a href="<?php echo ADMINBASEURL.'bankadmin/dashboard/' ?>" class="btn btn-warning"><i class="fa fa-times"></i> Cancel</a>
									
								</div>
							</div>
							<?php echo form_close(); ?>
				
							 
						</div>
					
				
			 
			</div>
</div>
</div>
</div>
			<!-- page end-->