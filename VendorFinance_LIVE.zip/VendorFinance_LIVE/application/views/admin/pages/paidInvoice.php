<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
		<h1>
			<?=$vendordetails->vendor_name;?> Invoice List
			<small></small>
		</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">Invoice List</a></li>
			<li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
		</ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
          <!--  <div class="box-header">
              <h3 class="box-title"><?=$vendordetails->vendor_name;?> Invoice List</h3>
				 <section class="content-header">
					<h1>
						<?=$vendordetails->vendor_name;?> Invoice List
						<small></small>
					</h1>
					<ol class="breadcrumb">
						<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="#">Invoice List</a></li>
						<li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
					</ol>
				</section>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="posts_val">
						<thead>
							<tr>
								<th class="center">S.No</th>
								<th class="center">Transaction ID</th>
								<th class="center">Beneficiary Name</th>
								<th class="center">Beneficiary Number</th>
								<!--<th class="center">IFSC Code</th>-->
								<th class="center">Amount paid</th>
								<th class="center">Paid Date</th>
								<th class="center">Status</th>
							</tr>
						</thead>
					</table>
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
<script>
 
    $(document).ready(function () {
        $('#posts_val').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
				"url": "<?php echo ADMINBASEURL; ?>bankadmin/getPaidInvoices",
				"dataType": "json",
				"type": "POST",
				"dataSrc": function ( json ) {
					//Make your callback here.
					return json.data;
				}, 
				"data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }               
			},
			"columns": [
				{ "data": "invoice_id", className: "center" },
				{ "data": "invoice_transactionid", className: "left" },
				{ "data": "invoice_beneficiary_name", className: "left" },
				{ "data": "invoice_beneficiary_number", className: "left" },
				{ "data": "invoice_topaid", className: "right" },
				{ "data": "payment_datetime", className: "center" },
				{ "data": "status", className: "center" },
				
			]	 
	    });
    });
	
</script> 