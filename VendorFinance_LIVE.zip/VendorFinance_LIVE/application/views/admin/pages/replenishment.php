<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Replenishment
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Replenishment</a></li>
      </ol>
    </section>
           
    <!-- Main content -->
    <section class="content">
      <div class="row">          
       <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
         <!--   <div class="box-header with-border">
              <h3 class="box-title">Replenishment</h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
			<?php if($this->session->flashdata('Error')):?>
            <div class="alert alert-success">
                <p><b>Error!</b> <?=$this->session->flashdata('Error'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <?php $CustomerData=$this->session->userdata("CustomerData");	 ?>
            <!-- form start -->
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>bankadmin/replenishmentVerification">
              <input type="hidden" name="cust_id" value="<?=$this->encryption->encrypt($CustomerData['cust_id']);?>" />
     
              <div class="box-body">
                <div class="form-group">
                  <label>Customer Name</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="cust_name" readonly value="<?php echo $CustomerData['cust_name'].' ('.$CustomerData['cust_user_code'].')'; ?>" placeholder="Customer Name" type="text"><?= form_error("cust_name")?>
                  </div>
                </div>
                 <!-- id="tags" -->
                <div class="form-group">
                  <label>Amount deposited</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="amount" value="<?=$repay->amount;?>" placeholder="Amount Deposited" type="text"><?= form_error("amount")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Transaction reference</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="transaction_number" value="<?=$repay->transaction_number;?>" placeholder="Transaction Reference" type="text"><?= form_error("transaction_number")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Cheque date</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="date_created" id="datepicker_new" value="<?=$repay->date_created;?>" placeholder="Date of Transaction" type="text"><?= form_error("date_created")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Cheque drawn on bank</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="drawn_bank" value="<?=$repay->drawn_bank;?>" placeholder="Cheque drawn on bank" type="text"><?= form_error("drawn_bank")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Transaction remarks</label>
                  <div class="form-group-inner">
                  <input class="form-control text-right" name="transition_remarks" value="<?=$repay->transition_remarks;?>" placeholder="Transaction Remarks" type="text"><?= form_error("transition_remarks")?>
                  </div>
                </div>
                  
                  
              </div>
              
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="pull-right btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          
        </div>
       
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>