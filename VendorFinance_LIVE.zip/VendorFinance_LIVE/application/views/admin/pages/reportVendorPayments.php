	<!--main content start-->
	
	<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Vendor Payments Report
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=ADMINBASEURL;?>bankadmin"><i class="fa fa-dashboard"></i> Home</a></li>
         <li>Vendor Payments Report</li>        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">          
            <!-- /.box-header -->
            <div class="box-body">			
				<form class="form-inline" method="POST" action=""><!-- form-search -->
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo ($filter_from!=''?date('d-m-Y',strtotime($filter_from)):''); ?>"  name="filter_from" id="from_date" placeholder="From Date">
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo ($filter_to!=''?date('d-m-Y',strtotime($filter_to)):''); ?>" name="filter_to" id="to_date" placeholder="To Date">
						</div>
					</div>	
					<div class="form-group">
						&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary">Submit</button>
						&nbsp;&nbsp;&nbsp;<button type="submit" name='reset' class="btn btn-primary">Reset</button>
					</div>
				</form>
				<!-- Report Download Excel
				<form class="form-inline" id="downloads" method ="POST" action="<?=ADMINBASEURL;?>bankadmin/cust_reportexc">
				<hr>
					<div class="form-group" style="float:right;">
						<button type="hidden" name='cust_download' class="btn btn-primary"><i class="fa fa-download">&nbsp;</i>
							<span> Download</span>
						</button>
					</div>
				</form>	-->
				<!--Report Download ends-->
              <table id="example2" class="table table-bordered table-hover table-striped" style="width:100%" style="width:100%">
                <thead>
                  <tr>
                   <th class="text-center">Sl.No</th> 
								<th class="text-center">Vendor Name</th> 
								<th class="text-center">No.Of Invoices</th> 
								<th class="text-center">Total Invoice Amount</th>
								<th class="text-center">Total Discount</th>  
								<th class="text-center">Net Paid</th>  
								<th class="text-center hidden">Gross Settled</th>  
								<th class="text-center hidden">Balance Due</th>  
								<th class="text-center">Action </th>
									                                
                  </tr>
                  </thead>
                  <tbody>        
					<?php
								foreach($invoice_data as $each)
							{?>
								<tr>
									<td class="text-center"><?php echo $i=$i+1; ?></td> 
									<td><?php echo  $each['invoice_beneficiary_name'] ; ?></td> 
									<td class="text-center"><?php echo  $each['total_invoice'] ; ?></td>
									<td class="text-right"><?php echo  number_format($each['totl_amount'],2) ; ?></td>
									<td class="text-right"><?php echo   number_format($each['invoice_discount'],2) ; ?></td>
									<td class="text-right"><?php echo  number_format($each['invoice_topaid'],2) ; ?></td>
									<td class="text-right hidden"><?php echo  number_format(($each['invoice_topaid']+$each['invoice_discount']),2); ?></td>
									<td class="text-right hidden"><?php echo  number_format($each['totl_net_amount']-($each['invoice_topaid']+$each['invoice_discount']),2); ?></td>
									<td class="text-center"> <a  href="<?php echo CUSTOMERBASEURL."bankadmin/report_invoice_by_vendor/".base64_encode($each['invoice_beneficiary_name']); ?>"><i class="fa fa-eye"></i> Details</a> </td>
								</tr>
							<?php 
							 
							} 
							if(count($invoice_data)==0){
								?>
								<tr>
									<td colspan="11" class="text-center text-danger">No Records Found..!</td>
								</tr>
								<?php
							}
							?>
                  </tbody>
               </table>
               
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  
  
	   <!--main content end-->
	<script> 
	function check_box_selected(){
		var is_selected=false;
		 $('input[name="mark_as_paid[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				 is_selected=true;
			 } 
			
		 })
		 if(!is_selected){
			 alert('Please select atleast one checkbox');
		 }else{
			 var prompted=prompt('Please Enter the Remarks.');
			 if(!prompted){
				 return false;
			 }
			 $('#customer_remark').val(prompted);
		 }
		  return is_selected;
	}
	</script>