

<?php
	$result = $this->session->userdata('member'); 
	if(!empty($result)){ 
		$user_type =$result['user_type'];
	} 
	
  ?> 
<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <b> <?=$status;?></b> Invoice List
        <small></small>
      </h1>
	  <?php		

			$CustomerData=$this->session->userdata("CustomerData");	
		if(isset($CustomerData['cust_name']) && $CustomerData['cust_name']!='')
		{
		?>
          
		<!-- inner menu: contains the messages -->
		<div class="table-responsive">
			<table class="table table-customer-limit due_content_header">	
				<tbody>			
					<tr>
						<th>Loan Limit</th><td><?php echo $CustomerData['cust_loan_limit']; ?></td>
						<th>Balance Loan Limit</th><td><?php echo $CustomerData['cust_current_loan_balance']; ?></td>
						<th>Monthly Loan Limit</th><td><?php echo $CustomerData['cust_monthly_loan_limit']; ?></td>
						<th>Weekly Loan Limit</th><td><?php echo $CustomerData['cust_weekly_loan_limit']; ?></td>
					</tr>
				</tbody>
			</table>
        </div> 
		<?php } ?>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>       
			<li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
		</ol>
    </section>

    <!-- Main content -->
    <section class="content due_mrg">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">            
            <div id="alert_message">
				
			</div>			 
            <!-- /.box-header -->
            <div class="box-body">
            <?php 
            if($mode=='update')
            {?>  
              <form  id="invoice_form" action="<?=ADMINBASEURL;?>/bankadmin/Invoicestatusupdate" method="POST">
                <input type="hidden" name="customer_id" id="customer_id" value="<?=$customer_id;?>" />
                <input type="hidden" name="status" id="status_inv" value="<?=$this->encryption->encrypt($status);?>" />   				
				 <div style="text-align: right;padding-bottom:10px;">
               <?php 
					if($status=='Pending'){ ?>
			    <button type="button" onclick="submitform('Verified')" name="invoice_status" value="Verified" class="btn btn-success">Verify</button>			
			     <?php }
					if($status=='Verified'){ ?>
					 <?php 
		if(check_module_for_readonly($user_type,'vendorInvoiceDues')==1){ 
		 
	   ?>
				<button type="button" onclick="submitform('Approved')" name="invoice_status" value="Approved" class="btn btn-success">Approve</button>
				<?php } ?> 
			    <?php }					
					if($status=='Pending' || $status=='Verified'){ ?>
					 <?php 
			    if(check_module_for_readonly($user_type,'vendorInvoiceDues')==1){  
			?>
			
				<button type="button" onclick="check_box_selected()"  name="invoice_status" value="Rejected" class="btn btn-danger">Reject</button>
				<?php } ?> 
			    <?php }
					if($status=='Rejected'){ ?>
					 <?php 
						if(check_module_for_readonly($user_type,'vendorInvoiceDues')==1){  
					?>
				<button type="button" onclick="submitform('Pending')" name="invoice_status" value="Pending" class="btn btn-warning">Move To Pending</button> 
				<?php } ?>
				<?php } ?>
				
                </div>
              <?php } ?>
				<div class="table-responsive">
					<table class="table table-bordered" id="posts_val">
						<thead>
							<tr>
								<th class="center">S.No</th>                    
								<th class="center">Invoice Number</th>
								<th class="center">Beneficiary Name</th>
								<th class="center">Beneficiary Number</th>                   
								<th class="center">Invoice Amount</th>
								<th class="center">Rate of interest</th>         
								<th class="center">Discount Amount</th>	
								<th class="center">Net/ Gross</th>	
								<th class="center">Amount Due</th>		
								<th class="center">Invoice Date</th>
								<th class="center">Status</th>	
								<?php if($status=='Rejected'){ ?>
								 <th class="center">Remarks</th>
								<?php }	
								if($mode=='update')
								{?>                  
								<th class="center"><input type="checkbox" class="parent_class"  /></th>
								<?php }?>					
							</tr>
						</thead>
					</table>
				</div>
                <?php 
                if($mode=='update')
                {?> 
			
			  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Please enter the reason </h4>
        </div>
        <div class="modal-body">
          <textarea style="min-width: 100%" id="reject_reason" name="reject_reason"  required></textarea>
		 
        </div>
        <div class="modal-footer">
		<button type="button" onclick="submitform('Rejected')" id="submit_reason" class="btn btn-default" >Submit</button>
          <button type="button"  class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
   <input type="hidden" name="invoice_status"  id="invoice_status"/>
				
                </form>
                <?php } ?>
				
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

  <?php 

  if($mode=="update") {
	  
	   $path = ADMINBASEURL."bankadmin/getInvoiceList?mode=update&status=".$status;
  }else{
	   $path = ADMINBASEURL."bankadmin/getInvoiceList?mode=view&page=".$cpage."&number=".$number;	  
  }
  $filter_hide='10,11';
  	if($status=='Rejected'){ 
	$filter_hide='10,11,12';
	}
  if($cpage=='paid_invoices' || $cpage == 'approved_invoices')
  {
	  $filter_hide='10';
  }
 
  ?>
   <script>
 
    $(document).ready(function () {
     datatable_appointments = $('#posts_val').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo $path; ?>",
		     "dataType": "json",
		     "type": "POST",
			 "dataSrc": function ( json ) {
                //Make your callback here.
				
          	
                return json.data;
			
            }, 
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   
				},

				

				"columnDefs": [ {
				"targets": [10,11,12],
				"orderable": false
				} ],

				"columnDefs": [ {
				"targets": [<?php echo $filter_hide; ?>],
				"orderable": false
				} ],

	    "columns": [
		         
					{ "data": "invoice_id", className: "center" },
					{ "data": "invoice_number", className: "left" },
					{ "data": "invoice_beneficiary_name", className: "left" },
					{ "data": "invoice_beneficiary_number", className: "left" },
					{ "data": "invoice_amount", className: "right" },
					{ "data": "interest_rate", className: "center" },
					{ "data": "discount_amount", className: "right" },
					{ "data": "invoice_net", className: "center" },	
					{ "data": "amount_due", className: "right" },
					{ "data": "invoice_date", className: "center" },
					{ "data": "invoice_status", className: "center" },
					<?php if($status == 'Rejected'){ ?>
					{ "data": "reject_reason", className: "center" },
					<?php }?>
					 <?php	
					if($mode=='update')
                    {?> 
					{ "data": "invoice_select", className: "center" },
					<?php } ?>
		       ]	 

	    });
		
	 
    });
	
</script> 
  <script> 
	function check_box_selected(){
		var is_selected=false;
		 $('input[name="invoice_id[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				 is_selected=true;
			 } 
			
		 })
		 if(!is_selected){
			 alert('Please select atleast one checkbox');
		 }else{
			
			$('#myModal').modal('show');
			$('#invoice_status').val('Rejected');

		 }		 
		  
	}
	
	function submitform(status){
		
		var is_selected=false;
		 $('input[name="invoice_id[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				 is_selected=true;
			 } 
			
		 })
		 if(!is_selected){
			 alert('Please select atleast one checkbox');
		 }else{
			
			$("#bg_model").fadeIn();
		var invoice_id = [];
		 $('input[name="invoice_id[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				invoice_id.push($(this).val());	
			 } 			
		 })		
		var customer_id=$("#customer_id").val();
		
		var status_inv=$("#status_inv").val();
		var invoice_status=status;
		var reject_reason='';
		
		if(invoice_status=='Rejected')
		{
			$('#myModal').modal('hide');
			reject_reason=$("#reject_reason").val();
			invoice_status='Rejected';
		}	
		
		
		$.ajax({
				method:'POST',
				data:{'invoice_status':invoice_status,'invoice_id':invoice_id,'status':status_inv,'customer_id':customer_id,'reject_reason':reject_reason},
				url: baseurl+'bankadmin/Invoicestatusupdate',
				success:function(data){						
					var json = $.parseJSON(data);		
		
					if(json['message']=='1')
					{
						var data_show='<div class="alert alert-success">   <p><b>Success!</b> '+json['data']+' </p>  </div>';
					}else{
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
					}
					$("#alert_message").html(data_show);
					
					datatable_appointments.ajax.reload( null, false );					

					$("#bg_model").fadeOut();
					var elements = document.getElementsByTagName("INPUT")
					for (var i = 0; i < elements.length; i++) {
					    if(elements[i].type === "checkbox") {
					        elements[i].checked = false;
					    }
					}

					/* var elements = document.getElementsByTagName("INPUT");
						for (var inp of elements) {
							if (inp.type === "checkbox")
								inp.checked = false;
						}*/
				}
			});	
		 }		 
		
      }
	
	</script>
	