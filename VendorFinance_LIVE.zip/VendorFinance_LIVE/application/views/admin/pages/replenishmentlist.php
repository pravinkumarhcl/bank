<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of replenishments
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customers</a></li>
        <li class="active">List of replenishments</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title">List of replenishments</h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
				<div>
				<a class="btn btn-primary pull-right" style="padding-bottom:10px;" href="<?=ADMINBASEURL;?>bankadmin/replenishment"><i class="fa fa-plus"></i> Add Fund</a>
				</div>
				<div class="clearfix"></div>
				<div class="table-responsive">
               <table class="table table-bordered" id="posts">
                <thead>
                <tr>
                  <th class="center">S.No</th>
                  <th class="center">Customer Name</th>
                  <th class="center">Transaction Number</th>
                  <th class="center">Amount</th>
                  <th class="center">Cheque drawn on bank</th>
                  <th class="center">Cheque Date</th>
                  <th class="center">Action</th>
                </tr>
                </thead>
              
               </table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
   <script>
 
    $(document).ready(function () {
        $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getReplenishmentListJson",
		     "dataType": "json",
		     "type": "POST",
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
	    "columns": [
		         
					{ "data": "id", className: "center" },
					{ "data": "cust_name", className: "left" },
					{ "data": "transaction_number", className: "left" },
					{ "data": "amount", className: "right" },
					{ "data": "drawn_bank", className: "right" },
					{ "data": "date", className: "center" },
					{ "data": "delete", className: "center" },
				]	 

	    });
		
	 
    });
	
</script> 
  
    