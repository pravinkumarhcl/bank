<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <b><?php echo $vendor_deails['0']['vendor_name']; ?></b> Invoice Report
        <small></small>
      </h1>
     <ol class="breadcrumb">
		 <li><a href="<?=ADMINBASEURL;?>bankadmin"><i class="fa fa-dashboard"></i>Home</a></li>
		 <li><a href="<?=ADMINBASEURL;?>bankadmin/customerBasedReport">Customer Report</a></li>
         <li><a href="<?=ADMINBASEURL;?>bankadmin/vendorBasedReport/<?php echo $vendor_deails['0']['cust_id']; ?>"><?php echo $vendor_deails['0']['cust_name']; ?></a></li>        
         <li><?php echo $vendor_deails['0']['vendor_name']; ?></li>		 
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
                       
              
            <!-- /.box-header -->
            <div class="box-body">
          <form class="form-inline " method="POST" action=""><!--form-search-->
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo $filter_from; ?>"  name="filter_from" id="from_date" placeholder="From Date">
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control" value="<?php echo $filter_to; ?>" name="filter_to" id="to_date" placeholder="To Date">
						</div>
					</div>	
					<div class="form-group">
						&nbsp;&nbsp;&nbsp;<button id="search" type="button" class="btn btn-primary">Submit</button>
						
						&nbsp;&nbsp;&nbsp;<button type="submit" name='reset' class="btn btn-primary">Reset</button>
					</div>	
				</form>
				<hr />
				<!-- Report Download Excel
				<form class="form-inline" id="downloads" method ="POST" action="<?=ADMINBASEURL;?>bankadmin/invoice_reportexc">
					<div class="form-group" style="float:right;">
						<input type="hidden" name='vendor_id' value="<?php echo $vendor_id; ?>" />						
						<button type="submit" name='invoice_download' class="btn btn-primary"><i class="fa fa-download">&nbsp;</i>
							<span> Download</span></button>
					</div>
				</form>	-->
				<!--Report Download ends-->
				
				 <table id="excel_report" class="table table-bordered posts" >
             
                <thead>
				
                  <tr>
				  
                    <th class="text-center">S.NO</th>
                  
                    <th class="text-center">Beneficiary Name</th>
                    <th class="text-center">Beneficiary Number</th>
                    <th class="text-center">IFSC Code</th>
					<th class="text-center">Transaction ID</th>
					<th class="text-center">Invoice Number</th>
					<th class="text-center">Invoice Amt</th>
					<th class="text-center">Discount</th>					
                    <th class="text-center">To Paid Amt</th>                   
                    <th class="text-center">Deduction Days</th>                                      
                    <th class="text-center">Net/Gross</th>                                      
                    <th class="text-center">Status</th>                                      
                  </tr>
                  </thead>
                  <tbody>        
					<?php
					$i=1;
					foreach($invoiceReport AS $data) { ?>
					<tr>
						<td class="text-center"><?php echo $i; ?></td>
						
						<td><?php echo $data['invoice_beneficiary_name']; ?></td>
						<td><?php echo $data['invoice_beneficiary_number']; ?></td>
						<td><?php echo $data['invoice_ifsc_code']; ?></td>
						<td><?php echo $data['invoice_transactionid']; ?></td>
						<td><?php echo $data['invoice_number']; ?></td>
						<td><?php echo $data['invoice_amount']; ?></td>
						<td class="text-right"><?php echo $data['invoice_discount']; ?></td>											
						<td class="text-right"><?php echo number_format($data['invoice_topaid']); ?></td>											
						<td class="text-right"><?php echo $data['invoice_deduction_days']; ?></td>									
						<td class="text-right"><?php echo $data['invoice_net']; ?></td>												
						<td class="text-center"><?php echo $data['invoice_status']; ?></td>												
					</tr>
					<?php $i++; } ?>
                  </tbody>
               </table>
               
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <script>
 
    $(document).ready(function () {
		var from_date = $('#from_date').val();
		var to_date = $('#to_date').val();
         datatable_appointments = $('#excel_report').DataTable({
			
			dom: '<"vtop">ltBrtlf<<t>ip>',
			
			buttons: [
			{ extend: 'excel', text: 'Export Excel' }],
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getInvoiceBasedReportJson?vendor_id=<?php echo $vendor_id;?>",
		     "dataType": "json",
		     "type": "POST",
			 "dataSrc": function ( json ) {       
$('.vtop').html(json.vendor_details);			 
				
					
					
                return json.data;
            }, 
		    data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				}
		                   },
	    "columns": [
		         
						{ "data": "invoice_id" },
						{ "data": "invoice_beneficiary_name" },
						{ "data": "invoice_beneficiary_number" },
						{ "data": "invoice_ifsc_code" },
						{ "data": "invoice_transactionid" },
						{ "data": "invoice_number" },
						{ "data": "invoice_amount" },
						{ "data": "invoice_discount" },
						{ "data": "invoice_topaid" },
						{ "data": "invoice_deduction_days" },
						{ "data": "invoice_net" },
						{ "data": "invoice_status" },
		         
		       ]	 

	    });
			 $('#search').click(function(){		
		datatable_appointments.ajax.reload();		
	
		});
		
    });
	
</script> 