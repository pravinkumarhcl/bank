<div class="content-wrapper" style="min-height: 946.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        General Site 
        <small>Settings</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">General Settings</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
           <!-- <div class="box-header with-border">
              <h3 class="box-title">Site Settings</h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>bankadmin/metafunction">
              <div class="box-body">
                <div class="form-group">
                  <label>Site Name</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="site_name" value="<?=$siteSettings->site_name;?>" placeholder="Site Name" type="text"><?= form_error("site_name")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Site url</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="site_url" value="<?=$siteSettings->site_url;?>" placeholder="Site url" type="text"><?= form_error("site_url")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Meta Title</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="meta_title" value="<?=$siteSettings->meta_title;?>" placeholder="Meta Title" type="text"><?= form_error("meta_title")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Meta Description</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="meta_description" value="<?=$siteSettings->meta_description;?>" placeholder="Meta Description" type="text"><?= form_error("meta_description")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Meta Keywords</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="meta_keywords" value="<?=$siteSettings->meta_keywords;?>" placeholder="Meta Keywords" type="text"><?= form_error("meta_keywords")?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>Copy Rights</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="copy_rights" value="<?=$siteSettings->copy_rights;?>" placeholder="Copy Rights" type="text"><?= form_error("copy_rights")?>
                  </div>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          
        </div>
        <!--/.col (left) -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>