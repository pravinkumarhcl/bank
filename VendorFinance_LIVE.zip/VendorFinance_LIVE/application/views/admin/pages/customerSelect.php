<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Customer Selection
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><a href="#">Customer Selection </a></li>
      </ol>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover table-striped" style="width:100%">
                <thead>
                  <tr>
                    <th class="text-center">S.NO</th>
					<th class="text-center">Customer Code</th>	              
                    <th class="text-center">Customer Company</th>				                                     
                    <th class="text-center">Action</th>                                      
                  </tr>
                  </thead>
                  <tbody>        
					<?php
					$i=1;
					//echo $active_cust_id;
					foreach($customer_list AS $data) { ?>
					<tr>
						<td class="text-center"><?php echo $i; ?></td>						
						<td><?php echo $data['cust_user_code']; ?></td>
						<td><?php echo $data['cust_name']; ?></td>
						<td class="text-center">
						<?php if($active_cust_id==$data['cust_id']){
							echo '<span class="text-success">Active</span>';
						}else{ ?>
						<a  class="btn btn-primary btn-xs" href="<?=ADMINBASEURL;?>/bankadmin/activateCustomer?cust_id=<?php echo $this->encryption->encrypt($data['cust_id']); ?>">Select</a>
						<?php } ?>
						</td>																
					</tr>
					<?php $i++; } ?>
                  </tbody>
               </table>
               
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>