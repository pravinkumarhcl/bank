<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Activity Log
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
        <li class="active"> Activity Log </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           <?php if($this->session->flashdata('error')):?>
            <div class="alert alert-error">
                <p><b>Error!</b> <?=$this->session->flashdata('error'); ?></p>
            </div>
            <?php endif;?> 
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
			<form class="form-inline" method="POST" action="" id="search_log_form" autocomplete="off"><!-- form-search-->
				<input type="hidden" name='cust_id' id="cust_id" value="<?php echo $cust_id;?>"/>
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
						<div class="col-sm-8">
							<input type="text" required autocomplete="off" class="form-control" value="<?php echo $filter_from;?>"  name="filter_from" id="from_date" placeholder="From Date">
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control"  autocomplete="off" value="<?php echo $filter_to;?>" 
							name="filter_to" id="to_date" placeholder="To Date">
						</div>
					</div>	
					<div class="form-group">
						&nbsp;&nbsp;&nbsp;<button type="submit" id="search_logs" class="btn btn-primary">Submit</button>
						&nbsp;&nbsp;&nbsp;<button type="button" id="reset" name='reset' class="btn btn-primary">Reset</button>
					</div>	
				</form>
				<hr />
              <table id="example2" class="table table-bordered table-hover table-striped" style="width:100%">
                <thead>
                <tr>
                  <th class="text-center">S.No</th>
                  <th class="text-center">Modified By</th>
                  <th class="text-center">Module</th>
                  <th class="text-center">Description</th>
                  <th class="text-center">Date Updated</th>
                </tr>
                </thead>
                <tbody>
                <?php
				 $i=1; 
				  $logdetails = array_reverse($logdetails);
				  
				    foreach($logdetails as $key=>$file) {
				
						$file_month = substr($file, -9, 2);
						if($file_month == date("m")){
						$handle = fopen("application/logs/".$file, "r");					
						if ($handle) {
							
						while (($line = fgets($handle)) !== false) {					
								$keywords = preg_split("/[\$]+/", $line);						
								?>
								<tr>
								  <td class="text-center"><?=$i; ?></td>
								  <td><?=ucfirst($keywords[0]); ?></td>
								  <td  ><?=ucfirst(str_replace('_',' ',$keywords[2])); ?></td>
								  <td style="width:40%;"><?=ucfirst($keywords[1]); ?></td>
								  <td class="text-center"><?=$keywords[3]; ?></td>
								</tr>
								<?php
								   $i++;
						}

						fclose($handle);
						} else {
						// error opening the file.
						} 
						}
					}
               ?>
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <script>
  
  $('#search_logs').click(function(){
	  var filter_from = $("#from_date").val();
	  var filter_to = $("#to_date").val();	
	 $.ajax({
				method:'POST',
				data:{'filter_from':filter_from,'filter_to':filter_to},
				url: baseurl+'bankadmin/validateDates',
				success:function(data){						
					var json = $.parseJSON(data);		
					
					if(json['message']=='0')
					{
					
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
						$("#alert_message").html(data_show);
					}
					else{
					$("#alert_message").html("");

					}					
					$("#search_log_form").submit();				

					
				}
			});
  });
  
  $('#reset').click(function(){
	$("#from_date").val("");  
	$("#to_date").val("");
  });
  </script>