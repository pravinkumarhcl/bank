<?php
	$result = $this->session->userdata('member'); 
	if(!empty($result)){ 
		$user_type =$result['user_type'];
	} 
  ?> 
<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <b>Approved</b> Invoice List 
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">Invoice List</a></li>
        <li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title"><?=$vendordetails->vendor_name;?> Invoice List</h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
				<div class="text-right" style="padding: 10px;">
			   	<?php 
				if(check_module_for_readonly($user_type,'ApprovedInvoice')==1){ 
		 
				?>
				<a href="<?=ADMINBASEURL;?>bankadmin/approvedNEFT">
					&nbsp;<button type="button" class="btn btn-success btn-md">NEFT</button>
				</a>
					<?php } ?>
				</div>
				<div class="table-responsive">
					<table class="table table-bordered" id="posts_val">
						<thead>
							<tr>
								<th class="center">S.No</th>
								<th class="center">Beneficiary Name</th>
								<th class="center">Beneficiary Number</th>
								<!--<th class="center">IFSC Code</th>-->
								<th class="center">Invoice Amount</th>
								<th class="center">Rate of interest</th>
								<th class="center">Discount</th>
								<th class="center">Amount to be paid</th>
								<th class="center">Invoice Date</th>
								<th class="center">Status</th>
							</tr>
						</thead>
					</table>
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
<script>
 
    $(document).ready(function () {
        $('#posts_val').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
				"url": "<?php echo ADMINBASEURL; ?>bankadmin/getApprovedInvoiceList",
				"dataType": "json",
				"type": "POST",
				"dataSrc": function ( json ) {
					//Make your callback here.
					return json.data;
				}, 
				"data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
			},
			"columns": [
				{ "data": "invoice_id", className: "center" },
				{ "data": "invoice_beneficiary_name", className: "left" },
				{ "data": "invoice_beneficiary_number", className: "left" },
				{ "data": "invoice_amount", className: "right" },
				{ "data": "rate_of_interest", className: "center" },
				{ "data": "invoice_discount", className: "right" },
				{ "data": "invoice_topaid", className: "right" },
				{ "data": "invoice_date", className: "center" },
				{ "data": "status", className: "center" },
			]
	    });	 
    });
	
</script> 