<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Customer Invoice List
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customers</a></li>
        <li class="active">Customer Invoice list</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Customer Invoice list</h3>
            </div>
            </br>
			<?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <?php if($this->session->flashdata('invoice_import_error')):
			?>
            <div class="alert alert-danger">
                <p><?=$this->session->flashdata('invoice_import_error'); ?></p>
            </div>
            <?php endif;?>  
            <div class="alert alert-danger error_invoice_updates" style="display:none;">
                <p><b>Error!</b>Atleast check one customer invoice checkbox.</p>
            </div>
            <div id="loadingDiv">
				<div>
					<h7>Please wait...</h7>
				</div>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
			<form name="frm_customer_invoice" id="frm_customer_invoice" method="post" action="">
			  <input type="hidden" name ="invoices_ids" id="invoices_ids" value="" />  
              <div class="pull-right">
               <a href="javascript:void(0);">
                   <button type="submit" class="btn btn-primary btn-sm btn-flat update_Coustomer_Invoice" >Process Invoice</button>
               </a>
              </div>
             </form>  
           
              <table id="example2" class="table table-bordered table-hover" style="width:100%">
                <thead>
                <tr>
                  <th class="text-center">S.No</th>
				  <th class="text-center">Customer Name</th>
                  <th class="text-center">Invoice File</th>
				  <th class="text-center">Date of Upload</th>  
                  <th>Action</th>
				   <th><input type="checkbox" name="comm_job_shedule" id="comm_job_shedule" value=""/> &nbsp; &nbsp; &nbsp;  Select</th>
                </tr>
                </thead>
                <tbody>
                <?php
				
				$i=0;
				$j=0;
                foreach($invoiceFile as $key_data => $cusfiles){ 
					 
					?>
					
				<?php //echo $cusID; print_r($files); ?>
                <tr>
                  <td class="text-center"><?=$j+1; ?></td>
				  <td><?php echo $cusfiles['cust_name'].'('.$cusfiles['cust_user_code'].')'; ?></td>
				  <td><?php echo $cusfiles['filename']; ?></td>
				  <td><?php echo date('d-m-Y H:i:s',strtotime($cusfiles['date'])); ?></td>
				  <td><a class="btn btn-primary btn-sm btn-flat" href="<?php echo CUSTOMERBASEURL.'bankadmin/download_invoice/'.base64_encode($cusfiles['id']); ?>">Download</a></td>
				  <td class="text-center"><input onclick='select_my_records()' type="checkbox" name="job_shedule" id="job_shedule<?=$i; ?>" class="customer_invoice_ids" value="<?php echo $cusfiles['id']; ?>"/> &nbsp; &nbsp; &nbsp;
				  <!--<img style="display:none;" src="<?=ADMINBASEURL;?>media/images/progress-bar-gif-11.gif" width="100" height="55" alt="Progres Bar" class="loading_files">-->
				  </td>
				   
				</tr>  
				<?php 
                $i++;
				$j++;
					  } ?>
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>