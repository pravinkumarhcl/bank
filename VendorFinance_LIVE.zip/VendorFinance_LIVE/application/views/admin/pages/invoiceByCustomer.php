<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <b> <?=$status;?></b> Invoice List By Customer
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">Invoice List</a></li>
        <li class="active"><?=$vendordetails->vendor_name;?> Invoice List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title"><?=$vendordetails->vendor_name;?> Invoice List</h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <?php if($this->session->flashdata('Error')):?>
            <div class="alert alert-danger">
                <p><?=$this->session->flashdata('Error'); ?></p>
            </div>
            <?php endif;?>  
            <!-- /.box-header -->
            <div class="box-body">
           
              <table id="example2" class="table table-bordered table-hover table-striped" style="width:100%" style="width:100%">
                <thead>
                  <tr>
                    <th class="text-center">S.No</th>
                    <th class="text-center">Customer Name</th>
                    <th class="text-center">Customer Code</th>
                    <th class="text-center">MCLR</th>
                    <th class="text-center">Weekly Limit</th>                    
                    <th class="text-center">Monthly Limit</th>
                    <th class="text-center">Balance Loan Amount</th>
                    <th class="text-center">To Be Paid</th>
					<th class="text-center">No Of Invoice</th>                                      
                  </tr>
                  </thead>
                  <tbody>                  
					<?php
						$i=1;
						foreach($customerInvoice AS $each)
						{
					?>
					<tr>
						<td class="text-center"><?php echo $i; ?></td>
						<td class="text-center"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceDues?status=<?php echo $this->encryption->encrypt($status); ?>&id=<?php echo $this->encryption->encrypt($each['cust_id']); ?>"><?php echo $each['cust_name']; ?></a></td>
						<td class="text-center"><?php echo $each['cust_code']; ?></td>
						<td class="text-center"><?php echo $each['cust_mclr']; ?></td>
						<td class="text-center"><?php echo $each['cust_weekly_loan_limit']; ?></td>
						<td class="text-center"><?php echo $each['cust_monthly_loan_limit']; ?></td>
						<td class="text-center"><?php echo $each['cust_current_loan_balance']; ?></td>
						<td class="text-center"><?php echo $each['to_be_paid']; ?></td>
						<td class="text-center"><?php echo $each['no_of_invoice']; ?></td>
					</tr>
					<?php
						}
						$i++;
					if(count($customerInvoice)==0){ ?>
						<tr>
							<td colspan="13" class="text-center text-danger">No Invoices Found..!</td>
						</tr>
					<?php
					}
					?>
                  </tbody>
               </table>
               
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>