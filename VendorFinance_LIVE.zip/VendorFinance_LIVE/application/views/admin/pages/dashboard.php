<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
	<form class="form-inline" method="POST" action="">
	
    <div class="form-group">   
		<h4><b>Dashboard</b>
			
		</h4>
      </div>
	<?php
		if($filter_to=='')
		{
			$filter_to=date("d-m-Y");
		}
		if($filter_from=='')
		{
			$year=date("Y");
			$month=date("m");
			if($month<4)
			{
				$year=$year-1;
			}
			$filter_from='01'.'-04-'.$year;
		}
	?>
	 <?php

	 if($this->session->flashdata('error')):?>
            <div class="alert alert-error">
                <p><b>Error!</b> <?=$this->session->flashdata('error'); ?></p>
            </div>
            <?php endif;?> 
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
	<div class="form-group">
		<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
		<div class="col-sm-8">
			<input type="text" required class="form-control" value="<?php echo $filter_from; ?>"  name="filter_from" id="dash_from_date" placeholder="From Date">
		</div>
	</div>	
	<div class="form-group">
		<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
		<div class="col-sm-8">
			<input type="text" required class="form-control" value="<?php echo $filter_to; ?>" name="filter_to" id="dash_to_date" placeholder="To Date">
		</div>
	</div>	
	<div class="form-group">
		&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary">Submit</button>
		&nbsp;&nbsp;&nbsp;<button type="button" id="reset" name='reset' class="btn btn-primary">Reset</button>
	</div>	
	</form>
    </section>

    <!-- Main content -->
    <section class="content">     
      <!-- Main row --> 
	  <?php $CustomerData=$this->session->userdata("CustomerData");	
		 
		if(isset($CustomerData['cust_name']) && $CustomerData['cust_name']!='')
		{
					$loan_balance  = filter_var($CustomerData['cust_current_loan_balance'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$replenished  = filter_var($CustomerData['cust_replenishment'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_balance =  $loan_balance+$replenished;

					$monthly_paid_loan  = filter_var($CustomerData['monthlyPainIvoice'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$cust_monthly_loan_limit  = filter_var($CustomerData['cust_monthly_loan_limit'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_month_balance =  $cust_monthly_loan_limit-$monthly_paid_loan;

					$weekly_paid_loan  = filter_var($CustomerData['weeklyPainIvoice'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
					$cust_weekly_loan_limit  = filter_var($CustomerData['cust_weekly_loan_limit'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

					$total_weekly_balance =  $cust_weekly_loan_limit-$weekly_paid_loan;
	 
				
	  ?>
	  <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
			<!-- MAP & BOX PANE -->
			<!-- TABLE: LATEST ORDERS -->
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Customer Information</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
						<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
					</div>
				</div>
				<!-- /.box-header -->
				<div class="box-body ">
			<div class="table-responsive">					
					
			<div class="col-md-8">
				<?php
			
							if($CustomerData['cust_type']=="parent"){ 
							
							?>
							<div class="row">
							<table class="table table-bordered table-hover "> 
									<tbody>
										<tr>
											<td class="text-center bg_lite3" colspan="5"><b>Loan Limit Info</b></td>
										</tr>
										<tr>
											<td class="text-center bg_lite3"></td>
											<td class="text-center bg_lite3">WEEKLY</td>
											<td class="text-center bg_lite3">MONTHLY</td>
											<td class="text-center bg_lite3"><?php echo $CustomerData['cust_mclr']; ?> MCLR</td> 
										</tr> 
										<tr>
											<td class="text-center bg_lite3">LIMIT</td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_weekly_loan_limit']; ?></b></td>
											<td class=" bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_monthly_loan_limit']; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_limit']; ?></b></td> 
										</tr> 
											<tr>
											<td class="text-center bg_lite3">USED</td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo number_format($CustomerData['weeklyPainIvoice'],2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo number_format($CustomerData['monthlyPainIvoice'],2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_used']; ?></b></td> 
										</tr> 
										<!-- <tr>
											<td class="text-center bg_lite3">USED SUB</td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_weeklyPainIvoice,2) ; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_monthlyPainIvoice,2) ; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_cust_loan_used,2) ; ?></b></td> 
										</tr> -->
									<tr>
										<td class="text-center bg_lite3">REPLENISHED</td>
										<td class="bg_lite3 text-right"><b>&nbsp;&nbsp;
										</b>								
										</td>
										<td class="bg_lite3 text-right"><b>&nbsp;&nbsp;
										</b>								
										</td>
										<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo ($CustomerData['cust_replenishment'])?$CustomerData['cust_replenishment']:'0.00'; ?>
										</b>								
										</td>
										</tr>
										<tr>										
											<td class="text-center bg_lite3">BALANCE</td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_weekly_balance-$sub_weeklyPainIvoice,2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_month_balance-$sub_monthlyPainIvoice,2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo  number_format($total_balance-$sub_cust_loan_used,2); ?></b></td> 
										</tr> 
									</tbody>
							</table>
							</div>
				<?php }else{
					?>
					<div class="row">
							<table class="table table-bordered table-hover "> 
									<tbody>
										<tr>
											<td class="text-center bg_lite3" colspan="5"><b>Loan Limit Info</b></td>
										</tr>
										<tr>
											<td class="text-center bg_lite3"></td>
											<td class="text-center bg_lite3">WEEKLY</td>
											<td class="text-center bg_lite3">MONTHLY</td>
											<td class="text-center bg_lite3"><?php echo $CustomerData['cust_mclr']; ?> MCLR</td> 
										</tr> 
										<tr>
											<td class="text-center bg_lite3">LIMIT</td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_weekly_loan_limit']; ?></b></td>
											<td class=" bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_monthly_loan_limit']; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_limit']; ?></b></td> 
										</tr>
										<tr>
											<td class="text-center bg_lite3">USED SELF</td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo ($CustomerData['weeklyPainIvoice']==""?'0.00':number_format($CustomerData['weeklyPainIvoice'],2)); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i>  <?php echo ($CustomerData['monthlyPainIvoice']==''?'0.00':number_format($CustomerData['monthlyPainIvoice'],2)); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php echo $CustomerData['cust_loan_used']; ?></b></td> 
										</tr> 
										
										<tr>
											<td class="text-center bg_lite3">USED OTHERS</td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_weeklyPainIvoice,2) ; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_monthlyPainIvoice,2) ; ?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php echo number_format($sub_cust_loan_used,2) ; ?></b></td> 
										</tr>
										
										<tr>
											<td class="text-center bg_lite3">USED BY MAIN</td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
											
												#LOGIC - from parent company limit if loan used amount crossed above 60% will show the crossed taken amount
												 
											    $parent_treshold=str_replace(',','',$parent_loan_usage['cust_weekly_loan_limit'])- str_replace(',','',$CustomerData['cust_weekly_loan_limit']);
											  $weeklyPainIvoice_p=$parent_loan_usage['weeklyPainIvoice'];
											  if($weeklyPainIvoice_p>$parent_treshold){
												    $weeklyPainIvoice_p_r=$weeklyPainIvoice_p-$parent_treshold;
												  echo  number_format($weeklyPainIvoice_p_r,2);
											  }else{
												  echo $weeklyPainIvoice_p_r="0.00";
											  }
											?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
												$parent_treshold_m=str_replace(',','',$parent_loan_usage['cust_monthly_loan_limit'])- str_replace(',','',$CustomerData['cust_monthly_loan_limit']);
											  $monthlyPainIvoice=$parent_loan_usage['monthlyPainIvoice'];
											  if($monthlyPainIvoice>$parent_treshold_m){
												    $monthlyPainIvoice_r=$monthlyPainIvoice-$parent_treshold_m;
												  echo  number_format($monthlyPainIvoice_r,2);
											  }else{
												  echo $monthlyPainIvoice_r="0.00";
											  }

											?></b></td>
											<td class="bg_lite3 text-right"><b><i class="fa fa-inr"></i> <?php 
											$parent_treshold_t=str_replace(',','',$parent_loan_usage['cust_loan_limit'])- str_replace(',','',$CustomerData['cust_loan_limit']);
											  $cust_loan_used_t=$parent_loan_usage['cust_loan_used'];
											  if($cust_loan_used_t>$parent_treshold_t){
												    $cust_loan_used_t_r=$cust_loan_used_t-$parent_treshold_t;
												  echo number_format($cust_loan_used_t_r,2);
											  }else{
												  echo $cust_loan_used_t_r="0.00";
											  }

											?></b></td> 
										</tr>
										
										<tr>										
											<td class="text-center bg_lite3">BALANCE</td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
											 
											echo number_format(($total_weekly_balance-$sub_weeklyPainIvoice)-$weeklyPainIvoice_p_r,2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
											echo  number_format(($total_month_balance-$sub_monthlyPainIvoice)-$monthlyPainIvoice_r,2); ?></b></td>
											<td class="text-right bg_lite3"><b><i class="fa fa-inr"></i> <?php 
											echo  number_format(($total_balance-$sub_cust_loan_used)-$cust_loan_used_t_r,2); ?></b></td> 
										</tr> 
									</tbody>
							</table>
							</div>
					<?php
				} ?>
							 
						</div>
					


					
					
						
						<div class="col-md-4">
							<div class="row">
								<table class="table table-bordered table-hover "> 
									<tbody>
										<tr>
											<td class="text-center bg_lite4" colspan="3"><b>Customer Receivable</b></td>
										</tr>
										<tr>
											<td class="text-center bg_lite4">Date</td>
											<td class="text-center bg_lite4">Amount</td>
											<td class="text-center bg_lite4">Rem Days</td>
										</tr>
										
										<?php foreach($receivableData as $dueData) { ?>
										<tr>
											<td class="text-center bg_lite4"><?php echo $dueData['date']; ?></td>
											<td class="text-right bg_lite4"><b><i class="fa fa-inr"></i> <?php echo number_format($Receivable_amount,2); //echo number_format($dueData['amount'],2); ?></b></td>
											<td class="text-center bg_lite4"><b><?php echo $dueData['RemDays']; ?></td>
										</tr>										
										<?php } 										
										if(count($receivableData)==1)
										{
										?>										
										
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<?php } 
										if(count($receivableData)<=0)
										{
										?>										
										
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">No records found</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<?php } ?>
										
										<?php if($CustomerData['cust_type']!="parent"){ ?>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<tr colspan="2">
											<td colspan="3" class="text-center bg_lite4">&nbsp;</td>					
										</tr>
										<?php } ?>
										
										<?php if(count($receivableData)>0)
										{
										?>
										
										<tr>
											<td class="text-center bg_lite4" colspan="3" style="padding:6px"><b><a href="<?=ADMINBASEURL;?>bankadmin/reportCustomerReceivable" class="btn btn-xs btn-primary ">Show More</a></b></td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
						
						
						
							<!--<table class="table table-bordered table-hover">
							<tr>
								<td colspan="2"><b>General Info</b></td>
								<td colspan="2"><b>Loan Limit Info</b></td>
							</tr>					
							<tr>
								<td>Customer Code</td>						
								<td><?php echo $CustomerData['cust_user_code']; ?></td>
								<td>Loan Limit</td>
								<td><?php echo $CustomerData['cust_loan_limit']; ?></td>
							</tr>
							<tr>
								<td>Customer Name</td>
								<td><?php echo $CustomerData['cust_name']; ?></td>
								<td>Available Loan Limit</td>
								<td><?php echo $CustomerData['cust_current_loan_balance']; ?></td>
							</tr>
							<tr>
								<td>Company Name</td>
								<td><?php echo $CustomerData['cust_company_name']; ?></td>
								<td>Monthly Loan Limit</td>
								<td><?php echo $CustomerData['cust_monthly_loan_limit']; ?></td>
							</tr>						
							<tr>
								<td>Phone number</td>
								<td><?php echo $CustomerData['cust_phone']; ?></td>
								<td>Weekly Loan Limit</td>
								<td><?php echo $CustomerData['cust_weekly_loan_limit']; ?></td>
							</tr>  
							</tbody>
						   </table>-->
					</div>
					<!-- /.table-responsive -->
				</div>
				<!-- /.box-body -->
				<!-- /.box-footer -->
			</div>
          <!-- /.box -->
        </div>
        <!-- /.col -->       
        <!-- /.col -->
	</div> 
		<?php } ?>
      <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
          <!-- MAP & BOX PANE -->
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
			
              <h3 class="box-title">Invoices Report</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body border_5">
              <div class="table-responsive">
                <table class="table table-bordered table-hover" style="width:100%">
                <thead>
                  <tr>
                    <th class="amber-800 col-md-3"></th>
                    <th class="amber-600 col-md-3"><h3 class="text-center">Invoice Amount</h3></th>
                    <th class="amber-400 col-md-3"><h3 class="text-center">Discount</h3></th>
                    <th class="amber-200 col-md-3"><h3 class="text-center">To Be Paid/Paid</h3></th>        
                  </tr>
                  </thead>
                  <tbody>
                  
                  <?php foreach($InvoiceReport as $each)  { 

				  ?>
				  <tr>
                    <td class="amber-800 col-md-3"><h3 class="text-center"><?php echo $each['invoice_status'];?></h3></td>                    
                    <td class="text-right amber-600 col-md-3">
						<?php 
						if($each['invoice_status']=='Approved'){
							$link_for="ApprovedInvoice";
						}elseif($each['invoice_status']=='Paid'){
							$link_for="paidInvoices";
						}else{
							$link_for="vendorInvoiceDues?status=".$each['invoice_status'];
						}						
						?>
						<!--<a href="<?=ADMINBASEURL;?>bankadmin/<?php echo $link_for; ?>">
							<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_amount'];?></b></h3>
						</a>-->
						
							<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_amount'];?></b></h3>
						
						
					</td>                    
                    <td class="text-right amber-400 col-md-3">
					<!--<a href="<?=ADMINBASEURL;?>bankadmin/<?php echo $link_for; ?>">
						<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_discount'];?></b></h3>
					</a>-->
					
						<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_discount'];?></b></h3>
					
					</td>                    
                    <td class="text-right amber-200 col-md-3">
					<!--<a href="<?=ADMINBASEURL;?>bankadmin/<?php echo $link_for; ?>">
						<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_to_paid'];?></b></h3>
					</a>-->
					
					
						<h3><b><i class="fa fa-inr"></i> <?php echo $each['invoice_to_paid'];?></b></h3>
					
					</td>                    
                  </tr>
				  <?php } ?>
                  
                  </tbody>
               </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
           <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->       
        <!-- /.col -->
      </div> 
	  <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
          <!-- MAP & BOX PANE -->
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Current Rate</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
               <table class="table table-bordered table-hover table-striped" style="width:100%">
                <thead>
                  <tr class="bg_lite1">                   
                    <th><h3 class="text-center">3MCLR</h3></th>
                    <th><h3 class="text-center">6MCLR</h3></th>
                    <th><h3 class="text-center">9MCLR</h3></th>
                    <th><h3 class="text-center">12MCLR</h3></th>
                    <th><h3 class="text-center">Strategic Premium Rate</h3></th>
                    <th><h3 class="text-center">Risk Premium Rate</h3></th>
                    <th><h3 class="text-center">Effective From</h3></th>
                  </tr>
                  </thead>
                  <tbody>
                  
                  <?php                 
                  if(count($RatesMaster)>0)
                  {
                  $i='1';
                  foreach($RatesMaster as $each)
                  {
					?><tr class="bg_lite2 text-center">             
						<td><h4><?php echo $each['three_mclr']; ?></h4></td>
						<td><h4><?php echo $each['six_mclr']; ?></h4></td>
						<td><h4><?php echo $each['nine_mclr']; ?></h4></td>
						<td><h4><?php echo $each['mclr_twelve']; ?></h4></td>
						<td><h4><?php echo $each['strategic_premium_rate']; ?></h4></td>
						<td><h4><?php echo $each['risk_premium_rate']; ?></h4></td>
						<td><h4><?php echo $each['financing_date']; ?></h4></td>
                  </tr>
                  <?php
                  $i++;
                  }
                  }
                  ?>
                  
                  </tbody>
               </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
           <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

        
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script>
  $('#reset').click(function(){
	$("#dash_from_date").val("");  
	$("#dash_to_date").val("");
  });
  </script>