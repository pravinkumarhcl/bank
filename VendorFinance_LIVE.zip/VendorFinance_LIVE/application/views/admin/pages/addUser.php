<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title; ?> User
		 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Users</a></li>
        <li class="active"><?=$title; ?> User</li>
      </ol>
	 
    </section>

    <?php
    if($this->session->flashdata('Success')):?>
    <div class="box-body">
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                <p> <?=$this->session->flashdata('Success'); ?></p>
            </div>
     </div>
    <?php endif; 
	if($this->session->flashdata('Error')):?>
    <div class="box-body">
            <div class="alert alert-error">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Error!</h4>
                <p> <?=$this->session->flashdata('Error'); ?></p>
            </div>
     </div>
    <?php endif;?>
    
    <!-- Main content -->
    <section class="content">
	
      <div class="row">          
        <div class="col-md-12">
		<a  class="pull-right btn btn-primary margin_5"  href="<?=ADMINBASEURL;?>bankadmin/userManagement"><i class="fa fa-table"></i></i><span> Users</span></a>
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
           <?php 
           

            
                   
           ?>
          
			
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>bankadmin/submitUser">
            <input type="hidden" name="id" id="user_id" value="<?=$userdetails->user_id;?>" />
            <div class="tab-content">
			
            
                
              <div class="box-body">                  
                   
                <div class="form-group">
                  <label>Name</label>
                  <div class="form-group-inner">
                  <input class="form-control"  name="user_name" value="<?=$userdetails->user_name;?>" placeholder="User Name" type="text"><?= form_error("user_name")?>
                  </div>
                </div>
                
               <div class="form-group">
                  <label>Email/User name</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="user_email" value="<?=$userdetails->user_email;?>" placeholder="Email/User name" type="email"><?= form_error("user_email")?>
                  </div>
                </div>
				
                <div class="form-group">
                  <label>User Type</label>
                  <div class="form-group-inner">
					<select  class="form-control"  name="user_type" id="user_type">
					<option value="">--Select User Type--</option>
					<option <?php echo ($userdetails->user_type=='bankadmin')? 'selected="selected"':''; ?> value="bankadmin">Admin</option>
					<option <?php echo ($userdetails->user_type=='maker')? 'selected="selected"':''; ?> value="maker">Maker</option>
					<option <?php echo ($userdetails->user_type=='checker')? 'selected="selected"':''; ?> value="checker">Checker</option>
					<!--option <?php echo ($userdetails->user_type=='customer')? 'selected="selected"':''; ?> value="checker">Customer</option-->
					</select><?= form_error("user_type")?>
                  
                  </div>
                </div>
                
                <div class="form-group">
                  <label>Phone Number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="user_phone" value="<?=$userdetails->user_phone;?>" placeholder="Phone Number" type="text"><?= form_error("user_phone")?>
                  </div>
                </div>
                
                
                  
                <div class="form-group">
                  <label>Department</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="user_department"  value="<?=$userdetails->user_department;?>" placeholder="Department" type="text">
				  <?= form_error("user_department")?>
                  </div>
                </div>
                     <div class="form-group">
                  <label>Designation</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="user_designation"  value="<?=$userdetails->user_designation;?>" placeholder="Designation" type="text">
				  <?= form_error("user_designation")?>
                  </div>
                </div>
               
                  <div class="box-footer">
					<button type="submit" class="pull-right btn btn-primary">Submit</button>
                </div>
              
			  </div>
				
              <!-- /.box-body -->
             
                
            
            </div>
          
            </form>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
       
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>