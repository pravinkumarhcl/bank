<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title; ?> Master Rate Form
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master Rates</a></li>
        <li class="active"><?=$title; ?>Master Rate Form</li>
      </ol>
    </section>

    <?php
    if($this->session->flashdata('Success')):?>
    <div class="box-body">
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i><?=$this->session->flashdata('Success'); ?></h4>
            </div>
     </div>
    <?php endif;?>

    
    <!-- Main content -->
    <section class="content">
      <div class="row">          
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>bankadmin/masterrateslist">
            <input type="hidden" name="id" value="<?=$interestrate->rate_id;?>" />
            <div class="tab-content">    
              <div class="box-body">
                <div class="form-group">
                  <label>3MCLR <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest " name="mclr3" value="<?=$interestrate-> mclr3;?>" placeholder="3MCLR" type="text">
				  <span class="text-danger"><?= form_error('mclr3')?></span>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>6MCLR <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest" name="mclr6" value="<?=$interestrate->mclr6;?>" placeholder="6MCLR" type="text">
				  <span class="text-danger"><?= form_error('mclr6')?></span>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>9MCLR <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest" name="mclr9" value="<?=$interestrate->mclr9;?>" placeholder="9MCLR" type="text"><span class="text-danger"><?= form_error('mclr9')?></span>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>12MCLR <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest" name="mclr12" value="<?=$interestrate->mclr12;?>" placeholder="12MCLR" type="text">
				  <span class="text-danger"><?= form_error('mclr12')?></span>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Strategic Premium Rate <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest" name="strategic_premium" value="<?=$interestrate->strategic_premium;?>" placeholder="Strategic Premium Rate" type="text"><span class="text-danger"><?= form_error('strategic_premium')?></span>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>Risk Premium Rate <span class="text-danger"> * </span></label>
                  <div class="form-group-inner">
                  <input class="form-control interest_rate mclr_intrest" name="risk_premium" value="<?=$interestrate->risk_premium;?>" placeholder="Risk Premium Rate" type="text"><span class="text-danger"><?= form_error('risk_premium')?></span>
                  </div>
                </div>
                
				</div> <!--box-body ends-->
				<div class="box-footer">
					<button type="sumbit" class="btn btn-primary next-customer pull-right">Submit</button>
                </div>
				
              </div> <!--Tab-content ends-->
			</form>
        
          </div><!--nav-->
     
        </div><!--col-->
       
        
      </div> <!--rows-->
    </section>
   
  </div> <!-- /.content Wrapper Ends -->



