<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Information
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customer Information</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
             
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
               
              <table class="table table-bordered table-hover" style="width:100%">
                  <tr><td colspan="2"><b>General Info</b></td></tr>
                <tr><td>Customer Code</td><td><?=$customerdetails->cust_user_code; ?></td></tr>
                <tr><td>Customer Name</td><td><?=$customerdetails->cust_name; ?></td></tr>
                <tr><td colspan="2"><b>Company Info</b></td></tr>                
                <tr><td>Address 1</td><td><?=$customerdetails->cust_address1; ?></td></tr>
                <tr><td>Address 2</td><td><?=$customerdetails->cust_address2; ?></td></tr>
                <tr><td>City</td><td><?=$customerdetails->cust_city; ?></td></tr>
                <tr><td>State</td><td><?=$customerdetails->cust_state; ?></td></tr>
                <tr><td colspan="2"><b>Contact Info</b></td></tr>
                <tr><td>Phone number</td><td><?=$customerdetails->cust_phone; ?></td></tr>
                <tr><td>Email Address</td><td><?=$customerdetails->cust_email; ?></td></tr>
                <tr><td colspan="2"><b>Account Info</b></td></tr>
                <tr><td>Customer Account no</td><td><?=$customerdetails->cust_account_no; ?></td></tr>
                <tr><td>IFSC Code</td><td><?=$customerdetails->cust_ifsc_code; ?></td></tr>
                
                <tr><td colspan="2"><b>Loan Limit Info</b></td></tr>
                <tr><td>Loan Limit</td><td><?=$customerdetails->cust_loan_limit; ?></td></tr>
                <tr><td>Available Loan Limit</td><td><?php printf("%0.2f",$balance); ?></td></tr>
				<tr><td>Monthly Loan Limit</td><td><?=$customerdetails->cust_monthly_loan_limit; ?></td></tr>
                <tr><td>Weekly Loan Limit</td><td><?=$customerdetails->cust_weekly_loan_limit; ?></td></tr>              
                
                <tr><td colspan="2"><b>Interest Rate Info</b></td></tr>
                <tr><td>Financing Date</td><td><?=$customerdetails->financing_date; ?></td></tr>
                <tr><td>3 Months MCLR</td><td><?=$customerdetails->three_mclr; ?></td></tr>
                <tr><td>6 Months MCLR</td><td><?=$customerdetails->six_mclr; ?></td></tr>
                <tr><td>9 Months MCLR</td><td><?=$customerdetails->nine_mclr; ?></td></tr>
                <tr><td>1 Year MCLR</td><td><?=$customerdetails->mclr_twelve; ?></td></tr>
                <tr><td>Strategic Premium Rate </td><td><?=$customerdetails->strategic_premium_rate; ?></td></tr>
                <tr><td>Risk Premium Rate</td><td><?=$customerdetails->risk_premium_rate; ?></td></tr>
                
                
                               
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>