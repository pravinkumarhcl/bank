<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Total Vendors Invoice list
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
       
        <li class="active">Vendors Invoice list</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Vendor Invoice list</h3>
            </div>
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <div class="box-body">
            
              <table id="example2" class="table table-bordered table-hover" style="width:100%">
                <thead>
                <tr>
                    <th>Vendor Code</th>
                    <th>Vendor Name</th>
                    <th>Total Amount</th>
                    <th>Discount</th>
                    <th>Amount to be paid</th>
                    <th>Pending Count</th>
                    <th>Confirmed Count</th>
                  </tr>
                  </thead>
                  <tbody>
                  
                  <?php
                  foreach($invoiceList as $each)
                  {?><tr>
                    <td><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceList?id=<?=$each->vendor_id;?>"><?=$each->vendor_code;?></a></td>
                    <td><?=$each->vendor_name;?></td>
                    <td><?=number_format($each->total_amount,2);?></td>
                    <td><?php 
                    
                    //echo '<pre>'; print_R($each);
                     $value = $each->interestRate*($each->total_amount*90)/365;
                     $valuefin = $value/100;
                     echo number_format($valuefin,2);
                    ?></td>
                    <td><?php
                    $sum = $each->total_amount-$valuefin;
                    echo number_format($sum,2);?></td>
                    <td><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceList?id=<?=$each->vendor_id;?>&status=pending"><?=$each->pending_count;?></a></td>
                    <td><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceList?id=<?=$each->vendor_id;?>&status=confirmed"><?=$each->confirmed_count;?></a></td>
                  </tr>
                <?php 
                $i++;
                } ?>
                </tbody>
               </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>