	<!--main content start-->
	
	<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Customer Receivable Report
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=ADMINBASEURL;?>bankadmin"><i class="fa fa-dashboard"></i> Home</a></li>
         <li>Customer Receivable Report</li>        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">          
            <!-- /.box-header -->
            <div class="box-body">			
				<div class="table-responsive">
					<!--Report Download ends-->
				  <table class="table table-bordered" id="posts">
					<thead>
					  <tr>
						<th class="center">Sl.No</th>
						<th class="center">Vendor Code</th>
						<th class="center">Invoice Amount</th>
						<th class="center">Type</th>
						<th class="center">Rate</th>
						<th class="center">Days</th>
						<th class="center">Payment Date</th>
						<th class="center">Paid Amount</th> 
						<th class="center">Interest</th> 
						<th class="center">Due Date</th> 
						<th class="center">Due Amount</th> 
						<th class="center">Status</th> 
						<th class="center">Remarks</th> 
																		
					  </tr>
					  </thead>
					 
				   </table>
				   
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
   <script>
 
    $(document).ready(function () {
        $('#posts').DataTable({
			dom: 'Brtlf<<t>ip>',
        buttons: [
		 { extend: 'excel', text: 'Export Excel' }],
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getCustomerReceivableReport",
		     "dataType": "json",
		     "type": "POST",
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
	    "columns": [
		         
						{ "data": "invoice_id", className: "center" },
						{ "data": "vendor_code", className: "left"},
						{ "data": "invoice_amount", className: "right" },
						{ "data": "type", className: "center" },
						{ "data": "interest_rate", className: "center" },
						{ "data": "invoice_deduction_days", className: "center" },
						{ "data": "payment_datetime", className: "center" },
						{ "data": "invoice_topaid", className: "right" },
						{ "data": "invoice_gross_rate", className: "right" },
						{ "data": "due_date", className: "center" },
						{ "data": "due_amount", className: "right" },
						{ "data": "status", className: "center" },
						{ "data": "customer_remark", className: "center" },
		        
		       ]	 

	    });
		
	 
    });
	
</script> 
  
	   <!--main content end-->
	<script> 
	function check_box_selected(){
		var is_selected=false;
		 $('input[name="mark_as_paid[]"]').each(function(t){ 
			 if($(this).prop('checked')){
				 is_selected=true;
			 } 
			
		 })
		 if(!is_selected){
			 alert('Please select atleast one checkbox');
		 }else{
			 var prompted=prompt('Please Enter the Remarks.');
			 if(!prompted){
				 return false;
			 }
			 $('#customer_remark').val(prompted);
		 }
		  return is_selected;
	}
	</script>