<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Vendor
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=ADMINBASEURL;?>bankadmin/vendorlist">Vendor Company</a></li>
        <li class="active">Add vendor</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;
			 $CustomerData=$this->session->userdata("CustomerData");
			?>
              
             <!--<div class="pull-right">
                   <a href="<?=ADMINBASEURL;?>bankadmin/vendorlist?id=<?=$vendor_cust_id;?>">
                       <button type="button" class="btn btn-primary btn-sm btn-flat">Vendor List</button>
                   </a>
              </div>-->
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>bankadmin/vendorVerification">
              <input type="hidden" name="vendor_cust_id" value="<?=$CustomerData['cust_id'];?>" />
              <input type="hidden" name="vendor_id" value="<?=$vendor_id;?>" />
              <div class="box-body">
                  
                <div class="form-group">
                  <label>Vendor number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="user_code" value="<?=$vendordetails->vendor_code;?>" placeholder="Vendor number" type="text"><?= form_error("user_code")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Vendor Company Name</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="company_name" value="<?=$vendordetails->vendor_company_name;?>" placeholder="Company Name" type="text"><?= form_error("company_name")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Address 1</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="address1" value="<?=$vendordetails->vendor_address1;?>" placeholder="Address 1" type="text"><?= form_error("address1")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Address 2</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="address2" value="<?=$vendordetails->vendor_address2;?>" placeholder="Address 2 (Optional)" type="text"><?= form_error("address2")?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>City</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="city" value="<?=$vendordetails->vendor_city;?>" placeholder="City" type="text"><?= form_error("city")?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label>State</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="state" value="<?=$vendordetails->vendor_state;?>" placeholder="State" type="text"><?= form_error("state")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Vendor Point of Contact Name</label>
                  <div class="form-group-inner">
                  <input class="form-control" id="numeric" name="name" value="<?=$vendordetails->vendor_name;?>" placeholder="Vendor Name" type="text"><?= form_error("name")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Vendor Phone number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="phone" onkeypress="return isNumber(event)" value="<?=$vendordetails->vendor_phone;?>" placeholder="Vendor Phone number" type="text"><?= form_error("phone")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Vendor Email ID</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="email" value="<?=$vendordetails->vendor_email;?>" placeholder="Vendor Email ID" type="text"><?= form_error("email")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Vendor bank name</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="bank_name" value="<?=$vendordetails->vendor_bank_name;?>" placeholder="Vendor Bank Name" type="text"><?= form_error("bank_name")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Vendor bank branch</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="bank_branch" value="<?=$vendordetails->vendor_bank_branch;?>" placeholder="Vendor Bank Branch" type="text"><?= form_error("bank_branch")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Vendor bank account number</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="account_no" onkeypress="return isNumber(event)" value="<?=$vendordetails->vendor_account_no;?>" placeholder="Customer bank account number" type="text"><?= form_error("account_no")?>
                  </div>
                </div>
                <div class="form-group">
                  <label>Vendor IFSC Code</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="ifsc_code" value="<?=$vendordetails->vendor_ifsc_code;?>" placeholder="Customer IFSC Code" type="text"><?= form_error("ifsc_code")?>
                </div>
                </div>
				
                <div class="form-group">
                  <label>Subsidiary Vendor</label>
                  <div class="form-group-inner">
					<div class="radio" style="margin: 0;">
						<label style="margin: 0;width: auto;"><input type="radio" name="is_subsidiary" value="N" <?php if($vendordetails->is_subsidiary!='Y') { echo 'checked'; } ?>>NO</label>
					</div>
					<div class="radio" style="margin: 0;">
						<label style="margin: 0;width: auto;margin-left:10px;" style="margin: 0;"><input <?php if($vendordetails->is_subsidiary=='Y') { echo 'checked'; } ?>  type="radio" name="is_subsidiary" value="Y">YES</label>
					</div>
                </div>
                </div>
				
              </div>
              <!-- /.box-body -->

              <div class="box-footer" style="text-align:center;">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          
        </div>
        <!--/.col (left) -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>