<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Vendor Import
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customer Vendor Import</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Vendor Import</h3>
            </div>
              <form action="<?=ADMINBASEURL;?>bankadmin/saveimport" method="POST" enctype="multipart/form-data" >
              <input type="hidden" name="cust_id" value="<?=$cust_id; ?>" />
              <div class="box-body">
                <div class="form-group">
                    <label>Import File</label>
                    <div class="form-group-inner">
                        <input class="" name="userfile" value="" type="file" />
                        <span style="color:red;">
                            <?php if($this->session->flashdata('import_error')!=''){
                                echo $this->session->flashdata('import_error');
                            }?>
                        </span>
                    </div>
                </div>
                  <br /> <br />
               <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
              </div>
          </form>
          </div>
          
        </div>
        <!--/.col (left) -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>