<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of Customers
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Customers</a></li>
        <li class="active">List of customers</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
		  <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
			<div class="clearfix hidden-md hidden-lg"></div>
            <div class="">
              <?php if($active_cust_id==''){ ?>
			  <a class="pull-right btn btn-primary margin_5" href="<?=ADMINBASEURL;?>bankadmin/customerform"><i class="fa fa-plus"></i> Add Customer</a>
			  <?php } ?>
            </div>
            <div class="clearfix "></div>
            <!-- /.box-header -->      
            <div class="box-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="posts">
					<thead>
					<tr>
					  <th class="center">S.No</th>
					  <th class="center">Customer Code</th>
					  <th class="center">Customer Name</th>                 
					  <th class="center">Account No</th>
					  <th class="center">IFSC Code</th>
					  <th class="center">Phone No</th>
					  <!--<th class="center">Type</th>-->
					  <th class="center">Action</th>
					</tr>
					</thead>                
				   </table>
				</div>          
            </div>          
          </div>         
        </div>      
      </div>    
    </section>
	 <script>
 
    $(document).ready(function () {
        $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getCustomerList",
		     "dataType": "json",
		     "type": "POST",
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
	    "columns": [
		         
				   { "data": "cust_id", className: "center" },
		          { "data": "cust_user_code", className: "left" },
		          { "data": "cust_name", className: "left" },
		          { "data": "cust_account_no", className: "left" },
		          { "data": "cust_ifsc_code", className: "left" },
		          { "data": "cust_phone", className: "left" },
		         <!-- { "data": "cust_type", className: "center" },-->
		         { "data": "customer_actions", className: "center" },
		       ]	 

	    });
		
	 
    });
	
</script> 
    <!-- /.content -->
  <!--
  <form>
  <label>Select any one</label> &nbsp;
  <input type="radio" name="gender" value="male" checked> Male &nbsp;
  <input type="radio" name="gender" value="female"> Female&nbsp;
  <input type="radio" name="gender" value="other"> Other &nbsp; 
</form> -->
  </div>
  