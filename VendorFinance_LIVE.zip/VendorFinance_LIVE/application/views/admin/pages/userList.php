<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of Users
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Users</a></li>
        <li class="active">List of Users</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
			<?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
			<div class="clearfix hidden-md hidden-lg"></div>
            <div class="">
              <?php

			  if($active_cust_id==''){ ?>
			  <a class="pull-right btn btn-primary margin_5" href="<?=ADMINBASEURL;?>bankadmin/userForm"><i class="fa fa-plus"></i> Add User</a>
			  <?php } ?>
            </div>
           
			<div class="clearfix"></div>
            <!-- /.box-header -->
            <div class="box-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="posts">
					<thead>
						<tr>
							<th class="center">User Id</th>
							<th class="center">User Name</th>
							<th class="center">User Type</th>
							<th class="center">Phone Number</th>                 
							<th class="center">Email Address</th>
							<th class="center">Department</th>
							<th class="center">Designation</th>
							<th class="center">Actions</th>
						  
						</tr>
					</thead>
				</table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box 
  $this->encryption->encrypt($customers->cust_id);
					$this->encryption->decrypt($ciphertext); -->
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <script>
 
    $(document).ready(function () {
        $('#posts').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getUserList",
		     "dataType": "json",
		     "type": "POST",
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
	    "columns": [
		         
				   { "data": "user_id", className: "center" },
		          { "data": "user_name", className: "left" },
		          { "data": "user_type", className: "center" },
		          { "data": "user_phone", className: "left" },
		          { "data": "user_email" , className: "left"},
		          { "data": "user_department", className: "left" },
		          { "data": "user_designation", className: "left" },
		         { "data": "user_actions", className: "center" },
		       ]	 

	    });
		
	 
    });
	
</script> 