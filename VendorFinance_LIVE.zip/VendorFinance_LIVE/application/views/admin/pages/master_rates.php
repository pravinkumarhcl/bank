<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Interest Rate List
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Interest Rate List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
               <h3 class="box-title">Interest Rate List</h3> 
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success" id="closealerts">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?>
                <span style="float:right;">
                    <i class="fa fa-times" aria-hidden="true"></i>
                  </span>
                </p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
			<a class="pull-right btn btn-primary margin_5" href="<?=ADMINBASEURL;?>bankadmin/masterrateslist"><i class="fa fa-plus"></i> Add Rates</a>
			<div class="clearfix"></div>
              <form action="<?=ADMINBASEURL;?>/bankadmin/masterRates" method="POST">
                <!-- <div class="pull-right" style="width: 20%;margin-left:1%;">
                <select name="interest_status" class="form-control" style="width: 57%;display: inline-block;">
                    <option value="">Select For Approved</option>
                    <option value="Approved" <?php echo ($actualStatus =='Approved' ? 'selected="selected"' : ''); ?>>Approve</option>
                </select>
               <button type="submit" class="btn btn-success btn-md btn-flat" style="margin-bottom: 3px;">Update Status</button>
                </div> -->
				<div class="table-responsive">
                <table class="table table-bordered" id="posts">
                <thead>
                  <tr>
                    <th class="text-center">S.No</th>
                    <th class="text-center">3MCLR</th>
                    <th class="text-center">6MCLR</th>
                    <th class="text-center">9MCLR</th>
                    <th class="text-center">12MCLR</th>                   
                    <th class="text-center">Strategic Premium Rate</th>
                    <th class="text-center">Risk Premium Rate</th>                    
                    <th class="text-center">Status</th>
                    <th class="text-center">Effective From</th>
                    <th class="text-center">Effective To</th>                    
                    <th class="text-center">Action</th>
                  </tr>
                  </thead>
                 
               </table>
				</div>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
   <script>
 
    $(document).ready(function () {
        $('#posts').DataTable({
			 "order": [[ 0, "desc" ]],
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getMasterRates",
		     "dataType": "json",
		     "type": "POST",
			 
		     "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
		                   },
			 "rowCallback": function( row, data ) {								
				if(data.status=='Active')
				{
					 $(row).addClass('label-success');
				}					
			},				   
	    "columns": [
		         
						{ "data": "rate_id", className: "center" },
						{ "data": "threemclr", className: "center" },
						{ "data": "sixmclr", className: "center" },
						{ "data": "ninemclr", className: "center" },
						{ "data": "twelvemclr", className: "center" },
						{ "data": "strategic_premium", className: "center" },
						{ "data": "risk_premium", className: "center" },
						{ "data": "status", className: "center" },
						{ "data": "effective_from", className: "center" },
						{ "data": "effective_to", className: "center" },
						{ "data": "action", className: "center" },
		       ]	 

	    });
		
	 
    });
	
</script> 