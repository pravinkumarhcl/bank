<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         <?=$title; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Mail Templates</a></li>
        <li class="active"><?=$title; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
		
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!---<div class="box-header with-border">
              <h3 class="box-title"><?=$title; ?></h3>
            </div>-->
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
            <!-- /.box-header -->
            <!-- form start -->
			<div class="col-md-12">
			<a class="pull-right btn btn-primary margin_5" href="<?=ADMINBASEURL;?>templates/mailtemplates"><i class="fa fa-table"></i> View Template</a>
			</div>
            <form role="form" method="POST" action="<?=ADMINBASEURL;?>templates/mailVerification">
              <input type="hidden" name="mail_edit_id" value="<?=$mail_edit_id;?>" /> 
              <div class="box-body">
                <div class="form-group">
                  <label>Mail Title</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="title" value="<?=$mailtemplates->title;?>" placeholder="Mail title" type="text"><?= form_error("title")?>
                  </div>
                </div>
                  
                <div class="form-group">
                  <label>Mail Subject</label>
                  <div class="form-group-inner">
                  <input class="form-control" name="subject" value="<?=$mailtemplates->subject;?>" placeholder="Mail subject" type="text"><?= form_error("subject")?>
                  </div>
                <div class="form-group">
                    <label>Mail Body</label><br /><br />
                    <div class="box-body pad ckeditor_div">
                    <textarea id="editor1" name="message" rows="10" cols="80">
                    <?php
                    $message = str_replace('\n','',$mailtemplates->message);
                    $message = str_replace('\r','',$message);
                    echo html_entity_decode($message);?>
                    </textarea>
                       
                </div> <?= form_error("message")?>
                
                </div>
                
               
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer text-right">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          
        </div>
        <!--/.col (left) -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>z