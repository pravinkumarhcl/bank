<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Interest Rate List
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Interest Rate List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <?php if($this->session->flashdata('Success')):?>
            <div class="alert alert-success">
                <p><b>Success!</b> <?=$this->session->flashdata('Success'); ?></p>
            </div>
            <?php endif;?>
              
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?=ADMINBASEURL;?>/bankadmin/InterestRateUpdate" method="POST">
                <div class="pull-right" style="width: 20%;margin-left:1%;">
                <select name="interest_status" class="form-control" style="width: 57%;display: inline-block;">
                    <option value="Pending" <?php echo ($actualStatus =='Pending' ? 'selected="selected"' : ''); ?>>Pending</option>
                    <option value="Approved" <?php echo ($actualStatus =='Approved' ? 'selected="selected"' : ''); ?>>Approve</option>
                </select>
               <button type="submit" class="btn btn-success btn-md btn-flat" style="margin-bottom: 3px;">Update Status</button>
                </div>
				<div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover table-striped" style="width:100%">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Customer Name</th>
                    <th>MCLR</th>
                    <th>MCLR Percentage</th>
                    <th>Strategic Premium Rate</th>
                    <th>Risk Premium Rate</th>
                    <th>Interest Rate</th>
                    <th>status</th>
                    <th><input type="checkbox" class="parent_class"  /></th>
                  </tr>
                  </thead>
                  <tbody>
                  
                  <?php
                  $arrayClasses = array('Approved'=>'label-success','Pending'=>'label-warning');
                  if(count($interestlist)>0)
                  {
                  $i='1';
                  foreach($interestlist as $each)
                  {?><tr>
                    <td><?=$i;?></td>
                    <td><a href="<?=ADMINBASEURL;?>bankadmin/customerview/<?=$each->cust_id;?>"><?=$each->cust_name;?></a></td>
                    <td><?=$each->cust_rate_mclr;?> Months</td>
                    <td><?=$each->cust_rate_mclr_percent; ?></td>
                    <td><?=$each->cust_rate_strategic_premium?></td>
                    <td><?=$each->cust_rate_risk_premium; ?></td>
                    <td><?=$each->cust_interest_rate; ?></td>
                    <td><span class="label <?=$arrayClasses[$each->status];?>"><?=$each->status; ?></span> </td>
                    <td>
                     <input type="checkbox" class="child_class"  name="cust_interest_id[]" value="<?=$each->cust_rate_id; ?>" />    
                    </td>
                  </tr>
                  <?php
                  $i++;
                  }
                  }
                  ?>
                  
                  </tbody>
               </table>
            </div>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>