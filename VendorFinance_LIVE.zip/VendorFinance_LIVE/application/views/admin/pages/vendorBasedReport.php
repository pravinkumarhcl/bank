<div class="content-wrapper" style="min-height: 916.3px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <b><?php echo $customer_deails['0']['cust_name']; ?></b> Vendor Payments
        <small></small>
      </h1>
      <ol class="breadcrumb">
		 <li><a href="<?=ADMINBASEURL;?>bankadmin"><i class="fa fa-dashboard"></i>Home</a></li>
		 <li><a href="<?=ADMINBASEURL;?>bankadmin/customerBasedReport">Customer Report</a></li>
         <li><?php echo $customer_deails['0']['cust_name']; ?></li>        
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
                       
             <div id="alert_message">
				
			</div>	 
            <!-- /.box-header -->
            <div class="box-body">
				<form class="form-inline" method="POST" action="" autocomplete="off"><!-- form-search-->
				<input type="hidden" name='cust_id' id="cust_id" value="<?php echo $cust_id;?>"/>
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="from_date">From Date</label>
						<div class="col-sm-8">
							<input type="text" required autocomplete="off" class="form-control" value=""  name="filter_from" id="from_date" placeholder="From Date">
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label col-sm-4 label-middle" for="to_date">To Date</label>
						<div class="col-sm-8">
							<input type="text" required class="form-control"  autocomplete="off" value="" 
							name="filter_to" id="to_date" placeholder="To Date">
						</div>
					</div>	
					<div class="form-group">
						&nbsp;&nbsp;&nbsp;<button type="button" id="search_vendors" class="btn btn-primary">Submit</button>
						&nbsp;&nbsp;&nbsp;<button type="submit" name='reset' class="btn btn-primary">Reset</button>
					</div>	
				</form>
				<hr />
				<!-- Report Download Excel
				<form class="form-inline" id="downloads" method ="POST" action="<?=ADMINBASEURL;?>bankadmin/vend_reportexc">
					<div class="form-group" style="float:right;">
						<input type="hidden" name='cust_id' value="<?php echo $cust_id;?>"/>
						<button type="submit" name='vend_download' class="btn btn-primary"><i class="fa fa-download">&nbsp;</i>
							<span> Download</span></button>
					</div>
				</form>	-->
				<!--Report Download ends-->
				<div class="table-responsive">
				  <table class="table table-bordered" id="posts">
					<thead>
					  <tr>
						<th class="center">S.NO</th>
						<th class="center">Vendor Code</th>
						<th class="center">Vendor Name</th>                     
						<th class="center">Invoice Amount</th>
						<th class="center">Discount</th>
						<th class="center">Invoice Date</th>
						<th class="center">Paid Amt</th>                                      
						<th class="center">Amt To Be Paid</th>
					  </tr>
					  </thead>
					  
				   </table>
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
   <script>
 
    $(document).ready(function () {
		var from_date = $('#from_date').val();
		var to_date = $('#to_date').val();
         datatable_appointments = $('#posts').DataTable({
			dom: 'Brtlf<<t>ip>',
        buttons: [
		 { extend: 'excel', text: 'Export Excel' }],
            "processing": true,
            "serverSide": true,
            "ajax":{
		     "url": "<?php echo ADMINBASEURL; ?>bankadmin/getVendorReport?cust_id=<?php echo $cust_id;?>",
		     "dataType": "json",
		     "type": "POST",
			 "dataSrc": function ( json ) {
                //Make your callback here.
             
                return json.data;
            }, 
		    data: function ( d ) {
					d.filter_from = $("#from_date").val();
					d.filter_to = $("#to_date").val();					
					d.<?php echo $this->security->get_csrf_token_name(); ?>='<?php echo $this->security->get_csrf_hash(); ?>';					
				}
		                   },
	    "columns": [
		         
					{ "data": "vendor_id", className: "center" },
					{ "data": "vendor_code", className: "left" },
					{ "data": "vendor_name", className: "left" },
					{ "data": "invoice_amount", className: "right" },
					{ "data": "discount", className: "right" },
					{ "data": "invoice_date", className: "center" },
					{ "data": "paid_amount", className: "right" },
					{ "data": "pending_amount", className: "right" },
		       ]	 

	    });
		
		function data_from(){
			return $('#from_date').val();
		}
		function data_to(){
			return $('#to_date').val();
		}
	 $('#search_vendors').click(function(){	
         filter_from = $("#from_date").val();
		filter_to = $("#to_date").val();
$.ajax({
				method:'POST',
				data:{'filter_from':filter_from,'filter_to':filter_to},
				url: baseurl+'bankadmin/validateDates',
				success:function(data){						
					var json = $.parseJSON(data);		
					
					if(json['message']=='0')
					{
					
						var data_show='<div class="alert alert-danger">   <p> '+json['data']+' </p>  </div>';
						$("#alert_message").html(data_show);
					}
					else{
					$("#alert_message").html("");

					}					
					datatable_appointments.ajax.reload();				

					
				}
			});	

			
			
	
		});
    });
	
</script> 