<?php


$this->load->view('admin/common/header');

$this->load->view('admin/common/headermenu');

$this->load->view('admin/common/leftsidemenu');

$this->load->view($page);

$this->load->view('admin/common/footer');