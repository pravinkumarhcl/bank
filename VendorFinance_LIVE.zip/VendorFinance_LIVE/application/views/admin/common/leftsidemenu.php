<?php
	$result = $this->session->userdata('member'); 
	if(!empty($result)){ 
		$user_type =$result['user_type'];
	} 
  ?> 

 <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?=MEDIAURL;?>images/adminlogo.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <?php 
	  $active_cust_id=$this->session->userdata('active_cust_id');
	  $runningMethod = $this->router->fetch_method();

	  ?>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        
		<li class="<?php echo ($runningMethod =='dashboard' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <!-- Optionally, you can add icons to the links -->
       
	   <?php 
		if(check_module_for_menu($user_type,'customerlist')>0){ 
	   ?>
		
		
		<li class="<?php echo ($runningMethod =='customerform' || $runningMethod =='customerview' || $runningMethod =='customerlist' ? 'menu-open' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/customerlist"><i class="fa fa-table"></i></i><span>Customers</span></a></li>
		<?php } ?>
		<?php 
		if(check_module_for_menu($user_type,'masterRates')>0){ 
	   ?>
		<?php if($active_cust_id=='') { ?>
		<li class="<?php echo ($runningMethod =='masterRates' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/masterRates"><i class="fa fa-percent" aria-hidden="true"></i><span>Master Rates</span></a></li>
		<?php } ?>   
		<?php } ?>   
		
		<?php if($active_cust_id!='') { ?>
		 
		 <li class="<?php echo ($runningMethod =='vendorlist' || $runningMethod =='vendorform' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorlist"><i class="fa fa-table"></i></i>Vendor Company</span></a></li>
		 
        <li class="treeview <?php echo ($runningMethod =='vendorInvoiceMainPage' || $runningMethod =='vendorInvoiceDues' || $runningMethod =='Invoiceviewandupdate' ? 'menu-open' : ''); ?>">
          <a href="#"><i class="fa fa-file"></i> <span>Invoice</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <?php $menu = $this->encryption->decrypt(str_replace(" ","+",$this->input->get('status'))); ?>
          <ul class="treeview-menu" style="display:<?php echo ($runningMethod =='invoiceByCustomer' || $runningMethod =='vendorInvoiceMainPage' || $runningMethod =='viewmapped' ||  $runningMethod =='viewmappedpaid' || $runningMethod =='vendorInvoiceList' || $runningMethod =='paidInvoices' || $runningMethod =='Invoiceviewandupdate' || $runningMethod =='ApprovedInvoice' ||  $runningMethod =='vendorInvoiceDues' ? 'block' : 'none'); ?>">
            <!--<li class="<?php echo ($runningMethod =='vendorInvoiceMainPage' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceMainPage"><i class="fa fa-dollar"></i>Invoice to paid</a></li>-->
           <?php 
		if(check_module_for_menu($user_type,'vendorInvoiceDues')>0){ 
	   ?>
		   <li class="<?php echo (($runningMethod =='invoiceByCustomer' || $runningMethod =='Invoiceviewandupdate' || $runningMethod =='vendorInvoiceDues') && ($menu=='Pending') ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceDues?status=<?php echo $this->encryption->encrypt('Pending'); ?>"><i class="fa fa-table"></i>Pending Invoice</a></li>
		<?php } ?>   
		  <?php 
		if(check_module_for_menu($user_type,'vendorInvoiceDues')>0){ 
	   ?>
            <li class="<?php echo (($runningMethod =='invoiceByCustomer' || $runningMethod =='Invoiceviewandupdate' || $runningMethod =='vendorInvoiceDues') && $menu=='Verified'  ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceDues?status=<?php echo $this->encryption->encrypt('Verified'); ?>"><i class="fa fa-table"></i>Verified Invoice</a></li>
			<?php } ?>   
			  <?php 
				if(check_module_for_menu($user_type,'ApprovedInvoice')>0){ 
				?>
            <li class="<?php echo ($runningMethod =='ApprovedInvoice' || $runningMethod =='viewmapped' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/ApprovedInvoice"><i class="fa fa-table"></i>Approved Invoice</a></li>		
			<?php } ?> 
			 <?php 
				if(check_module_for_menu($user_type,'paidInvoices')>0){ 
				?>
            <li class="<?php echo (($runningMethod =='paidInvoices' || $runningMethod =='viewmappedpaid') || ($runningMethod =='Invoiceviewandupdate' && $menu=='Paid') ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/paidInvoices"><i class="fa fa-table"></i>Paid Invoice</a></li>
				<?php } ?> 
				 <?php 
				if(check_module_for_menu($user_type,'vendorInvoiceDues')>0){ 
				?>
			<li class="<?php echo (($runningMethod =='invoiceByCustomer' || $runningMethod =='Invoiceviewandupdate' || $runningMethod =='vendorInvoiceDues') && $menu=='Rejected'  ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceDues?status=<?php echo $this->encryption->encrypt('Rejected'); ?>"><i class="fa fa-table"></i>Rejected Invoice</a></li>
			<?php } ?> 
			 <?php 
				if(check_module_for_menu($user_type,'vendorInvoiceDues')>0){ 
				?>
			<li class="hidden <?php echo ($runningMethod =='vendorInvoiceDues' && $menu=='Documents'  ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/vendorInvoiceDues?status=<?php echo $this->encryption->encrypt('Documents'); ?>"><i class="fa fa-table"></i>Pending Documents</a></li>
			<?php } ?> 
          </ul>
        </li>
		
        <?php }?>
	
		<?php
		if($active_cust_id!='') { ?>
			 <?php 
				if(check_module_for_menu($user_type,'replenishmentlist')>0){ 
				?>
        <li class="<?php echo ($runningMethod =='replenishment' || $runningMethod =='replenishmentlist'  || $runningMethod =='replenishmentVerification' ? 'menu-open' : ''); ?>">
          <a href="<?=ADMINBASEURL;?>bankadmin/replenishmentlist"><i class="fa fa-inr"></i> <span>Replenishment</span></a>          
        </li>
		<?php }?>
	<?php 
		if(check_module_for_menu($user_type,'customerBasedReport')>0){ 
	?>
	<li class="treeview <?php echo ($runningMethod =='customerBasedReport' || $runningMethod =='vendorBasedReport' || $runningMethod =='invoiceBasedReport'   ? 'active' : ''); ?>"><a href=""><i class="fa fa-file-text-o"></i> <span>Report</span>
		<span class="pull-right-container">
			<i class="fa fa-angle-left pull-right"></i>
		</span>
	</a>
	
	<ul class="treeview-menu" style="display:<?php echo ($runningMethod =='vendorBasedReport' || $runningMethod =='reportCustomerReceivable' ? 'block' : 'none'); ?>">
	
		<li class="<?php echo ($runningMethod =='vendorBasedReport'    ? 'active' : ''); ?>">
			<a href="<?=ADMINBASEURL .'bankadmin/vendorBasedReport/'.$active_cust_id;?>"><i class="fa fa-file-text-o"></i> 
				<span>Vendor Payments</span>	
			</a>
		</li>
		<li class="<?php echo ($runningMethod =='reportCustomerReceivable'  ? 'active' : ''); ?>">
			<a href="<?=ADMINBASEURL;?>bankadmin/reportCustomerReceivable"><i class="fa fa-file-text-o"></i> 
				<span>Customer Receivable</span>	
			</a>
		</li>
	</ul>
	</li>
	
	<?php } ?>   
	<?php } ?>   
       <?php 
	if(check_module_for_menu($user_type,'templates')>0){ 
				?>
        <li class="<?php echo ($runningMethod =='mailformat' || $runningMethod =='mailform'  || $runningMethod =='mailtemplates' ? 'menu-open' : ''); ?>">
          <a href="<?=ADMINBASEURL;?>templates/mailtemplates"><i class="fa fa-th"></i> <span>Mail Templates</span>            
          </a>
        </li>
		<?php } ?>  
		 <?php 
			if(check_module_for_menu($user_type,'userManagement')>0){ 
			?>
			<li class=""><a href="<?=ADMINBASEURL;?>bankadmin/userManagement"><i class="fa fa-link"></i> <span>User Management</span></a></li>
			<?php } ?> 
			<?php 
			if(check_module_for_menu($user_type,'siteSettings')>0){ 
			?>			
		<li class="<?php echo ($runningMethod =='siteSettings' ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/siteSettings"><i class="fa fa-gears"></i> <span>Site Settings</span></a></li>
		<?php } ?> 
       <?php 
			if(check_module_for_menu($user_type,'logdetails')>0){ 
			?>
	   <li class="<?php echo ($runningMethod =='logdetails'  ? 'active' : ''); ?>"><a href="<?=ADMINBASEURL;?>bankadmin/logdetails"><i class="fa fa-laptop"></i> <span>Activity Log</span></a></li>
	  <?php } ?> 
	  <?php 
			if(check_module_for_menu($user_type,'readExcel')>0){ 
			?>
		<li class=""><a href="<?=ADMINBASEURL;?>bankadmin/readExcel"><i class="fa fa-link"></i> <span>Invoice Cron link</span></a></li>
		<?php } ?> 
        </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>

  