<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteSettings->meta_title; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <meta name="description" content="<?=$siteSettings->meta_description; ?>">
  <meta name="keywords" content="<?=$siteSettings->meta_keywords; ?>">
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/ionicons.min.css">
  <!--DataTables-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/skin-blue.min.css">
  <!--User defined CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/style.css?ra=<?php echo rand(); ?>">  
  <!--Date Picker CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/bootstrap-datepicker.min.css">
  <!--Auto Complete CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/jquery-ui.css">
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/buttons.dataTables.min.css"> 
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!--<meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
  <script src="<?=ADMINBASEURL;?>assets/js/jquery.min.js"></script>
  
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>


<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  