  <div id="bg_model" class="bg_model">
	<img src="<?=ADMINBASEURL;?>/media/images/processing.gif" />
  </div>

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      
    </div>
    <!-- Default to the left -->
    <strong><?=$siteSettings->copy_rights; ?></strong>
  </footer>

<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 <script src="<?=ADMINBASEURL;?>assets/js/jquery.min.js"></script>-->


<!-- Datatables JS -->
<script src="<?=ADMINBASEURL;?>assets/js/dataTables.bootstrap.min.js"></script>
<script src="<?=ADMINBASEURL;?>assets/js/dataTables.min.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="<?=ADMINBASEURL;?>assets/js/bootstrap.min.js"></script>


<!-- AdminLTE App -->
<script src="<?=ADMINBASEURL;?>assets/js/adminlte.min.js"></script>

<!-- CK Editor -->
<script src="<?=ADMINBASEURL;?>assets/js/ckeditor/ckeditor.js"></script>

<!-- Autocomplete JS-->
<script src="<?=ADMINBASEURL;?>assets/js/jquery-ui.js"></script>

<!-- DatePicker JS -->
<script src="<?=ADMINBASEURL;?>assets/js/bootstrap-datepicker.min.js"></script>

<link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/buttons.dataTables.min.css">
<script src="<?=ADMINBASEURL;?>assets/js/fileinput.js" type="text/javascript"></script>
<script src="<?=ADMINBASEURL;?>assets/js/dataTables.buttons.min.js"></script>
<script src="<?=ADMINBASEURL;?>assets/js/jszip.min.js"></script>
<script src="<?=ADMINBASEURL;?>assets/js/buttons.html5.js"></script>

<script>
  $(function () {    
    CKEDITOR.replace('editor1')   
  })

</script>

<script type="text/javascript">
    var baseurl = '<?=ADMINBASEURL;?>';
</script>
<script  src="<?=ADMINBASEURL;?>assets/js/custom.js?ra=<?php echo rand(); ?>"></script>
<!-- Optionally, you can add Slimscroll and FastClick plugins.Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>