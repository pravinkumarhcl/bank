<script>
    $(document).ready(function() {
        $(".active-cus-name").click(function() {
            $(".custom-top-customer").toggle();
        });
    });
	$(document).mouseup(function (e){
		var container = $(".custom-top-customer");
		if (!container.is(e.target) && container.has(e.target).length === 0){
			container.hide();
		}
	});
</script>
<!-- Main Header -->
<header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
        <b>IOB-VF</b>
    </a>
	
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <?php		
					$CustomerData=$this->session->userdata("CustomerData");	
					
					if(isset($CustomerData['cust_name']) && $CustomerData['cust_name']!='')
					{
						?>
						<!-- Messages: style can be found in dropdown.less-->
						<li class="dropdown messages-menu" style="background: #4FB762;">
							<!-- Menu toggle button -->
							<a href="#" class="dropdown-toggle active-cus-name">
								<?php 
									echo 'Active Customer : <b>'.$CustomerData['cust_name'].'</b>('.ucfirst($this->session->userdata("active_cust_type")).')';
								?>             
							</a>

							<ul class="dropdown-menu custom-top-customer">
								<li class="header"><b>Customer Details</b>
									<a href="<?=ADMINBASEURL;?>bankadmin/clearCustomer" class="btn btn-info pull-right">Clear Customer</a>
								</li>
								<li>
									<!-- inner menu: contains the messages -->
									<table class="table table-bordered table-hover" style="width:100%">
										<tr>
											<td colspan="2"><b>General Info</b></td>
										</tr>
										<tr>
											<td>Customer Code</td>
											<td>
												<?php echo $CustomerData['cust_user_code']; ?>
											</td>
										</tr>
										<tr>
											<td>Customer Name</td>
											<td>
												<?php echo $CustomerData['cust_name']; ?>
											</td>
										</tr>
										<tr>
											<td colspan="2"><b>Company Info</b></td>
										</tr>
										<?php 
											$sub_company_data=$this->session->userdata('sub_company_data');
											foreach($sub_company_data as $sub_comp){
												?>
												<tr>
													<td>Subsidiary Company
														<?php echo ++$comp;?>
													</td>
													<td>
														<a href="<?php echo ADMINBASEURL; ?>bankadmin/customerview/<?php echo $sub_comp['cust_id'];?>">
														<?php echo $sub_comp['cust_name']; ?>
													</td>
												</tr>
												<?php
											}
										?>
										<tr>
											<td>Address 1</td>
											<td>
												<?php echo $CustomerData['cust_address1']; ?>
											</td>
										</tr>
										<tr>
											<td>Address 2</td>
											<td>
												<?php echo $CustomerData['cust_address2']; ?>
											</td>
										</tr>
										<tr>
											<td>City</td>
											<td>
												<?php echo $CustomerData['cust_city']; ?>
											</td>
										</tr>
										<tr>
											<td>State</td>
											<td>
												<?php echo $CustomerData['cust_state']; ?>
											</td>
										</tr>
										<tr>
											<td colspan="2"><b>Contact Info</b></td>
										</tr>
										<tr>
											<td>Phone number</td>
											<td>
												<?php echo $CustomerData['cust_phone']; ?>
											</td>
										</tr>
										<tr>
											<td>Email Address</td>
											<td>
												<?php echo $CustomerData['cust_email']; ?>
											</td>
										</tr>
										<tr>
											<td colspan="2"><b>Account Info</b></td>
										</tr>
										<tr>
											<td>Customer Account no</td>
											<td>
												<?php echo $CustomerData['cust_account_no']; ?>
											</td>
										</tr>
										<tr>
											<td>IFSC Code</td>
											<td>
												<?php echo $CustomerData['cust_ifsc_code']; ?>
											</td>
										</tr>

										<tr>
											<td colspan="2"><b>Loan Limit Info</b></td>
										</tr>
										<tr>
											<td>Loan Limit</td>
											<td>
												<?php echo $CustomerData['cust_loan_limit']; ?>
											</td>
										</tr>
										<tr>
											<td>Balance Loan Limit</td>
											<td>
												<?php echo $CustomerData['cust_current_loan_balance']; ?>
											</td>
										</tr>
										<tr>
											<td>Monthly Loan Limit</td>
											<td>
												<?php echo $CustomerData['cust_monthly_loan_limit']; ?>
											</td>
										</tr>
										<tr>
											<td>Weekly Loan Limit</td>
											<td>
												<?php echo $CustomerData['cust_weekly_loan_limit']; ?>
											</td>
										</tr>

										<tr>
											<td colspan="2"><b>Interest Rate Info</b></td>
										</tr>
										<tr>
											<td>
												Financing Date</td>
											<td>
												<?php echo $CustomerData['financing_date']; ?>
											</td>
										</tr>
										<tr>
											<td>
												3 Months MCLR
											</td>
											<td>
												<?php echo $CustomerData['three_mclr']; ?>
											</td>
										</tr>
										<tr>
											<td>
												6 Months MCLR
											</td>
											<td>
												<?php echo $CustomerData['six_mclr']; ?>
											</td>
										</tr>
										<tr>
											<td>
												9 Months MCLR
											</td>
											<td>
												<?php echo $CustomerData['nine_mclr']; ?>
											</td>
										</tr>
										<tr>
											<td>
												1 Year MCLR
											</td>
											<td>
												<?php echo $CustomerData['mclr_twelve']; ?>
											</td>
										</tr>
										<tr>
											<td>Strategic Premium Rate </td>
											<td>
												<?php echo $CustomerData['strategic_premium_rate']; ?>
											</td>
										</tr>
										<tr>
											<td>Risk Premium Rate</td>
											<td>
												<?php echo $CustomerData['risk_premium_rate']; ?>
											</td>
										</tr>
										</tbody>
									</table>
									<!-- /.menu -->
									</li>
								</ul>
							</li>
							<?php } ?>
							<!-- /.messages-menu -->

							<!-- User Account Menu -->
							<li class="dropdown user user-menu">
								<!-- Menu Toggle Button -->
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<span class="hidden-xs">My Account</span>
								</a>
								<ul class="dropdown-menu">
									<!-- The user image in the menu -->
									<li class="user-footer">
										<a href="<?=ADMINBASEURL;?>bankadmin/myprofile">My Profile</a>
									</li>
									<li class="user-footer">
										<a href="<?=ADMINBASEURL;?>bankadmin/siteSettings">Site Settings</a>
									</li>
									<li class="user-footer">
										<a href="<?=ADMINBASEURL;?>bankadmin/logout">Sign out</a>
									</li>
								</ul>
							</li>

            </ul>
        </div>
    </nav>
</header>