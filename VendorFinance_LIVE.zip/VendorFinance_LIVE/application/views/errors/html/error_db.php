

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteSettings->meta_title; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <meta name="description" content="<?=$siteSettings->meta_description; ?>">
  <meta name="keywords" content="<?=$siteSettings->meta_keywords; ?>">
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/ionicons.min.css">
  <!--DataTables-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/skin-blue.min.css">
  <!--User defined CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/style.css?ra=<?php echo rand(); ?>">  
  <!--Date Picker CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/bootstrap-datepicker.min.css">
  <!--Auto Complete CSS-->
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/jquery-ui.css">
  <link rel="stylesheet" href="<?=ADMINBASEURL;?>assets/css/buttons.dataTables.min.css"> 
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <script src="<?=ADMINBASEURL;?>assets/js/jquery.min.js"></script>
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<style type="text/css">

::selection { background-color: #E13300; color: white; }
::-moz-selection { background-color: #E13300; color: white; }

body {
	background-color: #FFF;	
	font: 13px/20px normal Helvetica, Arial, sans-serif;
	color: #4F5155;
}

a {
	color: #003399;
	background-color: transparent;
	font-weight: normal;
}

h1 {
	color: #444;
	background-color: transparent;	
	font-size: 35px;
	font-weight: normal;
	margin: 0 0 14px 0;
	padding: 20px 15px 10px 15px;
	line-height:70px;
}
h1 span{
	font-size:55px;
}
code {
	font-family: Consolas, Monaco, Courier New, Courier, monospace;
	font-size: 12px;
	background-color: #f9f9f9;
	border: 1px solid #D0D0D0;
	color: #002166;
	display: block;
	margin: 14px 0 14px 0;
	padding: 12px 10px 12px 10px;
}
p {
	margin: 12px 15px 12px 15px;
}
.fa-exclamation-triangle{
	color:#f26060;
	font-size: 60px !important;
}
.contact-admin{
	text-align: center;
    font-size: 20px;
    font-weight: 700;
    color: #009688;
}
</style>
 <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>


<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Main Header -->
  <!-- Main Header -->
  <header class="main-header">

    <!-- Logo -->
    <a href="#" class="logo">
	  <b>IOB-VF</b>     
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
	  
        <ul class="nav navbar-nav">
		
          
          <!-- User Account Menu -->
          <li class="dropdown user user-menu">
            <!-- Menu Toggle Button -->
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="hidden-xs">My Account</span>
            </a>
            <ul class="dropdown-menu">
              <!-- The user image in the menu -->
              
              <li class="user-footer">
                  <a href="<?=ADMINBASEURL;?>bankadmin/siteSettings">Site Settings</a>
              </li>
              <li class="user-footer">
                  <a href="<?=ADMINBASEURL;?>bankadmin/logout">Sign out</a>
              </li>
            </ul>
          </li>
          
        </ul>
      </div>
    </nav>
  </header> 

 <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?=MEDIAURL;?>images/adminlogo.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          
          <!-- Status -->
          
        </div>
      </div>
    
		<!-- Sidebar Menu -->
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header">MAIN NAVIGATION</li>
			<!-- Optionally, you can add icons to the links -->
		</ul>
		<!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

<div class="content-wrapper" style="min-height: 916.3px;">
	<h1 align="center"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <br/> <span>OOPS</span> <br/> Something Went Wrong</h1>
	<div class='contact-admin' style="color:#555;">Database server is not available</div>
	<br/>
	<div class='contact-admin'>Please contact system administrator</div>
	<!--<h1><?php echo $heading; ?></h1>
	<?php echo $message; ?>-->
</div>
</body>
</html>